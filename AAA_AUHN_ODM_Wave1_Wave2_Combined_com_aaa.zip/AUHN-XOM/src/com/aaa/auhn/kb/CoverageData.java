package com.aaa.auhn.kb;
public class CoverageData {
    private String vVehicle_Number;
    public String getVVehicle_Number() { return vVehicle_Number; }
    public void setVVehicle_Number(String value) { vVehicle_Number = value; }
    private String vLine;
    public String getVLine() { return vLine; }
    public void setVLine(String value) { vLine = value; }
    private String vLimit;
    public String getVLimit() { return vLimit; }
    public void setVLimit(String value) { vLimit = value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction=value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
}
