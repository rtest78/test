package com.techsavants.auhn.kb;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;

/** Generic collection operations intended for direct use by ODM BAL rules. */
public final class AuhnCollections {
	private AuhnCollections() {
	}

	public static int countWhere(List<?> facts, String property, Object expected) {
		int count = 0;
		if (facts == null)
			return 0;
		for (Object fact : facts)
			if (Objects.equals(read(fact, property), expected))
				count++;
		return count;
	}

	public static boolean anyWhere(List<?> facts, String property, Object expected) {
		if (facts == null)
			return false;
		for (Object fact : facts)
			if (Objects.equals(read(fact, property), expected))
				return true;
		return false;
	}

	/** Universal quantification; an empty list returns true. */
	public static boolean allWhere(List<?> facts, String property, Object expected) {
		if (facts == null || facts.isEmpty())
			return true;
		for (Object fact : facts)
			if (!Objects.equals(read(fact, property), expected))
				return false;
		return true;
	}

	/** Projects one property from a list while preserving source order. */
	public static List<String> projectStrings(List<?> facts, String property) {
		List<String> out = new ArrayList<String>();
		if (facts == null)
			return out;
		for (Object fact : facts) {
			Object value = read(fact, property);
			if (value != null)
				out.add(String.valueOf(value));
		}
		return out;
	}

	public static boolean contains(List<?> values, Object expected) {
		return values != null && values.contains(expected);
	}

	public static List<Object> distinct(List<?> values) {
		return values == null ? new ArrayList<Object>() : new ArrayList<Object>(new LinkedHashSet<Object>(values));
	}

	private static Object read(Object fact, String property) {
		if (fact == null || property == null)
			return null;
		String suffix = property.length() == 0 ? property
				: Character.toUpperCase(property.charAt(0)) + property.substring(1);
		try {
			Method getter = fact.getClass().getMethod("get" + suffix);
			return getter.invoke(fact);
		} catch (Exception ignored) {
			try {
				Method getter = fact.getClass().getMethod("getV" + suffix);
				return getter.invoke(fact);
			} catch (Exception ignoredAgain) {
				try {
					Method getter = fact.getClass().getMethod("is" + suffix);
					return getter.invoke(fact);
				} catch (Exception ignoredBoolean) {
					try {
						Method getter = fact.getClass().getMethod("isV" + suffix);
						return getter.invoke(fact);
					} catch (Exception ignoredPrefixedBoolean) {
						try {
							Field field = fact.getClass().getDeclaredField(property);
							field.setAccessible(true);
							return field.get(fact);
						} catch (Exception missing) {
							try {
								Field field = fact.getClass().getDeclaredField(
										"v" + Character.toUpperCase(property.charAt(0)) + property.substring(1));
								field.setAccessible(true);
								return field.get(fact);
							} catch (Exception missingPrefixed) {
								throw new IllegalArgumentException(
										"Unknown AUHN property: " + property + " on " + fact.getClass().getName(),
										missingPrefixed);
							}
						}
					}
				}
			}
		}
	}
}
