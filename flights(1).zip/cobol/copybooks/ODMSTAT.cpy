      * LOCAL APPLICATION STATUS; NOT THE IBM HBRA-CONN-AREA.
       01 ODM-CALL-STATUS.
          05 ODM-APP-RC               PIC 9(3).
             88 ODM-CALL-OK           VALUE 0.
             88 ODM-CALL-FAILED       VALUE 500.
          05 ODM-WARNING              PIC X.
          05 ODM-ERROR-STAGE          PIC X(24).
          05 ODM-ERROR-MESSAGE        PIC X(1024).
          05 ODM-API-LOAD-ERROR       PIC X.
          05 ODM-CONN-CALLED          PIC X.
          05 ODM-CONN-CC              PIC S9(9) COMP-5.
          05 ODM-CONN-RC              PIC S9(9) COMP-5.
          05 ODM-CONN-MESSAGE         PIC X(1024).
          05 ODM-RULE-CALLED          PIC X.
          05 ODM-RULE-SUCCESS         PIC X.
          05 ODM-RULE-CC              PIC S9(9) COMP-5.
          05 ODM-RULE-RC              PIC S9(9) COMP-5.
          05 ODM-RULE-MESSAGE         PIC X(1024).
          05 ODM-DISC-CALLED          PIC X.
          05 ODM-DISC-CC              PIC S9(9) COMP-5.
          05 ODM-DISC-RC              PIC S9(9) COMP-5.
          05 ODM-DISC-MESSAGE         PIC X(1024).
