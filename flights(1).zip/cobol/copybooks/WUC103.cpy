000100******************************************************************00010000
000200* WUC103 - POLICY CODES COBOL II RECORD LAYOUT.                *  00020000
000300******************************************************************00030000
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00040000
000500* POLICY CODES DATA TO BE PASSED TO AION.                        *00050000
000600*                                                                *00060000
000700******************************************************************00070000
000800*01 WUC103-POLICY-CODES-REC.                                      00080000
000900   05 WUC103-POLICY-CODES-DATA OCCURS 30 TIMES                    00090000
001000             INDEXED BY POC-IDX.                                  00100000
001100      10 WUC103-POC-GENERATION             PIC  X(01).            00110000
001200         88 WUC103-UNKNOWN-GENERATION                VALUE 'X'.   00120000
001300         88 WUC103-EXISTING-GENERATION               VALUE 'E'.   00130000
001400         88 WUC103-CHANGE-GENERATION                 VALUE 'C'.   00140000
001500      10 WUC103-POC-ACTION                 PIC  X(04).            00150000
001600      10 WUC103-POC-NAME                   PIC  X(10).            00160000
001700      10 WUC103-POC-CODE                   PIC  X(10).            00170000
