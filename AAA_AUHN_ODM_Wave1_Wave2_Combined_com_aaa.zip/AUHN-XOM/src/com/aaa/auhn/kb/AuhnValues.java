package com.aaa.auhn.kb;

public final class AuhnValues {
	public static String getNullText() {
		return null;
	}

	public static boolean isNull(Object value) {
		return value == null;
	}

	public static boolean isNullList(java.util.List<?> value) {
		return value == null;
	}

	private AuhnValues() {
	}

	public static boolean truth(boolean value) {
		return value;
	}

	public static int compareText(String left, String right) {
		if (left == null || right == null)
			throw new NullPointerException("Null operand in ordered text comparison");
		return left.compareTo(right);
	}

	public static int position(String needle, String haystack) {
		if (needle == null || haystack == null)
			return 0;
		return haystack.indexOf(needle) + 1;
	}

	public static java.util.Date date(int y, int m, int d) {
		return java.util.Date.from(java.time.LocalDate.of(y, m, d).atStartOfDay(java.time.ZoneOffset.UTC).toInstant());
	}
}
