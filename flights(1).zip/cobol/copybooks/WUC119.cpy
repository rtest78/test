000100******************************************************************00010000
000200* WUC119 - SUSPENSION COBOL II RECORD LAYOUT.                    *00020000
000300******************************************************************00030000
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00040000
000500* ADMITTED SUSPENSION/REINSTATEMENT DATA TO BE PASSED TO AION.   *00050000
000600*                                                                *00060000
000700******************************************************************00070000
000800*01 WUC119-SUSPENSION-REC.                                        00080000
000900   05 WUC119-SUSPENSION-INFORMATION OCCURS 400 TIMES              00090000
001000             INDEXED BY SUSP-IDX.                                 00100000
001100      10 WUC119-SUSP-GENERATION            PIC  X(01).            00110000
001200         88 WUC119-UNKNOWN-GENERATION                VALUE 'X'.   00120000
001300         88 WUC119-EXISTING-GENERATION               VALUE 'E'.   00130000
001400         88 WUC119-CHANGE-GENERATION                 VALUE 'C'.   00140000
001500      10 WUC119-SUSP-ACTION                PIC  X(04).            00150000
001600      10 WUC119-SUSP-DRIVER-NUMBER         PIC  9(15).            00160000
001700      10 WUC119-SUSP-ID                    PIC  9(04).            00170000
001800      10 WUC119-SUSP-DATE                  PIC  X(10).            00180000
001900      10 WUC119-REIN-DATE                  PIC  X(10).            00190000
