package com.techsavants.auhn.kb;
public class Policies {
    private Boolean vIsCurrentInfo;
    public Boolean getVIsCurrentInfo() { return vIsCurrentInfo; }
    public void setVIsCurrentInfo(Boolean value) { vIsCurrentInfo = value; }
    private Boolean vRewrittenPolicy;
    public Boolean getVRewrittenPolicy() { return vRewrittenPolicy; }
    public void setVRewrittenPolicy(Boolean value) { vRewrittenPolicy = value; }
    private String vBackdatedEffDt;
    public String getVBackdatedEffDt() { return vBackdatedEffDt; }
    public void setVBackdatedEffDt(String value) { vBackdatedEffDt = value; }
    private Boolean vCommentFlag;
    public Boolean getVCommentFlag() { return vCommentFlag; }
    public void setVCommentFlag(Boolean value) { vCommentFlag = value; }
    private Boolean vCACLossExistsFlag;
    public Boolean getVCACLossExistsFlag() { return vCACLossExistsFlag; }
    public void setVCACLossExistsFlag(Boolean value) { vCACLossExistsFlag = value; }
    private Boolean vCACDrvCdErrorExistsFlag;
    public Boolean getVCACDrvCdErrorExistsFlag() { return vCACDrvCdErrorExistsFlag; }
    public void setVCACDrvCdErrorExistsFlag(Boolean value) { vCACDrvCdErrorExistsFlag = value; }
    private String vBusinessClass;
    public String getVBusinessClass() { return vBusinessClass; }
    public void setVBusinessClass(String value) { vBusinessClass = value; }
    private Boolean vReferAgentExistsFlag;
    public Boolean getVReferAgentExistsFlag() { return vReferAgentExistsFlag; }
    public void setVReferAgentExistsFlag(Boolean value) { vReferAgentExistsFlag = value; }
    private String vJewelHUONPremDiscrepancy;
    public String getVJewelHUONPremDiscrepancy() { return vJewelHUONPremDiscrepancy; }
    public void setVJewelHUONPremDiscrepancy(String value) { vJewelHUONPremDiscrepancy = value; }
    private String vPolPrdEffDte;
    public String getVPolPrdEffDte() { return vPolPrdEffDte; }
    public void setVPolPrdEffDte(String value) { vPolPrdEffDte = value; }
    private Boolean vClueReceivedFlag;
    public Boolean getVClueReceivedFlag() { return vClueReceivedFlag; }
    public void setVClueReceivedFlag(Boolean value) { vClueReceivedFlag = value; }
    private Boolean vMgrEADApprovalFlag;
    public Boolean getVMgrEADApprovalFlag() { return vMgrEADApprovalFlag; }
    public void setVMgrEADApprovalFlag(Boolean value) { vMgrEADApprovalFlag = value; }
    private String vTransType;
    public String getVTransType() { return vTransType; }
    public void setVTransType(String value) { vTransType = value; }
    private String vSpinOffPolicy;
    public String getVSpinOffPolicy() { return vSpinOffPolicy; }
    public void setVSpinOffPolicy(String value) { vSpinOffPolicy = value; }
    private String vNNOPolicy;
    public String getVNNOPolicy() { return vNNOPolicy; }
    public void setVNNOPolicy(String value) { vNNOPolicy = value; }
    private Boolean vReferBranchExistsFlag;
    public Boolean getVReferBranchExistsFlag() { return vReferBranchExistsFlag; }
    public void setVReferBranchExistsFlag(Boolean value) { vReferBranchExistsFlag = value; }
    private Boolean vUmbrellaPolicyFlag;
    public Boolean getVUmbrellaPolicyFlag() { return vUmbrellaPolicyFlag; }
    public void setVUmbrellaPolicyFlag(Boolean value) { vUmbrellaPolicyFlag = value; }
    private Boolean vAnnMileOverrideExists;
    public Boolean getVAnnMileOverrideExists() { return vAnnMileOverrideExists; }
    public void setVAnnMileOverrideExists(Boolean value) { vAnnMileOverrideExists = value; }
    private Boolean vIsExistingInfo;
    public Boolean getVIsExistingInfo() { return vIsExistingInfo; }
    public void setVIsExistingInfo(Boolean value) { vIsExistingInfo = value; }
    private Boolean vIsNewInfo;
    public Boolean getVIsNewInfo() { return vIsNewInfo; }
    public void setVIsNewInfo(Boolean value) { vIsNewInfo = value; }
    private String vNamedInsuredChanged;
    public String getVNamedInsuredChanged() { return vNamedInsuredChanged; }
    public void setVNamedInsuredChanged(String value) { vNamedInsuredChanged = value; }
    private Boolean vAgentChangeFlag;
    public Boolean getVAgentChangeFlag() { return vAgentChangeFlag; }
    public void setVAgentChangeFlag(Boolean value) { vAgentChangeFlag = value; }
    private Boolean vInceptionChangeFlag;
    public Boolean getVInceptionChangeFlag() { return vInceptionChangeFlag; }
    public void setVInceptionChangeFlag(Boolean value) { vInceptionChangeFlag = value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction=value; }
    private String vACTION_ADDED;
    public String getVACTION_ADDED() { return vACTION_ADDED; }
    public void setVACTION_ADDED(String value) { vACTION_ADDED=value; }
    private String vACTION_CHANGED;
    public String getVACTION_CHANGED() { return vACTION_CHANGED; }
    public void setVACTION_CHANGED(String value) { vACTION_CHANGED=value; }
    private String vACTION_ELIMINATED;
    public String getVACTION_ELIMINATED() { return vACTION_ELIMINATED; }
    public void setVACTION_ELIMINATED(String value) { vACTION_ELIMINATED=value; }
    private java.util.Date vEffectiveDate;
    public java.util.Date getVEffectiveDate() { return vEffectiveDate; }
    public void setVEffectiveDate(java.util.Date value) { vEffectiveDate=value; }
    private Boolean vVehicleAdditionalInsuredsFlag;
    public Boolean getVVehicleAdditionalInsuredsFlag() { return vVehicleAdditionalInsuredsFlag; }
    public void setVVehicleAdditionalInsuredsFlag(Boolean value) { vVehicleAdditionalInsuredsFlag=value; }
    private Boolean vMgrApprovalFlag;
    public Boolean getVMgrApprovalFlag() { return vMgrApprovalFlag; }
    public void setVMgrApprovalFlag(Boolean value) { vMgrApprovalFlag=value; }
    private Boolean vVehicleSpecialEquipmentFlag;
    public Boolean getVVehicleSpecialEquipmentFlag() { return vVehicleSpecialEquipmentFlag; }
    public void setVVehicleSpecialEquipmentFlag(Boolean value) { vVehicleSpecialEquipmentFlag=value; }
    private String vBusinessClassScore;
    public String getVBusinessClassScore() { return vBusinessClassScore; }
    public void setVBusinessClassScore(String value) { vBusinessClassScore=value; }
    private String vProdRlseEffDte;
    public String getVProdRlseEffDte() { return vProdRlseEffDte; }
    public void setVProdRlseEffDte(String value) { vProdRlseEffDte=value; }
    private String vCLUENotReceived;
    public String getVCLUENotReceived() { return vCLUENotReceived; }
    public void setVCLUENotReceived(String value) { vCLUENotReceived=value; }
    private Boolean vLiabOnlyCovgExistsFlag;
    public Boolean getVLiabOnlyCovgExistsFlag() { return vLiabOnlyCovgExistsFlag; }
    public void setVLiabOnlyCovgExistsFlag(Boolean value) { vLiabOnlyCovgExistsFlag=value; }
    private Boolean vIsAddedOrNew;
    public Boolean getVIsAddedOrNew() { return vIsAddedOrNew; }
    public void setVIsAddedOrNew(Boolean value) { vIsAddedOrNew=value; }
}
