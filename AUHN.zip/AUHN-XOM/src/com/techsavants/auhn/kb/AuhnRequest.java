package com.techsavants.auhn.kb;

import java.util.*;

public class AuhnRequest {
	private String transactionType;
	private String executionPhase = "FULL";

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String v) {
		transactionType = v;
	}

	public String getExecutionPhase() {
		return executionPhase;
	}

	public void setExecutionPhase(String v) {
		executionPhase = v;
	}

	private List<AccidentData> accidentDataFacts = new ArrayList<AccidentData>();

	public List<AccidentData> getAccidentDataFacts() {
		return accidentDataFacts;
	}

	public void setAccidentDataFacts(List<AccidentData> v) {
		accidentDataFacts = v == null ? new ArrayList<AccidentData>() : v;
	}

	private List<AccidentsAdmitted> accidentsAdmittedFacts = new ArrayList<AccidentsAdmitted>();

	public List<AccidentsAdmitted> getAccidentsAdmittedFacts() {
		return accidentsAdmittedFacts;
	}

	public void setAccidentsAdmittedFacts(List<AccidentsAdmitted> v) {
		accidentsAdmittedFacts = v == null ? new ArrayList<AccidentsAdmitted>() : v;
	}

	private List<AccidentsPACE> accidentsPACEFacts = new ArrayList<AccidentsPACE>();

	public List<AccidentsPACE> getAccidentsPACEFacts() {
		return accidentsPACEFacts;
	}

	public void setAccidentsPACEFacts(List<AccidentsPACE> v) {
		accidentsPACEFacts = v == null ? new ArrayList<AccidentsPACE>() : v;
	}

	private List<ApplicationData> applicationDataFacts = new ArrayList<ApplicationData>();

	public List<ApplicationData> getApplicationDataFacts() {
		return applicationDataFacts;
	}

	public void setApplicationDataFacts(List<ApplicationData> v) {
		applicationDataFacts = v == null ? new ArrayList<ApplicationData>() : v;
	}

	private List<CitationData> citationDataFacts = new ArrayList<CitationData>();

	public List<CitationData> getCitationDataFacts() {
		return citationDataFacts;
	}

	public void setCitationDataFacts(List<CitationData> v) {
		citationDataFacts = v == null ? new ArrayList<CitationData>() : v;
	}

	private List<Citations> citationsFacts = new ArrayList<Citations>();

	public List<Citations> getCitationsFacts() {
		return citationsFacts;
	}

	public void setCitationsFacts(List<Citations> v) {
		citationsFacts = v == null ? new ArrayList<Citations>() : v;
	}

	private List<CoverageData> coverageDataFacts = new ArrayList<CoverageData>();

	public List<CoverageData> getCoverageDataFacts() {
		return coverageDataFacts;
	}

	public void setCoverageDataFacts(List<CoverageData> v) {
		coverageDataFacts = v == null ? new ArrayList<CoverageData>() : v;
	}

	private List<Coverages> coveragesFacts = new ArrayList<Coverages>();

	public List<Coverages> getCoveragesFacts() {
		return coveragesFacts;
	}

	public void setCoveragesFacts(List<Coverages> v) {
		coveragesFacts = v == null ? new ArrayList<Coverages>() : v;
	}

	private List<DriverData> driverDataFacts = new ArrayList<DriverData>();

	public List<DriverData> getDriverDataFacts() {
		return driverDataFacts;
	}

	public void setDriverDataFacts(List<DriverData> v) {
		driverDataFacts = v == null ? new ArrayList<DriverData>() : v;
	}

	private List<DriverOfVehicleData> driverOfVehicleDataFacts = new ArrayList<DriverOfVehicleData>();

	public List<DriverOfVehicleData> getDriverOfVehicleDataFacts() {
		return driverOfVehicleDataFacts;
	}

	public void setDriverOfVehicleDataFacts(List<DriverOfVehicleData> v) {
		driverOfVehicleDataFacts = v == null ? new ArrayList<DriverOfVehicleData>() : v;
	}

	private List<Drivers> driversFacts = new ArrayList<Drivers>();

	public List<Drivers> getDriversFacts() {
		return driversFacts;
	}

	public void setDriversFacts(List<Drivers> v) {
		driversFacts = v == null ? new ArrayList<Drivers>() : v;
	}

	private List<DriversMVRInfo> driversMVRInfoFacts = new ArrayList<DriversMVRInfo>();

	public List<DriversMVRInfo> getDriversMVRInfoFacts() {
		return driversMVRInfoFacts;
	}

	public void setDriversMVRInfoFacts(List<DriversMVRInfo> v) {
		driversMVRInfoFacts = v == null ? new ArrayList<DriversMVRInfo>() : v;
	}

	private List<DriversOfVehicles> driversOfVehiclesFacts = new ArrayList<DriversOfVehicles>();

	public List<DriversOfVehicles> getDriversOfVehiclesFacts() {
		return driversOfVehiclesFacts;
	}

	public void setDriversOfVehiclesFacts(List<DriversOfVehicles> v) {
		driversOfVehiclesFacts = v == null ? new ArrayList<DriversOfVehicles>() : v;
	}

	private List<EmploymentData> employmentDataFacts = new ArrayList<EmploymentData>();

	public List<EmploymentData> getEmploymentDataFacts() {
		return employmentDataFacts;
	}

	public void setEmploymentDataFacts(List<EmploymentData> v) {
		employmentDataFacts = v == null ? new ArrayList<EmploymentData>() : v;
	}

	private List<EndorsementData> endorsementDataFacts = new ArrayList<EndorsementData>();

	public List<EndorsementData> getEndorsementDataFacts() {
		return endorsementDataFacts;
	}

	public void setEndorsementDataFacts(List<EndorsementData> v) {
		endorsementDataFacts = v == null ? new ArrayList<EndorsementData>() : v;
	}

	private List<Endorsements> endorsementsFacts = new ArrayList<Endorsements>();

	public List<Endorsements> getEndorsementsFacts() {
		return endorsementsFacts;
	}

	public void setEndorsementsFacts(List<Endorsements> v) {
		endorsementsFacts = v == null ? new ArrayList<Endorsements>() : v;
	}

	private List<InspectionData> inspectionDataFacts = new ArrayList<InspectionData>();

	public List<InspectionData> getInspectionDataFacts() {
		return inspectionDataFacts;
	}

	public void setInspectionDataFacts(List<InspectionData> v) {
		inspectionDataFacts = v == null ? new ArrayList<InspectionData>() : v;
	}

	private List<Inspections> inspectionsFacts = new ArrayList<Inspections>();

	public List<Inspections> getInspectionsFacts() {
		return inspectionsFacts;
	}

	public void setInspectionsFacts(List<Inspections> v) {
		inspectionsFacts = v == null ? new ArrayList<Inspections>() : v;
	}

	private List<MVR1Data> mVR1DataFacts = new ArrayList<MVR1Data>();

	public List<MVR1Data> getMVR1DataFacts() {
		return mVR1DataFacts;
	}

	public void setMVR1DataFacts(List<MVR1Data> v) {
		mVR1DataFacts = v == null ? new ArrayList<MVR1Data>() : v;
	}

	private List<MVR2Data> mVR2DataFacts = new ArrayList<MVR2Data>();

	public List<MVR2Data> getMVR2DataFacts() {
		return mVR2DataFacts;
	}

	public void setMVR2DataFacts(List<MVR2Data> v) {
		mVR2DataFacts = v == null ? new ArrayList<MVR2Data>() : v;
	}

	private List<MVR3Data> mVR3DataFacts = new ArrayList<MVR3Data>();

	public List<MVR3Data> getMVR3DataFacts() {
		return mVR3DataFacts;
	}

	public void setMVR3DataFacts(List<MVR3Data> v) {
		mVR3DataFacts = v == null ? new ArrayList<MVR3Data>() : v;
	}

	private List<MVR4Data> mVR4DataFacts = new ArrayList<MVR4Data>();

	public List<MVR4Data> getMVR4DataFacts() {
		return mVR4DataFacts;
	}

	public void setMVR4DataFacts(List<MVR4Data> v) {
		mVR4DataFacts = v == null ? new ArrayList<MVR4Data>() : v;
	}

	private List<MVR5Data> mVR5DataFacts = new ArrayList<MVR5Data>();

	public List<MVR5Data> getMVR5DataFacts() {
		return mVR5DataFacts;
	}

	public void setMVR5DataFacts(List<MVR5Data> v) {
		mVR5DataFacts = v == null ? new ArrayList<MVR5Data>() : v;
	}

	private List<MVR6Data> mVR6DataFacts = new ArrayList<MVR6Data>();

	public List<MVR6Data> getMVR6DataFacts() {
		return mVR6DataFacts;
	}

	public void setMVR6DataFacts(List<MVR6Data> v) {
		mVR6DataFacts = v == null ? new ArrayList<MVR6Data>() : v;
	}

	private List<MVRHierarchy> mVRHierarchyFacts = new ArrayList<MVRHierarchy>();

	public List<MVRHierarchy> getMVRHierarchyFacts() {
		return mVRHierarchyFacts;
	}

	public void setMVRHierarchyFacts(List<MVRHierarchy> v) {
		mVRHierarchyFacts = v == null ? new ArrayList<MVRHierarchy>() : v;
	}

	private List<Occupations> occupationsFacts = new ArrayList<Occupations>();

	public List<Occupations> getOccupationsFacts() {
		return occupationsFacts;
	}

	public void setOccupationsFacts(List<Occupations> v) {
		occupationsFacts = v == null ? new ArrayList<Occupations>() : v;
	}

	private List<PACEData> pACEDataFacts = new ArrayList<PACEData>();

	public List<PACEData> getPACEDataFacts() {
		return pACEDataFacts;
	}

	public void setPACEDataFacts(List<PACEData> v) {
		pACEDataFacts = v == null ? new ArrayList<PACEData>() : v;
	}

	private List<Policies> policiesFacts = new ArrayList<Policies>();

	public List<Policies> getPoliciesFacts() {
		return policiesFacts;
	}

	public void setPoliciesFacts(List<Policies> v) {
		policiesFacts = v == null ? new ArrayList<Policies>() : v;
	}

	private List<PolicyCodeData> policyCodeDataFacts = new ArrayList<PolicyCodeData>();

	public List<PolicyCodeData> getPolicyCodeDataFacts() {
		return policyCodeDataFacts;
	}

	public void setPolicyCodeDataFacts(List<PolicyCodeData> v) {
		policyCodeDataFacts = v == null ? new ArrayList<PolicyCodeData>() : v;
	}

	private List<PolicyCodes> policyCodesFacts = new ArrayList<PolicyCodes>();

	public List<PolicyCodes> getPolicyCodesFacts() {
		return policyCodesFacts;
	}

	public void setPolicyCodesFacts(List<PolicyCodes> v) {
		policyCodesFacts = v == null ? new ArrayList<PolicyCodes>() : v;
	}

	private List<PolicyData> policyDataFacts = new ArrayList<PolicyData>();

	public List<PolicyData> getPolicyDataFacts() {
		return policyDataFacts;
	}

	public void setPolicyDataFacts(List<PolicyData> v) {
		policyDataFacts = v == null ? new ArrayList<PolicyData>() : v;
	}

	private List<SuspensionData> suspensionDataFacts = new ArrayList<SuspensionData>();

	public List<SuspensionData> getSuspensionDataFacts() {
		return suspensionDataFacts;
	}

	public void setSuspensionDataFacts(List<SuspensionData> v) {
		suspensionDataFacts = v == null ? new ArrayList<SuspensionData>() : v;
	}

	private List<TransData> transDataFacts = new ArrayList<TransData>();

	public List<TransData> getTransDataFacts() {
		return transDataFacts;
	}

	public void setTransDataFacts(List<TransData> v) {
		transDataFacts = v == null ? new ArrayList<TransData>() : v;
	}

	private List<VehicleData> vehicleDataFacts = new ArrayList<VehicleData>();

	public List<VehicleData> getVehicleDataFacts() {
		return vehicleDataFacts;
	}

	public void setVehicleDataFacts(List<VehicleData> v) {
		vehicleDataFacts = v == null ? new ArrayList<VehicleData>() : v;
	}

	private List<Vehicles> vehiclesFacts = new ArrayList<Vehicles>();

	public List<Vehicles> getVehiclesFacts() {
		return vehiclesFacts;
	}

	public void setVehiclesFacts(List<Vehicles> v) {
		vehiclesFacts = v == null ? new ArrayList<Vehicles>() : v;
	}

	private final List<AccidentsMVR> accidentsMVRFacts = new ArrayList<AccidentsMVR>();

	public List<AccidentsMVR> getAccidentsMVRFacts() {
		return accidentsMVRFacts;
	}

	private final List<CitationsAdmitted> citationsAdmittedFacts = new ArrayList<CitationsAdmitted>();

	public List<CitationsAdmitted> getCitationsAdmittedFacts() {
		return citationsAdmittedFacts;
	}

	private final List<CitationsMVR> citationsMVRFacts = new ArrayList<CitationsMVR>();

	public List<CitationsMVR> getCitationsMVRFacts() {
		return citationsMVRFacts;
	}

	private final List<SuspensionsAdmitted> suspensionsAdmittedFacts = new ArrayList<SuspensionsAdmitted>();

	public List<SuspensionsAdmitted> getSuspensionsAdmittedFacts() {
		return suspensionsAdmittedFacts;
	}

	private final List<SuspensionsMVR> suspensionsMVRFacts = new ArrayList<SuspensionsMVR>();

	public List<SuspensionsMVR> getSuspensionsMVRFacts() {
		return suspensionsMVRFacts;
	}

	private final List<FailuresToAppear> failuresToAppearFacts = new ArrayList<FailuresToAppear>();

	public List<FailuresToAppear> getFailuresToAppearFacts() {
		return failuresToAppearFacts;
	}

	private final List<LicenseActions> licenseActionsFacts = new ArrayList<LicenseActions>();

	public List<LicenseActions> getLicenseActionsFacts() {
		return licenseActionsFacts;
	}

	private java.util.Date effectiveDate;

	public java.util.Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(java.util.Date date) {
		effectiveDate = date;
	}

	public void setAccidentsMVRFacts(List<AccidentsMVR> values) {
		if (values == accidentsMVRFacts)
			return;
		accidentsMVRFacts.clear();
		if (values != null)
			accidentsMVRFacts.addAll(values);
	}

	public void setCitationsAdmittedFacts(List<CitationsAdmitted> values) {
		if (values == citationsAdmittedFacts)
			return;
		citationsAdmittedFacts.clear();
		if (values != null)
			citationsAdmittedFacts.addAll(values);
	}

	public void setCitationsMVRFacts(List<CitationsMVR> values) {
		if (values == citationsMVRFacts)
			return;
		citationsMVRFacts.clear();
		if (values != null)
			citationsMVRFacts.addAll(values);
	}

	public void setSuspensionsAdmittedFacts(List<SuspensionsAdmitted> values) {
		if (values == suspensionsAdmittedFacts)
			return;
		suspensionsAdmittedFacts.clear();
		if (values != null)
			suspensionsAdmittedFacts.addAll(values);
	}

	public void setSuspensionsMVRFacts(List<SuspensionsMVR> values) {
		if (values == suspensionsMVRFacts)
			return;
		suspensionsMVRFacts.clear();
		if (values != null)
			suspensionsMVRFacts.addAll(values);
	}

	public void setFailuresToAppearFacts(List<FailuresToAppear> values) {
		if (values == failuresToAppearFacts)
			return;
		failuresToAppearFacts.clear();
		if (values != null)
			failuresToAppearFacts.addAll(values);
	}

	public void setLicenseActionsFacts(List<LicenseActions> values) {
		if (values == licenseActionsFacts)
			return;
		licenseActionsFacts.clear();
		if (values != null)
			licenseActionsFacts.addAll(values);
	}
}
