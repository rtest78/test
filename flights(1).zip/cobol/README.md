# Flights and AUHN: COBOL batch integration for z/OS

This package contains copybooks, Java mapping wrappers, COBOL HBR callers, batch smoke programs, JCL templates, and local tests. It follows the supplied `example.txt` connection pattern. The implementation uses one combined IN_OUT buffer for each application.

**Status:** local source compilation, mapper checks, buffer layouts and mock HBR calls passed. This is a source workspace. IBM Rule Designer compilation, Flights COBOL importer generation, IBM marshalling, Enterprise COBOL compilation, live rule execution and deployment still require your IBM environment. The Flights model in `Flights-COBOL-XOM` is a hand-written contract model and must be replaced by importer output before deployment. The supplied AUHN generated XOM and marshaller are retained.

## 1. Files to give to the COBOL developers

| File | Purpose |
|---|---|
| `copybooks/FLIGHTOD.cpy` | Flights level-01 buffer; includes FLTIN and FLTOUT |
| `copybooks/FLTIN.cpy` | Flights request fields and 100 input flight legs |
| `copybooks/FLTOUT.cpy` | Flights response fields, 100 routes, 50 cities per route |
| `copybooks/AUODM.cpy` | Eight-character PDS member alias for AUODM-WRAPPER; same bytes and root |
| `copybooks/WUC100.cpy`–`WUC122.cpy` | Existing AUHN record layouts; exact supplied records |
| `copybooks/ODMPATH.cpy` | Caller-supplied ruleset path, X(256) |
| `copybooks/ODMSTAT.cpy` | Application result and diagnostics for all three HBR calls |
| `copybooks/ODMWORK.cpy` | Helper working storage; includes installed IBM HBRC and HBRWS |
| `copybooks/ODMEXEC.cpy` | Shared procedure copybook implementing connection, rule call and disconnect |
| `src/FLTCALL.cbl` | Flights callable subprogram, three arguments |
| `src/AUHNCB.cbl` | AUHN callable subprogram, three arguments |
| `src/FLTBATCH.cbl` | Complete Flights batch smoke program |
| `src/AUHNBAT.cbl` | Complete AUHN batch smoke program |
| `jcl/*.jcl` | Run-step templates with STEPLIB and HBRENVPR |
| `tests/` | Local contract and mock HBR test sources; never install fixture headers on z/OS |

Both application archives contain an identical `cobol/` directory. The Flights archive additionally contains its new Java adapter, contract model, bridge BOM, mapping rules, operation and wrapper flow. The AUHN archive retains its earlier mapping implementation and adds the new batch callers.

For PDS installation, place the new copybooks in members named after their stems: FLIGHTOD, FLTIN, FLTOUT, AUODM, ODMPATH, ODMSTAT, ODMWORK, ODMEXEC, and WUC100–WUC122. The original long filename `AUODM-WRAPPER.cpy` remains in the source workspace for the importer; the new production callers use `COPY AUODM.` because a PDS member name has an eight-character limit. Do not change the level-01 name `AUODM-DECISION-AREA`.

Use fixed source format. Existing WUC copybooks have sequence fields in columns 1–6 and 73–80. New production sources fit within column 72. Transfer text to the mainframe with your site's normal ASCII-to-EBCDIC conversion and FB 80 member conventions. Do not change PIC clauses, insert alignment or use edited numeric pictures.

## 2. How the wrapper works

COBOL owns the combined buffer and keeps its address valid until FLTCALL/AUHNCB returns. The caller registers its address, `LENGTH OF` the entire buffer and the exact ODM parameter name. IBM's generated marshaller converts this buffer to the generated Java COBOL type. The Java mapper creates the existing business request. The existing rules create the existing business response. The mapper writes the response into the same generated COBOL object, and the marshaller returns those bytes to the original COBOL buffer.

There are two distinct wrappers: the physical copybook combines the records; the Java mapper bridges that physical contract to the existing business classes. The COBOL helper manages HBR calls and diagnostics. It does not implement flight selection or underwriting rules.

| Application | Buffer root | Parameter name | Direction | Default smoke path |
|---|---|---|---|---|
| Flights | FLC-DECISION-AREA | flightDecisionArea | IN_OUT | /FlightsDep/FlightsCOBOL |
| AUHN | AUODM-DECISION-AREA | auDecisionArea | IN_OUT | /AUHN_KB_RuleApp/AUHN_KB_Rules |

These are source configuration names, not proof that a ruleset has been deployed. The unversioned paths mirror your supplied connection example. For production, use the exact versioned path from your deployment console: `/RuleApp/version/Ruleset/version`. Do not invent version numbers.

Your example registers two separate request/response parameters. These operations register **one** IN_OUT parameter in slot 1. Slots 2–32 are cleared. Register neither WUC121 by itself nor the old Flights `request`/`response` names for the new operation.

## 3. Flights copybook contract

All Flights numeric fields use unsigned DISPLAY, so the physical buffer contains text digits rather than native binary values. Counts determine which occurrences are active; the full fixed buffer is always passed. COBOL subscripts are one-based and Java array indices are zero-based.

| COBOL field | PIC / capacity | Business mapping |
|---|---|---|
| FLC-FROM-CITY | X(32) | FlightRequest.fromCity |
| FLC-TO-CITY | X(32) | FlightRequest.toCity |
| FLC-SHORTEST | X; Y or N | FlightRequest.shortestRoute |
| FLC-FLIGHT-COUNT | 9(3); 0–100 | Number of active input legs |
| FLC-START-CITY(i) | X(32) | Flight.startCity |
| FLC-STOP-CITY(i) | X(32) | Flight.stopCity |
| FLC-MILES(i) | 9(9) | Flight.miles |
| FLC-ROUTE-COUNT | 9(3); 0–100 | FlightResponse.routes size |
| FLC-CURRENT-CITY(r) | X(32) | Node.currentCity |
| FLC-TOTAL-MILES(r) | 9(10) | Node.totalMiles |
| FLC-CITY-COUNT(r) | 9(2); 1–50 for an active route | Node.visitedCities size |
| FLC-VISITED-CITY(r,c) | X(32) | Node.visitedCities[c-1] |

Y requests the supplied shortest-route behavior. N requests the supplied all-routes behavior. Cities are case-sensitive, with trailing COBOL spaces removed. Leading and internal spaces are retained. Use nonblank printable portable characters; this interface rejects control characters and extended Unicode cities. The 32-character city width and 100/100/50 capacities are newly chosen interface limits, not limits discovered in the original Java app. Change them only as a coordinated contract revision.

Mileage must be nonnegative. A leg must fit PIC 9(9), and the sum of all active leg mileages must be at most 2,147,483,647. This conservative bound protects the original Java `int` cumulative mileage without changing its algorithm. A valid graph may produce more than 100 routes or paths with more than 50 cities; the output mapper rejects such a response instead of silently truncating it. In all-routes mode, a dense graph may require substantial rule execution time before the output capacity check; use an administrator-approved timeout and a representative load test.

An empty response has count zero. The mapper resets every unused output row to spaces and numeric zero, including all city occurrences. Treat output only as valid when ODM-APP-RC is zero. On a mapping/rule failure the buffer can still contain prior output.

| Physical section | Zero-based offset | Length / stride |
|---|---:|---:|
| Request header | 0 | 68 |
| First flight | 68 | 73 per leg × 100 |
| Route count | 7,368 | 3 |
| First route | 7,371 | 1,644 per route × 100 |
| First visited city in first route | 7,415 | 32 per city |
| Last visited city in last route | 171,739 | 32 |
| Complete buffer | 0 | **171,771 bytes** |

## 4. AUHN copybook contract

The existing physical order remains WUC100, WUC101–WUC120, WUC122, then WUC121. The complete area is **164,063 bytes**. WUC121 starts at zero-based offset 163,398 and contains 665 bytes. AUODM.cpy is identical to AUODM-WRAPPER.cpy; it does not add a second record or change this order.

Initialize the entire area before populating each transaction, then move source record fields into the corresponding WUC occurrences. `INITIALIZE AUODM-DECISION-AREA` provides spaces for alphanumeric fields and valid zeros for numeric fields. Do not initialize the entire buffer with LOW-VALUES or move SPACES over numeric data. Do not initialize after populating the request.

WUC101-TRAN-TYPE must be NB or AO. Populate at least the first WUC102 policy and its generation effective date. The smoke example uses generation C and MM/dd/yyyy dates. Active policy generations must precede blank unused rows. Driver/vehicle tables use their existing generation/action and X end markers; MVR tables use blank/XXXXXXXXXX license markers; PACE uses driver zero. Follow `integration/FIELD_MAPPING.md` and the existing mapper documentation for every record's active-row convention.

The existing AUHN Java mapper consumes WUC101–WUC120 and sets FULL execution. WUC100 and WUC122 remain present, but the supplied business loaders do not populate facts from them. This implementation does not establish parity with an unseen legacy AION calling program.

On success, read WUC121-ROUTING-DESTINATION and scan the reasons up to X, a blank unused code, or the 60-entry boundary. Each reason contains a three-character code and four-digit vehicle/driver numbers. All 60 slots may be used, leaving no X slot. The mapper rejects excess reasons and numeric identifiers that do not fit, and validates the response before replacing output. Unspecified identifiers used by the existing rules are 9999. Do not read WUC121 on an HBR or mapping failure.

AUHNBAT supplies only minimal smoke data. It is not an approved underwriting test case or an expected-decision baseline. Production NB/AO cases must populate the real records and be compared to approved results.

## 5. Calling from an existing COBOL batch program

Add the application's buffer, ODMPATH and ODMSTAT to working storage. Populate the buffer and configured path, then make a three-argument CALL by reference.

```cobol
           COPY FLIGHTOD.
           COPY ODMPATH.
           COPY ODMSTAT.
      * PROCEDURE DIVISION, AFTER INITIALIZATION AND POPULATION:
           CALL 'FLTCALL' USING FLC-DECISION-AREA
               ODM-RULESET-PATH ODM-CALL-STATUS
           IF ODM-CALL-OK
               CONTINUE
      *        READ FLC-ROUTE-COUNT AND ACTIVE ROUTES HERE.
           ELSE
               DISPLAY ODM-ERROR-STAGE ' ' ODM-ERROR-MESSAGE
           END-IF
```

For AUHN, use these working-storage copies and call:

```cobol
           COPY AUODM.
           COPY ODMPATH.
           COPY ODMSTAT.
      * PROCEDURE DIVISION, AFTER INITIALIZATION AND POPULATION:
           CALL 'AUHNCB' USING AUODM-DECISION-AREA
               ODM-RULESET-PATH ODM-CALL-STATUS
```

The full runnable examples are FLTBATCH and AUHNBAT. Their main programs return batch RC 0 on accepted success and RC 12 on failure. The helper returns the same RETURN-CODE and also supplies explicit status, so callers need not depend on RETURN-CODE surviving another CALL.

The earlier AUHN helper `integration/AUHN-HBRRULE.cbl` has PROGRAM-ID AUHNCALL and a one-argument interface. It is retained for existing consumers. **New batch code should use AUHNCB with three arguments.** Do not call AUHNCALL with the AUHNCB argument list or switch an old caller without updating its CALL.

### Status and error handling

The helpers accept HBR-CC-OK and HBR-CC-WARNING, matching your example. Warning information is retained rather than erased. After successful/warning connection they attempt disconnect even when rule execution fails. They snapshot rule diagnostics before disconnect can overwrite HBRWS, and a later disconnect failure does not hide an earlier rule failure.

| Status field | Meaning |
|---|---|
| ODM-APP-RC | 000 accepted success; 500 application failure |
| ODM-WARNING | Y if any HBR stage returned an accepted warning |
| ODM-ERROR-STAGE / ODM-ERROR-MESSAGE | Primary failure; first error wins |
| ODM-CONN-CC / RC / MESSAGE | Saved HBRCONN diagnostics |
| ODM-RULE-CC / RC / MESSAGE | Saved HBRRULE diagnostics |
| ODM-DISC-CC / RC / MESSAGE | Saved HBRDISC diagnostics |
| ODM-CONN-CALLED / RULE-CALLED / DISC-CALLED | Y when that call was attempted |
| ODM-RULE-SUCCESS | Y if HBRRULE returned OK or WARNING |
| ODM-API-LOAD-ERROR | Y when an API CALL took its ON EXCEPTION branch |

A blank path fails before connection. If an API module cannot be loaded, the helper returns a named-stage error. Raw CC/RC zeros do not mean success in that case; check ODM-APP-RC and ODM-API-LOAD-ERROR. A rule call may succeed while disconnect fails; that still returns APP-RC 500. Log all stage diagnostics and let the application's existing error paragraph decide recovery. RT900/RT624 structures from your example are not included; map ODMSTAT into your site's own error record if needed.

The helpers are intended for serial batch use. Each helper call connects, executes once and disconnects. For a high-volume production job, the batch/ODM team may later move connection ownership around a transaction loop. Preserve per-request parameter clearing, independent status snapshots and guaranteed cleanup when doing so.

## 6. IBM HBRWS and connection settings

Use **your installed release's** IBM members:

- `HBRHLQ.SHBRCOBC(HBRWS)` defines HBRA-CONN-AREA and its header defaults.
- `HBRHLQ.SHBRCOBC(HBRC)` defines the completion and reason codes.
- `HBRWORKDS.SHBRPARM(HBRBATCH)` holds approved batch connection properties.
- `HBRENVPR DD` points to that HBRBATCH member at execution time.

The helper preserves the IBM header VALUE clauses. It does not initialize the entire HBRWS area and it does not provide a replacement production HBRWS. The files under tests/fixtures deliberately expose only the symbols needed for local tests and must not be copied into a production SYSLIB.

For this standard zRES batch pattern, the COBOL program supplies a ruleset path, while the administrator selects the server through HBRBATCH. A REST URL, HTTP port and embedded credentials are not part of this CALL interface.

| Setting | Where | Site action |
|---|---|---|
| HBRSSIDLIST | HBRBATCH | Supply actual active subsystem IDs in priority order |
| HBRTARGETRES | HBRBATCH | ZRES for the standard zRule Execution Server target used here |
| HBRTIMEOUT | HBRBATCH | Choose an approved timeout for the workload |
| HBRENVPR | Batch JCL | Reference the correct server group's HBRBATCH member |
| SHBRLOAD | STEPLIB / binder setup | Use the load library for the installed ODM release |
| HBRWS / HBRC | Compile SYSLIB | Use headers from that same release |
| Security | Site z/OS administration | Authorize the batch identity for the chosen subsystem and rule execution |
| CCSID / binary conventions | IBM headers, importer and compiler | Verify agreement with the actual caller buffer; retain installed defaults until verified |
| ODM-RULESET-PATH | Application configuration | Supply exact deployed RuleApp/ruleset versions |

The JCL files are templates with explicit YOUR.* placeholders. They have not been submitted. Replace the job card, application load library, ODM installation/work qualifiers and any LE library requirements. Use your installed ODM batch sample's compile/binder procedure; compiler procedure names, API stub binding and library concatenations vary by installation. Compile the new programs in fixed format, with the exact copybook SYSLIB and appropriate dynamic CALL/link conventions. Place FLTCALL/AUHNCB in the application load library and make all HBR client load modules available using that sample's settings. These programs are batch code and contain no EXEC CICS or IMS calls.

## 7. ODM developer tasks for Flights

1. Import the five projects: Flights-XOM, Flights-BOM, Flights, Flights-COBOL-XOM and Flights-COBOL-Adapter. Keep the original Java source and original 14 Flights BRLs.
2. In the installed COBOL importer, import **FLIGHTOD.cpy**, with FLTIN.cpy and FLTOUT.cpy on its COPY search path. Select project Flights-COBOL-XOM and package `com.techsavants.flights.cobol`. Import the physical copybook; do not generate a physical layout from the minimal bridge BOM.
3. Replace the hand-written contract classes with importer-generated classes. The mapper currently expects `Flc_decision_area`, `Flc_flight`, `Flc_route` and `Flc_route_city`, underscore property names, short counts, int leg miles, long route miles and fixed occurrence arrays. Compare against the actual generated API. If the importer uses different names/types, adapt the mapper and variable/BOM type to that generated API. Do not retain duplicate class definitions.
4. Generate and include the IBM COBOL marshalling configuration and marshaller JAR. None is fabricated in this package. Select the target release and CCSID that agree with the z/OS application. Verify total size 171,771 and the table strides above in the generated metadata.
5. Build Flights-COBOL-Adapter against the **actual generated** XOM. The rule project now includes both COBOL XOM and adapter XOM path entries plus the bridge BOM. Regenerate/refresh the bridge BOM from the actual classes if required by the installed release, retaining its two mapping phrases and avoiding duplicate BOM types.
6. Verify `flightDecisionArea` is the sole exposed FlightsCOBOL parameter, type `com.techsavants.flights.cobol.Flc_decision_area`, direction IN_OUT. Verify wrapper flow `FindFlightRoutesCOBOL`: map input, invoke original `FindFlightRoutes` as a subflow, map output. The input mapping resets internal request/response/context/search variables for each execution.
7. Keep the original operation `Flights` with request IN and response OUT for existing Java callers. The original flow and original BRLs are unchanged. FlightsDep now also lists the new FlightsCOBOL operation.
8. Clean/build in Rule Designer and resolve all Problems view errors. Structural XML checks and Java compilation here do not prove BAL/BOM or ruleset compilation.
9. Deploy FlightsDep with the business XOM, generated COBOL XOM, adapter, generated marshaller and configuration attached as required by your installed version. Verify the RES parameter metadata and record the exact path. This archive itself is not a deployable RuleApp archive.

## 8. ODM developer tasks for AUHN

1. Import AUHN-XOM, AUHN-BOM, AUHN-Rules, AUHN-COBOL-XOM and AUHN-COBOL-Adapter. Retain the supplied generated COBOL classes and marshaller for the unchanged physical layout.
2. The archive now explicitly includes AUHN-COBOL-Adapter on the rule project's XOM path and AUHN-COBOL-Bridge on its BOM path. Clean/build and verify these entries resolve in your workspace.
3. Verify auDecisionArea IN_OUT in AUHN_KB_Rules. Its flow already maps COBOL input, runs the existing underwriting flow and maps AuhnResponse into WUC121. Existing Java request/response clients need the earlier contract version or a separate operation; the AUHN source operation was changed in the earlier migration.
4. Verify runtime packaging includes AUHN-XOM, generated AUHN-COBOL-XOM, AUHN-COBOL-Adapter and the supplied/generated matching marshaller and configuration. Deploy a new ruleset version and record its exact path.
5. Compare representative NB and AO decisions, all referral rows and identifiers against approved business baselines. The local tests check mapping and supplied-loader parity, not underwriting equivalence to unseen AION execution.

## 9. Verification and release acceptance

`TEST_REPORT.md` records the checks performed here. With GnuCOBOL and a JDK installed, run from the extracted Flights archive root:

```bash
bash cobol/tests/run-tests.sh
```

To run the common suite stored in the AUHN archive, also extract the Flights archive and set `FLIGHTS_PROJECT_ROOT` to its absolute project root. `COBC_BIN` and `ODM_TEST_BUILD` can point to local compiler/build locations. Local tests deliberately use ASCII byte fixtures and mock HBR modules. They do not verify EBCDIC encoding, IBM marshalling or HBR server connectivity. The earlier AUHN suite remains available as `bash integration/cobol-tests/run-tests.sh`.

Before release, the COBOL and ODM teams must jointly complete:

1. Enterprise COBOL compile and binder checks with real HBRWS/HBRC.
2. IBM-generated Flights XOM and marshaller verification, including full fixed occurrence arrays and CCSID handling.
3. IBM Rule Designer build and deployed ruleset metadata/classloader checks for both applications.
4. A real z/OS HBRRULE round trip. Flights smoke input A→B 100, B→C 200, A→C 500 should return the original rules' shortest route A,B,C with total 300; N mode should return both paths. Confirm no-route, same-origin/destination, cycle, equal-mileage and capacity-error behavior against the original Java operation. These are expected acceptance cases, not results of a live run here.
5. Representative AUHN NB/AO parity checks, including no reasons, multiple reasons, 60 reasons, malformed dates, sentinel handling and mapping errors.
6. Negative connection/path/security/timeout tests. Ensure the application rejects failed output and logs the retained stage diagnostics.

## 10. Sources

The application structures and algorithm are taken from the supplied Flights archive; the connection/OK-or-WARNING handling pattern is taken from the supplied example.txt. AUHN uses the current supplied migration workspace and its unchanged physical contract.

- IBM HBR APIs and installed copybook locations: https://www.ibm.com/docs/en/odm/8.12.0?topic=reference-apis
- IBM completion and reason codes: https://www.ibm.com/docs/en/drfz/9.1.0?topic=reference-completion-reason-codes
- IBM batch runtime settings: https://www.ibm.com/docs/en/drfz/9.5.0?topic=manager-zos-runtime-variables
- IBM COBOL XOM and deployment overview: https://www.ibm.com/docs/en/odm/9.0.0?topic=models-overview-bom-execution-object-model-xom
- IBM generated COBOL XOM/configuration/marshaller workflow: https://www.redbooks.ibm.com/redbooks/pdfs/sg248014.pdf (chapter 3)

The installed release's headers, generated metadata and batch sample are authoritative for the final ABI and runtime configuration.
