package com.techsavants;


import java.util.ArrayList;
import java.util.List;

public class FlightResponse {

    private List<Node> routes = new ArrayList<Node>();

    public FlightResponse() {
    }

    public List<Node> getRoutes() {
        return routes;
    }

    public void setRoutes(List<Node> routes) {
        this.routes = routes;
    }
}
