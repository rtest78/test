package com.techsavants.auhn.kb;
public class VehicleData {
    private String vCar_Group;
    public String getVCar_Group() { return vCar_Group; }
    public void setVCar_Group(String value) { vCar_Group = value; }
    private String vCycle_License_Ind;
    public String getVCycle_License_Ind() { return vCycle_License_Ind; }
    public void setVCycle_License_Ind(String value) { vCycle_License_Ind = value; }
    private Integer vLimit_of_Liability;
    public Integer getVLimit_of_Liability() { return vLimit_of_Liability; }
    public void setVLimit_of_Liability(Integer value) { vLimit_of_Liability = value; }
    private String vLoad_Capacity;
    public String getVLoad_Capacity() { return vLoad_Capacity; }
    public void setVLoad_Capacity(String value) { vLoad_Capacity = value; }
    private Integer vPurchase_Price;
    public Integer getVPurchase_Price() { return vPurchase_Price; }
    public void setVPurchase_Price(Integer value) { vPurchase_Price = value; }
    private java.util.Date vReg_Own_DOB;
    public java.util.Date getVReg_Own_DOB() { return vReg_Own_DOB; }
    public void setVReg_Own_DOB(java.util.Date value) { vReg_Own_DOB = value; }
    private String vReg_Own_Relationship;
    public String getVReg_Own_Relationship() { return vReg_Own_Relationship; }
    public void setVReg_Own_Relationship(String value) { vReg_Own_Relationship = value; }
    private String vSequence_Number;
    public String getVSequence_Number() { return vSequence_Number; }
    public void setVSequence_Number(String value) { vSequence_Number = value; }
    private String vSymbol;
    public String getVSymbol() { return vSymbol; }
    public void setVSymbol(String value) { vSymbol = value; }
    private String vTrade_Name;
    public String getVTrade_Name() { return vTrade_Name; }
    public void setVTrade_Name(String value) { vTrade_Name = value; }
    private String vUse;
    public String getVUse() { return vUse; }
    public void setVUse(String value) { vUse = value; }
    private String vVehicle_Number;
    public String getVVehicle_Number() { return vVehicle_Number; }
    public void setVVehicle_Number(String value) { vVehicle_Number = value; }
    private String vVINN;
    public String getVVINN() { return vVINN; }
    public void setVVINN(String value) { vVINN = value; }
    private Integer vYear;
    public Integer getVYear() { return vYear; }
    public void setVYear(Integer value) { vYear = value; }
    private String vParkedLocation;
    public String getVParkedLocation() { return vParkedLocation; }
    public void setVParkedLocation(String value) { vParkedLocation = value; }
    private String vAntiTheftCode;
    public String getVAntiTheftCode() { return vAntiTheftCode; }
    public void setVAntiTheftCode(String value) { vAntiTheftCode = value; }
    private java.util.Date vPurchaseDate;
    public java.util.Date getVPurchaseDate() { return vPurchaseDate; }
    public void setVPurchaseDate(java.util.Date value) { vPurchaseDate = value; }
    private String vEVRCode;
    public String getVEVRCode() { return vEVRCode; }
    public void setVEVRCode(String value) { vEVRCode = value; }
    private String vBody_Type;
    public String getVBody_Type() { return vBody_Type; }
    public void setVBody_Type(String value) { vBody_Type = value; }
    private String vMiles_Calc_Mth;
    public String getVMiles_Calc_Mth() { return vMiles_Calc_Mth; }
    public void setVMiles_Calc_Mth(String value) { vMiles_Calc_Mth = value; }
    private String vAnnual_Miles_Code;
    public String getVAnnual_Miles_Code() { return vAnnual_Miles_Code; }
    public void setVAnnual_Miles_Code(String value) { vAnnual_Miles_Code = value; }
    private String vPri_Rated_Drv;
    public String getVPri_Rated_Drv() { return vPri_Rated_Drv; }
    public void setVPri_Rated_Drv(String value) { vPri_Rated_Drv = value; }
    private String vElim_Reason_Cd;
    public String getVElim_Reason_Cd() { return vElim_Reason_Cd; }
    public void setVElim_Reason_Cd(String value) { vElim_Reason_Cd = value; }
    private Integer vAnnual_Mileage;
    public Integer getVAnnual_Mileage() { return vAnnual_Mileage; }
    public void setVAnnual_Mileage(Integer value) { vAnnual_Mileage = value; }
    private String vVndr_Milg_Src;
    public String getVVndr_Milg_Src() { return vVndr_Milg_Src; }
    public void setVVndr_Milg_Src(String value) { vVndr_Milg_Src = value; }
    private String vStorage_Ind;
    public String getVStorage_Ind() { return vStorage_Ind; }
    public void setVStorage_Ind(String value) { vStorage_Ind = value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction=value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
}
