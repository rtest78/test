000100******************************************************************00010000
000200* WUC122 - TRANSACTION DATA COBOL II RECORD LAYOUT.              *00020000
000300******************************************************************00030000
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00040000
000500* TRANSACTION DATA TO BE PASSED TO WUS104.                       *00050000
000600*                                                                *00060000
000700******************************************************************00070000
000800*01 WUC122-POL-MISC.                                              00080000
000900                                                                  00090000
001000   05 WUC122-POL-CAC-EXISTS                PIC  X(01).            00100010
001000   05 WUC122-POL-CAU-EXISTS                PIC  X(01).            00100020
000045   05 WUC122-POL-JWL-HUON-PRM-DISCR        PIC  X(01).            00100100
001000   05 WUC122-POL-PRV-AGENT                 PIC  X(09).            00110200
001000   05 WUC122-POL-CUR-AGENT                 PIC  X(09).            00110300
001000   05 WUC122-FILLER                        PIC  X(29).            00110400
