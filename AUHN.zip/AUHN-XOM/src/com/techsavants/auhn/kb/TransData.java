package com.techsavants.auhn.kb;
public class TransData {
    private String vTransType;
    public String getVTransType() { return vTransType; }
    public void setVTransType(String value) { vTransType = value; }
    private String vClubCode;
    public String getVClubCode() { return vClubCode; }
    public void setVClubCode(String value) { vClubCode = value; }
    private String vProduct;
    public String getVProduct() { return vProduct; }
    public void setVProduct(String value) { vProduct = value; }
}
