package com.aaa.auhn.kb;
public class MVR3Data {
    private String vLicense_Number;
    public String getVLicense_Number() { return vLicense_Number; }
    public void setVLicense_Number(String value) { vLicense_Number = value; }
    private Integer vSequence_Number;
    public Integer getVSequence_Number() { return vSequence_Number; }
    public void setVSequence_Number(Integer value) { vSequence_Number = value; }
    private String vCategory;
    public String getVCategory() { return vCategory; }
    public void setVCategory(String value) { vCategory = value; }
    private String vDescription;
    public String getVDescription() { return vDescription; }
    public void setVDescription(String value) { vDescription = value; }
    private Integer vGood_Driver_Pts;
    public Integer getVGood_Driver_Pts() { return vGood_Driver_Pts; }
    public void setVGood_Driver_Pts(Integer value) { vGood_Driver_Pts = value; }
    private String vSurcharge;
    public String getVSurcharge() { return vSurcharge; }
    public void setVSurcharge(String value) { vSurcharge = value; }
}
