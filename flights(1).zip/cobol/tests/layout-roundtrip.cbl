       >>SOURCE FORMAT FREE
identification division.
program-id. FLTLAYOUT.
environment division.
input-output section.
file-control.
    select area-file assign to 'flights-input.bin'
      organization sequential access sequential file status io-status.
    select result-file assign to 'flights-output.bin'
      organization sequential access sequential file status io-status.
data division.
file section.
fd area-file recording mode F.
01 area-record pic x(171771).
fd result-file recording mode F.
01 result-record pic x(171771).
working-storage section.
       >>SOURCE FORMAT FIXED
           COPY FLIGHTOD.
       >>SOURCE FORMAT FREE
01 io-status pic xx.
01 mode-name pic x(16).
01 ptr-base usage pointer.
01 numeric-base redefines ptr-base pic 9(18) comp-5.
01 ptr-field usage pointer.
01 numeric-field redefines ptr-field pic 9(18) comp-5.
01 offset-value pic 9(9) comp-5.
01 errors binary-long value 0.
procedure division.
main.
    accept mode-name from command-line
    if length of FLC-DECISION-AREA not = 171771
        add 1 to errors end-if
    set ptr-base to address of FLC-DECISION-AREA
    set ptr-field to address of FLC-FLIGHT(1)
    compute offset-value = numeric-field - numeric-base
    if offset-value not = 68 add 1 to errors end-if
    set ptr-field to address of FLC-FLIGHT(2)
    compute offset-value = numeric-field - numeric-base
    if offset-value not = 141 add 1 to errors end-if
    set ptr-field to address of FLC-ROUTE-COUNT
    compute offset-value = numeric-field - numeric-base
    if offset-value not = 7368 add 1 to errors end-if
    set ptr-field to address of FLC-ROUTE(1)
    compute offset-value = numeric-field - numeric-base
    if offset-value not = 7371 add 1 to errors end-if
    set ptr-field to address of FLC-ROUTE(2)
    compute offset-value = numeric-field - numeric-base
    if offset-value not = 9015 add 1 to errors end-if
    set ptr-field to address of FLC-VISITED-CITY(1,1)
    compute offset-value = numeric-field - numeric-base
    if offset-value not = 7415 add 1 to errors end-if
    set ptr-field to address of FLC-VISITED-CITY(100,50)
    compute offset-value = numeric-field - numeric-base
    if offset-value not = 171739 add 1 to errors end-if
    if mode-name = 'write'
        initialize FLC-DECISION-AREA
        move 'A' to FLC-FROM-CITY FLC-START-CITY(1)
        move 'C' to FLC-TO-CITY
        move 'B' to FLC-STOP-CITY(1)
        move 'Y' to FLC-SHORTEST
        move 1 to FLC-FLIGHT-COUNT
        move 100 to FLC-MILES(1)
        open output area-file
        if io-status not = '00' move 12 to return-code goback end-if
        move FLC-DECISION-AREA to area-record
        write area-record
        if io-status not = '00' add 1 to errors end-if
        close area-file
    else
        open input result-file
        if io-status not = '00' move 12 to return-code goback end-if
        read result-file
        if io-status not = '00' add 1 to errors end-if
        move result-record to FLC-DECISION-AREA
        close result-file
        if FLC-ROUTE-COUNT not = 1 or FLC-CITY-COUNT(1) not = 3
           or FLC-TOTAL-MILES(1) not = 300
           or FLC-CURRENT-CITY(1) not = 'C'
           or FLC-VISITED-CITY(1,1) not = 'A'
           or FLC-VISITED-CITY(1,2) not = 'B'
           or FLC-VISITED-CITY(1,3) not = 'C'
           or FLC-ROUTE-COUNT not numeric
           or FLC-CITY-COUNT(100) not = 0
           or FLC-TOTAL-MILES(100) not = 0
           or FLC-VISITED-CITY(100,50) not = spaces
            add 1 to errors
        end-if
    end-if
    if errors not = 0
        display 'LAYOUT/ROUNDTRIP FAILURES: ' errors
        move 12 to return-code
    else
        display 'PASS: Flights byte layout and ' mode-name
        move 0 to return-code
    end-if
    goback.
