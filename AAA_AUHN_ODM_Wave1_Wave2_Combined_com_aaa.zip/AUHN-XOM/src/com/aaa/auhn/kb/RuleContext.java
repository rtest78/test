package com.aaa.auhn.kb;
import java.util.*;
import static com.aaa.auhn.kb.SourceFacts.*;
public class RuleContext {
    private String routingDestination;
    private String transactionType;
    private final List<Referral> results = new ArrayList<Referral>();
    public String getRoutingDestination() { return routingDestination; }
    public void setRoutingDestination(String value) { routingDestination=value; }
    public String getTransactionType() { return transactionType; }
    public void setTransactionType(String value) { transactionType=value; }
    public List<Referral> getResults() { return results; }
    public void record(String code, String driver, String vehicle, String destination, boolean routing) { results.add(new Referral(code,driver==null?"9999":driver,vehicle==null?"9999":vehicle)); if(routing) routingDestination=destination; }
    public void completeNoReferral() { if(routingDestination==null) record("010",null,null,"NB".equals(transactionType)?"PDS":"PAO",true); }
    public void deduplicate() { LinkedHashMap<List<String>,Referral> unique=new LinkedHashMap<List<String>,Referral>(); for(Referral r:results) { List<String> k=Arrays.asList(r.getCode(),r.getDriver(),r.getVehicle()); if(!unique.containsKey(k)) unique.put(k,r); } results.clear(); results.addAll(unique.values()); }
    public void validatePrepared() { if(!"NB".equals(transactionType) && !"AO".equals(transactionType)) throw new IllegalArgumentException("AUHN transaction type must be NB or AO"); }
    private final List<AccidentData> accidentDataFacts = new ArrayList<AccidentData>();
    public List<AccidentData> getAccidentDataFacts() { return accidentDataFacts; }
    private final List<AccidentsAdmitted> accidentsAdmittedFacts = new ArrayList<AccidentsAdmitted>();
    public List<AccidentsAdmitted> getAccidentsAdmittedFacts() { return accidentsAdmittedFacts; }
    private final List<AccidentsPACE> accidentsPACEFacts = new ArrayList<AccidentsPACE>();
    public List<AccidentsPACE> getAccidentsPACEFacts() { return accidentsPACEFacts; }
    private final List<ApplicationData> applicationDataFacts = new ArrayList<ApplicationData>();
    public List<ApplicationData> getApplicationDataFacts() { return applicationDataFacts; }
    private final List<CitationData> citationDataFacts = new ArrayList<CitationData>();
    public List<CitationData> getCitationDataFacts() { return citationDataFacts; }
    private final List<Citations> citationsFacts = new ArrayList<Citations>();
    public List<Citations> getCitationsFacts() { return citationsFacts; }
    private final List<CoverageData> coverageDataFacts = new ArrayList<CoverageData>();
    public List<CoverageData> getCoverageDataFacts() { return coverageDataFacts; }
    private final List<Coverages> coveragesFacts = new ArrayList<Coverages>();
    public List<Coverages> getCoveragesFacts() { return coveragesFacts; }
    private final List<DriverData> driverDataFacts = new ArrayList<DriverData>();
    public List<DriverData> getDriverDataFacts() { return driverDataFacts; }
    private final List<DriverOfVehicleData> driverOfVehicleDataFacts = new ArrayList<DriverOfVehicleData>();
    public List<DriverOfVehicleData> getDriverOfVehicleDataFacts() { return driverOfVehicleDataFacts; }
    private final List<Drivers> driversFacts = new ArrayList<Drivers>();
    public List<Drivers> getDriversFacts() { return driversFacts; }
    private final List<DriversMVRInfo> driversMVRInfoFacts = new ArrayList<DriversMVRInfo>();
    public List<DriversMVRInfo> getDriversMVRInfoFacts() { return driversMVRInfoFacts; }
    private final List<DriversOfVehicles> driversOfVehiclesFacts = new ArrayList<DriversOfVehicles>();
    public List<DriversOfVehicles> getDriversOfVehiclesFacts() { return driversOfVehiclesFacts; }
    private final List<EmploymentData> employmentDataFacts = new ArrayList<EmploymentData>();
    public List<EmploymentData> getEmploymentDataFacts() { return employmentDataFacts; }
    private final List<EndorsementData> endorsementDataFacts = new ArrayList<EndorsementData>();
    public List<EndorsementData> getEndorsementDataFacts() { return endorsementDataFacts; }
    private final List<Endorsements> endorsementsFacts = new ArrayList<Endorsements>();
    public List<Endorsements> getEndorsementsFacts() { return endorsementsFacts; }
    private final List<InspectionData> inspectionDataFacts = new ArrayList<InspectionData>();
    public List<InspectionData> getInspectionDataFacts() { return inspectionDataFacts; }
    private final List<Inspections> inspectionsFacts = new ArrayList<Inspections>();
    public List<Inspections> getInspectionsFacts() { return inspectionsFacts; }
    private final List<MVR1Data> mVR1DataFacts = new ArrayList<MVR1Data>();
    public List<MVR1Data> getMVR1DataFacts() { return mVR1DataFacts; }
    private final List<MVR2Data> mVR2DataFacts = new ArrayList<MVR2Data>();
    public List<MVR2Data> getMVR2DataFacts() { return mVR2DataFacts; }
    private final List<MVR3Data> mVR3DataFacts = new ArrayList<MVR3Data>();
    public List<MVR3Data> getMVR3DataFacts() { return mVR3DataFacts; }
    private final List<MVR4Data> mVR4DataFacts = new ArrayList<MVR4Data>();
    public List<MVR4Data> getMVR4DataFacts() { return mVR4DataFacts; }
    private final List<MVR5Data> mVR5DataFacts = new ArrayList<MVR5Data>();
    public List<MVR5Data> getMVR5DataFacts() { return mVR5DataFacts; }
    private final List<MVR6Data> mVR6DataFacts = new ArrayList<MVR6Data>();
    public List<MVR6Data> getMVR6DataFacts() { return mVR6DataFacts; }
    private final List<MVRHierarchy> mVRHierarchyFacts = new ArrayList<MVRHierarchy>();
    public List<MVRHierarchy> getMVRHierarchyFacts() { return mVRHierarchyFacts; }
    private final List<Occupations> occupationsFacts = new ArrayList<Occupations>();
    public List<Occupations> getOccupationsFacts() { return occupationsFacts; }
    private final List<PACEData> pACEDataFacts = new ArrayList<PACEData>();
    public List<PACEData> getPACEDataFacts() { return pACEDataFacts; }
    private final List<Policies> policiesFacts = new ArrayList<Policies>();
    public List<Policies> getPoliciesFacts() { return policiesFacts; }
    private final List<PolicyCodeData> policyCodeDataFacts = new ArrayList<PolicyCodeData>();
    public List<PolicyCodeData> getPolicyCodeDataFacts() { return policyCodeDataFacts; }
    private final List<PolicyCodes> policyCodesFacts = new ArrayList<PolicyCodes>();
    public List<PolicyCodes> getPolicyCodesFacts() { return policyCodesFacts; }
    private final List<PolicyData> policyDataFacts = new ArrayList<PolicyData>();
    public List<PolicyData> getPolicyDataFacts() { return policyDataFacts; }
    private final List<SuspensionData> suspensionDataFacts = new ArrayList<SuspensionData>();
    public List<SuspensionData> getSuspensionDataFacts() { return suspensionDataFacts; }
    private final List<TransData> transDataFacts = new ArrayList<TransData>();
    public List<TransData> getTransDataFacts() { return transDataFacts; }
    private final List<VehicleData> vehicleDataFacts = new ArrayList<VehicleData>();
    public List<VehicleData> getVehicleDataFacts() { return vehicleDataFacts; }
    private final List<Vehicles> vehiclesFacts = new ArrayList<Vehicles>();
    public List<Vehicles> getVehiclesFacts() { return vehiclesFacts; }
    public List<?> activityList(String name) {
        if("AccidentsAdmitted".equals(name))return accidentsAdmittedFacts;
        if("AccidentsPACE".equals(name))return accidentsPACEFacts;
        if("AccidentsMVR".equals(name))return accidentsMVRFacts;
        if("CitationsAdmitted".equals(name))return citationsAdmittedFacts;
        if("CitationsMVR".equals(name))return citationsMVRFacts;
        if("SuspensionsAdmitted".equals(name))return suspensionsAdmittedFacts;
        if("SuspensionsMVR".equals(name))return suspensionsMVRFacts;
        if("FailuresToAppear".equals(name))return failuresToAppearFacts;
        if("LicenseActions".equals(name))return licenseActionsFacts;
        throw new IllegalArgumentException("Unknown source activity class: "+name);
    }
    public Boolean queryAccidentsAdmittedAllActivitiesMatch2(String driver,String other) { return allActivitiesMatch(accidentsAdmittedFacts,activityList(other),driver); }
    public Integer queryAccidentsAdmittedGetDriverLossTypeCount2(AccidentsAdmitted unused,String driver,String loss) {
        int count=0;
        if("NC".equals(loss))for(AccidentsAdmitted a:accidentsAdmittedFacts)if(eq(driver,a.getVDriverNumber()) && !Arrays.asList("PD","BI").contains(text(a,"LossType")) && flag(a,"IsWithinExperiencePeriod"))count++;
        return count;
    }
    public Integer queryAccidentsAdmittedNumActivitiesForDriver2(String driver,Boolean countable) { return countActivities(accidentsAdmittedFacts,driver,false,Boolean.TRUE.equals(countable)); }
    public Integer queryAccidentsAdmittedNumActivitiesOnPolicy1(Boolean countable) { return countActivities(accidentsAdmittedFacts,null,true,Boolean.TRUE.equals(countable)); }
    public Boolean queryAccidentsPACEAllActivitiesMatch2(String driver,String other) { return allActivitiesMatch(accidentsPACEFacts,activityList(other),driver); }
    public Boolean queryAccidentsPACEAnyNonMatchActivity2(String driver,String other) { return noExactActivityMatch(accidentsPACEFacts,activityList(other),driver); }
    public Integer queryAccidentsPACENumActivitiesForDriver2(String driver,Boolean countable) { return countActivities(accidentsPACEFacts,driver,false,Boolean.TRUE.equals(countable)); }
    public Integer queryAccidentsPACENumActivitiesOnPolicy1(Boolean countable) { return countActivities(accidentsPACEFacts,null,true,Boolean.TRUE.equals(countable)); }
    public Boolean queryCitationsAdmittedAllActivitiesMatch2(String driver,String other) { return allActivitiesMatch(citationsAdmittedFacts,activityList(other),driver); }
    public Boolean queryCitationsAdmittedMatchEachCategory2(String driver,String other) { return matchCategories(citationsAdmittedFacts,activityList(other),driver); }
    public Integer queryCitationsAdmittedNumActivitiesForDriver2(String driver,Boolean countable) { return countActivities(citationsAdmittedFacts,driver,false,Boolean.TRUE.equals(countable)); }
    public Boolean queryDriversExistsDriverWithCode1(String code) { for(Drivers d:driversFacts)if(eq(code,d.getVDriverCode()))return true;return false; }
    private int driverCodes(String...codes) { int n=0;for(Drivers d:driversFacts)if(flag(d,"IsCurrentInfo") && Arrays.asList(codes).contains(d.getVDriverCode()))n++;return n; }
    public Integer queryDriversGetDDriverCount() { return driverCodes("D"); }
    public Integer queryDriversGetDandTDriverCount() { return driverCodes("D","T"); }
    public Integer queryDriversGetValidDriverCount() { int n=0;for(Drivers d:driversFacts)if(flag(d,"IsCurrentInfo") && (d.getVMVRInfo()==null || flag(d.getVMVRInfo(),"HasValidLicense")))n++;return n; }
    public java.util.List<String> queryDriversOfVehiclesVehiclesDriverIsPrimary1(String driver) {
        List<String> result=null;
        for(DriversOfVehicles d:driversOfVehiclesFacts)if(flag(d,"IsCurrentInfo") && flag(d,"PrimaryDriverFlag") && eq(driver,d.getVDriverNumber())) {if(result==null)result=new ArrayList<String>();result.add(d.getVVehicleNumber());}
        return result;
    }
    public Integer queryEndorsementsGetExcludedEndAddCount() { int n=0;for(Endorsements e:endorsementsFacts)if(flag(e,"IsAddedOrNew") && "2184".equals(e.getVEndorsementNumber()))n++;return n; }
    public java.util.Date queryGlobalInfoGetEffectiveDate() {
        if(effectiveDate!=null)return effectiveDate;
        if(!policyDataFacts.isEmpty())return date(policyDataFacts.get(0),"Gen_Eff_Date");
        if(!policiesFacts.isEmpty())return date(policiesFacts.get(0),"EffectiveDate");
        throw new IllegalStateException("An effective date is required");
    }
    public String queryGlobalInfoGetTypeOfTrans() { return transactionType; }
    public Boolean querySuspensionsAdmittedAllActivitiesMatch2(String driver,String other) { return allActivitiesMatch(suspensionsAdmittedFacts,activityList(other),driver); }
    public Integer querySuspensionsAdmittedNumActivitiesForDriver2(String driver,Boolean countable) { return countActivities(suspensionsAdmittedFacts,driver,false,Boolean.TRUE.equals(countable)); }
    public Boolean queryVehiclesGetAllAreMotorcycles() { boolean any=false;for(Vehicles v:vehiclesFacts)if(flag(v,"IsCurrentInfo")){any=true;if(!"MCYC".equals(text(v,"CarGroup")))return false;}return any; }
    public Integer queryVehiclesGetPassengerCarCount() { int n=0;for(Vehicles v:vehiclesFacts)if(flag(v,"IsCurrentInfo") && Arrays.asList("REGL","REGU","DBUG","CCAR","KIT","CUST","NISO").contains(text(v,"CarGroup")))n++;return n; }
    public void prepareBusinessObjects() { new SourcePreparation(this).populate(); }

    private String executionPhase="FULL";
    public String getExecutionPhase(){return executionPhase;}
    public void setExecutionPhase(String value){executionPhase=value;}
    public void resetVehicleFlags(){for(Vehicles v:vehiclesFacts)v.setVHasNonGoodDriver(false);}
    private int mvrDriverIndex;
    private final List<MVRHierarchy> currentMvrTopics=new ArrayList<MVRHierarchy>();
    public boolean getHasMoreMvrDrivers(){return mvrDriverIndex<mVR1DataFacts.size();}
    private MVRHierarchy topic(String license,Integer sequence,Object record){
        if(sequence==null)throw new IllegalArgumentException("MVR sequence number is required");
        MVRHierarchy h=new MVRHierarchy();h.setVLicenseNumber(license);h.setVSequenceNumber(sequence);h.setTopicRecord(record);h.setVProcessed(false);mVRHierarchyFacts.add(h);currentMvrTopics.add(h);return h;
    }
    private void assignWindows(){
        Collections.sort(currentMvrTopics,new Comparator<MVRHierarchy>(){public int compare(MVRHierarchy x,MVRHierarchy y){return x.getVSequenceNumber().compareTo(y.getVSequenceNumber());}});
        for(int i=0;i<currentMvrTopics.size()-1;i++)currentMvrTopics.get(i).setVNextSequenceNumber(currentMvrTopics.get(i+1).getVSequenceNumber());
    }
    public void preparePrimaryMvrTopics(){
        if(mvrDriverIndex==0)mVRHierarchyFacts.clear();currentMvrTopics.clear();
        if(!getHasMoreMvrDrivers())return;
        String license=mVR1DataFacts.get(mvrDriverIndex).getVLicense_Number();
        for(MVR2Data d:mVR2DataFacts)if(eq(license,d.getVLicense_Number()))topic(license,d.getVSequence_Number(),d);
        for(MVR5Data d:mVR5DataFacts)if(eq(license,d.getVLicense_Number()))topic(license,d.getVSequence_Number(),d);
        assignWindows();
    }
    public void prepareSecondaryMvrTopics(){
        if(!getHasMoreMvrDrivers())return;
        String license=mVR1DataFacts.get(mvrDriverIndex).getVLicense_Number();
        for(MVR3Data d:mVR3DataFacts)if(eq(license,d.getVLicense_Number()))topic(license,d.getVSequence_Number(),d);
        for(MVR6Data d:mVR6DataFacts)if(eq(license,d.getVLicense_Number()))topic(license,d.getVSequence_Number(),d);
        assignWindows();
    }
    public void markMvrProcessed(){for(MVRHierarchy h:currentMvrTopics)h.setVProcessed(true);mvrDriverIndex++;}
    // Generic collection methods accept fact lists and arguments from BAL.
    public int countWhere(java.util.List facts, String property, Object expected) { return AuhnCollections.countWhere(facts, property, expected); }
    public boolean anyWhere(java.util.List facts, String property, Object expected) { return AuhnCollections.anyWhere(facts, property, expected); }
    public boolean allWhere(java.util.List facts, String property, Object expected) { return AuhnCollections.allWhere(facts, property, expected); }
    public java.util.List<String> projectStrings(java.util.List facts, String property) { return AuhnCollections.projectStrings(facts, property); }
    public boolean containsValue(java.util.List values, Object expected) { return AuhnCollections.contains(values, expected); }
    public java.util.List<Object> distinctValues(java.util.List values) { return AuhnCollections.distinct(values); }

public static RuleContext fromRequest(AuhnRequest request){
if(request==null) throw new IllegalArgumentException("AUHN request is required");
RuleContext c=new RuleContext();
c.setTransactionType(request.getTransactionType());
c.setExecutionPhase(request.getExecutionPhase());
c.setEffectiveDate(request.getEffectiveDate());
c.accidentDataFacts.addAll(request.getAccidentDataFacts());
c.accidentsAdmittedFacts.addAll(request.getAccidentsAdmittedFacts());
c.accidentsPACEFacts.addAll(request.getAccidentsPACEFacts());
c.applicationDataFacts.addAll(request.getApplicationDataFacts());
c.citationDataFacts.addAll(request.getCitationDataFacts());
c.citationsFacts.addAll(request.getCitationsFacts());
c.coverageDataFacts.addAll(request.getCoverageDataFacts());
c.coveragesFacts.addAll(request.getCoveragesFacts());
c.driverDataFacts.addAll(request.getDriverDataFacts());
c.driverOfVehicleDataFacts.addAll(request.getDriverOfVehicleDataFacts());
c.driversFacts.addAll(request.getDriversFacts());
c.driversMVRInfoFacts.addAll(request.getDriversMVRInfoFacts());
c.driversOfVehiclesFacts.addAll(request.getDriversOfVehiclesFacts());
c.employmentDataFacts.addAll(request.getEmploymentDataFacts());
c.endorsementDataFacts.addAll(request.getEndorsementDataFacts());
c.endorsementsFacts.addAll(request.getEndorsementsFacts());
c.inspectionDataFacts.addAll(request.getInspectionDataFacts());
c.inspectionsFacts.addAll(request.getInspectionsFacts());
c.mVR1DataFacts.addAll(request.getMVR1DataFacts());
c.mVR2DataFacts.addAll(request.getMVR2DataFacts());
c.mVR3DataFacts.addAll(request.getMVR3DataFacts());
c.mVR4DataFacts.addAll(request.getMVR4DataFacts());
c.mVR5DataFacts.addAll(request.getMVR5DataFacts());
c.mVR6DataFacts.addAll(request.getMVR6DataFacts());
c.mVRHierarchyFacts.addAll(request.getMVRHierarchyFacts());
c.occupationsFacts.addAll(request.getOccupationsFacts());
c.pACEDataFacts.addAll(request.getPACEDataFacts());
c.policiesFacts.addAll(request.getPoliciesFacts());
c.policyCodeDataFacts.addAll(request.getPolicyCodeDataFacts());
c.policyCodesFacts.addAll(request.getPolicyCodesFacts());
c.policyDataFacts.addAll(request.getPolicyDataFacts());
c.suspensionDataFacts.addAll(request.getSuspensionDataFacts());
c.transDataFacts.addAll(request.getTransDataFacts());
c.vehicleDataFacts.addAll(request.getVehicleDataFacts());
c.vehiclesFacts.addAll(request.getVehiclesFacts());
c.getAccidentsMVRFacts().addAll(request.getAccidentsMVRFacts());
c.getCitationsAdmittedFacts().addAll(request.getCitationsAdmittedFacts());
c.getCitationsMVRFacts().addAll(request.getCitationsMVRFacts());
c.getSuspensionsAdmittedFacts().addAll(request.getSuspensionsAdmittedFacts());
c.getSuspensionsMVRFacts().addAll(request.getSuspensionsMVRFacts());
c.getFailuresToAppearFacts().addAll(request.getFailuresToAppearFacts());
c.getLicenseActionsFacts().addAll(request.getLicenseActionsFacts());
return c;
}
public AuhnResponse toResponse(){
AuhnResponse r=new AuhnResponse();
r.setReferrals(new ArrayList<Referral>(results));
r.setRoutingDestination(routingDestination);
r.setMvrHierarchy(new ArrayList<MVRHierarchy>(mVRHierarchyFacts));
return r;
}
private final List<AccidentsMVR> accidentsMVRFacts=new ArrayList<AccidentsMVR>();
public List<AccidentsMVR> getAccidentsMVRFacts(){return accidentsMVRFacts;}
private final List<CitationsAdmitted> citationsAdmittedFacts=new ArrayList<CitationsAdmitted>();
public List<CitationsAdmitted> getCitationsAdmittedFacts(){return citationsAdmittedFacts;}
private final List<CitationsMVR> citationsMVRFacts=new ArrayList<CitationsMVR>();
public List<CitationsMVR> getCitationsMVRFacts(){return citationsMVRFacts;}
private final List<SuspensionsAdmitted> suspensionsAdmittedFacts=new ArrayList<SuspensionsAdmitted>();
public List<SuspensionsAdmitted> getSuspensionsAdmittedFacts(){return suspensionsAdmittedFacts;}
private final List<SuspensionsMVR> suspensionsMVRFacts=new ArrayList<SuspensionsMVR>();
public List<SuspensionsMVR> getSuspensionsMVRFacts(){return suspensionsMVRFacts;}
private final List<FailuresToAppear> failuresToAppearFacts=new ArrayList<FailuresToAppear>();
public List<FailuresToAppear> getFailuresToAppearFacts(){return failuresToAppearFacts;}
private final List<LicenseActions> licenseActionsFacts=new ArrayList<LicenseActions>();
public List<LicenseActions> getLicenseActionsFacts(){return licenseActionsFacts;}
private java.util.Date effectiveDate;
public java.util.Date getEffectiveDate(){return effectiveDate;}
public void setEffectiveDate(java.util.Date date){effectiveDate=date;}
}
