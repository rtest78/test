000100******************************************************************00000100
000200* WUC100 - INPUT DATA COBOL II RECORD LAYOUT.                  *  00000200
000300******************************************************************00000300
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00000400
000500* INPUT DATA RECEIVED BY AU PROCESSOR.                           *00000500
000600*                                                                *00000600
000700******************************************************************00000700
000800*01 WUC100-INPUT-REC.                                             00000800
000900   05 WUC100-COMPANY                       PIC  9(01).            00000900
000900   05 WUC100-CLUB-CODE                     PIC  X(04).            00000910
001000   05 WUC100-REFTYPE                       PIC  X(03).            00001000
001000   05 WUC100-PRODUCT                       PIC  X(03).            00001010
001100   05 WUC100-POLICY                        PIC  9(09).            00001100
001400   05 WUC100-BUSTRNNO                      PIC  9(04).            00001400
001410   05 WUC100-TRANTYPE                      PIC  X(04).            00001410
001420   05 WUC100-STATE                         PIC  X(02).            00001420
001430   05 WUC100-SUBCOY                        PIC  9(04).            00001430
001430   05 WUC100-BTCHTHREAD                    PIC  X(09).            00001431
001430   05 WUC100-TRANCNT                       PIC S9(4) USAGE COMP.  00001432
001430   05 WUC100-EFFECTDTE                     PIC S9(9) USAGE COMP.  00001433
001430   05 WUC100-INCEPTION                     PIC S9(9) USAGE COMP.  00001434
001430   05 WUC100-TERMINCEP                     PIC S9(9) USAGE COMP.  00001435
001430   05 WUC100-DUEDATE                       PIC S9(9) USAGE COMP.  00001436
