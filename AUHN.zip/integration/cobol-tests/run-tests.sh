#!/usr/bin/env bash
set -euo pipefail
auhn_test_dir="$(cd "$(dirname "$0")" && pwd)"
auhn_root="$(cd "$auhn_test_dir/../.." && pwd)"
auhn_build_dir="${AUHN_COBOL_TEST_BUILD:-$auhn_root/.cobol-test}"
auhn_cobc="${COBC_BIN:-cobc}"
mkdir -p "$auhn_build_dir/classes"
cd "$auhn_build_dir"
"$auhn_cobc" -V
# Native COBOL tests use ASCII text, IBM-compatible COMP sizes and big endian.
# This is not an IBM Enterprise COBOL compiler or EBCDIC runtime.
auhn_flags=(-std=ibm -fbinary-size=2-4-8 -fbinary-byteorder=big-endian -I "$auhn_root/AUHN-Rules/Copybooks")
"$auhn_cobc" -x "${auhn_flags[@]}" -o verify-layout "$auhn_test_dir/verify-layout.cbl"
./verify-layout
python3 "$auhn_test_dir/check_marshaller_layout.py"
find "$auhn_root/AUHN-XOM/src" "$auhn_root/AUHN-COBOL-Adapter/src" -name '*.java' > sources.txt
java com.sun.tools.javac.Main --release 8 -cp "$auhn_root/AUHN-COBOL-XOM/bin" -d classes @sources.txt "$auhn_test_dir/BufferBridgeTest.java"
java -cp "classes:$auhn_root/AUHN-COBOL-XOM/bin" BufferBridgeTest "$auhn_test_dir/layout.tsv" decision-area.bin decision-area-returned.bin
"$auhn_cobc" -x "${auhn_flags[@]}" -o verify-return "$auhn_test_dir/verify-return.cbl"
./verify-return
"$auhn_cobc" -x "${auhn_flags[@]}" -I "$auhn_test_dir/fixtures" -o test-caller "$auhn_test_dir/test-caller.cbl" "$auhn_root/integration/AUHN-HBRRULE.cbl" "$auhn_test_dir/fixtures/mock-hbr.cbl"
./test-caller
bash "$auhn_root/integration/test-mapper.sh"
echo 'PASS: all local tests completed. IBM engine, IBM marshalling and live HBRRULE execution remain unverified.'
