package com.techsavants;

import java.util.ArrayList;
import java.util.List;

public class FlightUtils {

	public static FlightResponse createResponse() {
		FlightResponse response = new FlightResponse();
		response.setRoutes(new ArrayList<Node>());
		return response;
	}

	public static List<Node> createNodeList() {
		return new ArrayList<Node>();
	}

	public static TravelContext createTravelContext(FlightRequest request) {

		TravelContext context = new TravelContext();

		context.setTargetCity(request.getToCity());
		context.setFindShortestOnly(request.isShortestRoute());
		context.setNodes(new ArrayList<Node>());
		context.setGoodNodes(new ArrayList<Node>());

		return context;
	}

	public static Node createInitialNode(FlightRequest request) {

		Node node = new Node();

		node.setCurrentCity(request.getFromCity());
		node.setTotalMiles(0);
		node.setVisitedCities(new ArrayList<String>());
		node.addCity(request.getFromCity());

		return node;
	}

	public static Node getNullNode() {
		return null;
	}

	public static Node createNextNode(Node currentNode, Flight flight) {

		Node node = new Node();

		node.setCurrentCity(flight.getStopCity());

		node.setTotalMiles(currentNode.getTotalMiles() + flight.getMiles());

		node.setVisitedCities(new ArrayList<String>(currentNode.getVisitedCities()));

		node.addCity(flight.getStopCity());

		return node;
	}
	
	
	public static void addNodeToList(
	        List<Node> nodeList,
	        Node node) {

	    if (nodeList == null || node == null) {
	        return;
	    }

	    nodeList.add(node);
	}
	
	public static Node removeLowestMileageNode(
	        List<Node> nodeList) {

	    if (nodeList == null || nodeList.isEmpty()) {
	        return null;
	    }

	    int lowestIndex = 0;

	    for (int index = 1;
	         index < nodeList.size();
	         index++) {

	        if (nodeList.get(index).getTotalMiles() <
	            nodeList.get(lowestIndex).getTotalMiles()) {

	            lowestIndex = index;
	        }
	    }

	    return nodeList.remove(lowestIndex);
	}
}
