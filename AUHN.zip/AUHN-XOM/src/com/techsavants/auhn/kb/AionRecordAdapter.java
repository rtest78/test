package com.techsavants.auhn.kb;

import java.util.*;

/**
 * Fixed-width loaders generated from AUHNPCON offsets (not guessed from names).
 */
public final class AionRecordAdapter {
	private AionRecordAdapter() {
	}

	public static int load(AuhnRequest request, String loader, String buffer) {
		if (request == null)
			throw new IllegalArgumentException("Request is required");
		if (buffer == null || buffer.isEmpty())
			return 99;
		switch (loader) {
		case "LoadPolicy": { // AUHNPCON.txt:71
			for (int row = 0; row < 2; row++) {
				int base = row * 83;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("X", base))
					break;
				if (buffer.length() - base < 83)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				PolicyData raw = new PolicyData();
				SourceFacts.set(raw, "Generation", buffer.substring(base + 0, base + 1).trim());
				SourceFacts.set(raw, "New_Renew_Code", buffer.substring(base + 1, base + 4).trim());
				SourceFacts.set(raw, "Named_Insured_Status", buffer.substring(base + 4, base + 5).trim());
				SourceFacts.set(raw, "Excess_Pol_Ind", buffer.substring(base + 5, base + 6).trim());
				SourceFacts.set(raw, "Comments_Ind", buffer.substring(base + 6, base + 7).trim());
				SourceFacts.set(raw, "Gen_Eff_Date", parseDate(buffer.substring(base + 7, base + 17)));
				SourceFacts.set(raw, "Trans_Date", parseDate(buffer.substring(base + 17, base + 27)));
				SourceFacts.set(raw, "Longevity_Date", parseDate(buffer.substring(base + 27, base + 37)));
				SourceFacts.set(raw, "Excess_Nb_POL_Ind", buffer.substring(base + 37, base + 38).trim());
				SourceFacts.set(raw, "Mgr_Approval", buffer.substring(base + 38, base + 39).trim());
				SourceFacts.set(raw, "Named_Insured_Changed", buffer.substring(base + 39, base + 40).trim());
				SourceFacts.set(raw, "Jewel_HUON_Prem_Discrepancy", buffer.substring(base + 40, base + 41).trim());
				SourceFacts.set(raw, "NB_Regd_Owner_Other", buffer.substring(base + 41, base + 42).trim());
				SourceFacts.set(raw, "Business_Class", buffer.substring(base + 42, base + 43).trim());
				SourceFacts.set(raw, "Inception_Change", buffer.substring(base + 43, base + 44).trim());
				SourceFacts.set(raw, "Agent_Change", buffer.substring(base + 44, base + 45).trim());
				SourceFacts.set(raw, "Clue_Received", buffer.substring(base + 45, base + 46).trim());
				SourceFacts.set(raw, "VADINS", buffer.substring(base + 46, base + 47).trim());
				SourceFacts.set(raw, "SD_LNH", buffer.substring(base + 47, base + 48).trim());
				SourceFacts.set(raw, "SD_LSH", buffer.substring(base + 48, base + 49).trim());
				SourceFacts.set(raw, "SD_LSHM", buffer.substring(base + 49, base + 50).trim());
				SourceFacts.set(raw, "CLUE_Not_Received", buffer.substring(base + 50, base + 51).trim());
				SourceFacts.set(raw, "Mgr_EAD_Approval", buffer.substring(base + 51, base + 52).trim());
				SourceFacts.set(raw, "CAC_Loss_Exists", buffer.substring(base + 52, base + 53).trim());
				SourceFacts.set(raw, "CAC_DrvCd_Error_Exists", buffer.substring(base + 53, base + 54).trim());
				SourceFacts.set(raw, "Ann_Mile_Override_Exists", buffer.substring(base + 54, base + 55).trim());
				SourceFacts.set(raw, "Refer_Branch_Exists", buffer.substring(base + 55, base + 56).trim());
				SourceFacts.set(raw, "Refer_Agent_Exists", buffer.substring(base + 56, base + 57).trim());
				SourceFacts.set(raw, "Liab_Only_Covg_Exists", buffer.substring(base + 57, base + 58).trim());
				SourceFacts.set(raw, "Trans_Type", buffer.substring(base + 58, base + 60).trim());
				SourceFacts.set(raw, "BusinessClass_Score", buffer.substring(base + 60, base + 63).trim());
				SourceFacts.set(raw, "Pol_Prd_Eff_Dte", buffer.substring(base + 63, base + 71).trim());
				SourceFacts.set(raw, "Prod_Rlse_Eff_Dte", buffer.substring(base + 71, base + 79).trim());
				SourceFacts.set(raw, "Rewritten_Policy", buffer.substring(base + 79, base + 80).trim());
				SourceFacts.set(raw, "SpinOff_Policy", buffer.substring(base + 80, base + 81).trim());
				SourceFacts.set(raw, "NNO_Policy", buffer.substring(base + 81, base + 82).trim());
				SourceFacts.set(raw, "Backdated_Eff_Dt", buffer.substring(base + 82, base + 83).trim());
				request.getPolicyDataFacts().add(raw);
			}
			return 0;
		}
		case "LoadDrivers": { // AUHNPCON.txt:135
			for (int row = 0; row < 50; row++) {
				int base = row * 123;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("X", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 123)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				DriverData raw = new DriverData();
				SourceFacts.set(raw, "Generation", buffer.substring(base + 0, base + 1).trim());
				SourceFacts.set(raw, "Action", buffer.substring(base + 1, base + 5).trim());
				SourceFacts.set(raw, "Driver_Number", buffer.substring(base + 5, base + 20).trim());
				SourceFacts.set(raw, "License_Number", buffer.substring(base + 20, base + 30).trim());
				SourceFacts.set(raw, "Driver_Code", buffer.substring(base + 30, base + 31).trim());
				SourceFacts.set(raw, "YR_First_Licensed", SourceFacts.integer(buffer.substring(base + 31, base + 35)));
				SourceFacts.set(raw, "Good_Driver_Ind", buffer.substring(base + 35, base + 36).trim());
				SourceFacts.set(raw, "Relation_to_Applicant", buffer.substring(base + 36, base + 38).trim());
				SourceFacts.set(raw, "Named_Insured_Ind", buffer.substring(base + 38, base + 39).trim());
				SourceFacts.set(raw, "ID_Number", buffer.substring(base + 39, base + 43).trim());
				SourceFacts.set(raw, "Out_of_State_Lic", buffer.substring(base + 43, base + 44).trim());
				SourceFacts.set(raw, "Own_Car_and_Ins", buffer.substring(base + 44, base + 45).trim());
				SourceFacts.set(raw, "RemovalCode", buffer.substring(base + 45, base + 47).trim());
				SourceFacts.set(raw, "ProofOfDependencyInd", buffer.substring(base + 47, base + 48).trim());
				SourceFacts.set(raw, "Birthdate", parseDate(buffer.substring(base + 48, base + 58)));
				SourceFacts.set(raw, "TOT_Points", SourceFacts.integer(buffer.substring(base + 58, base + 62)));
				SourceFacts.set(raw, "Tot_Susp_Count", SourceFacts.integer(buffer.substring(base + 62, base + 66)));
				SourceFacts.set(raw, "CAYR_First_Licensed",
						SourceFacts.integer(buffer.substring(base + 66, base + 70)));
				SourceFacts.set(raw, "Prev_Lic_Out_of_State", buffer.substring(base + 70, base + 71).trim());
				SourceFacts.set(raw, "Student_Away_Ind", buffer.substring(base + 71, base + 72).trim());
				SourceFacts.set(raw, "Student_Away_Reapplied",
						SourceFacts.integer(buffer.substring(base + 72, base + 76)));
				SourceFacts.set(raw, "Other_Country_Lic", buffer.substring(base + 76, base + 77).trim());
				SourceFacts.set(raw, "Cur_Other_Country_Lic", buffer.substring(base + 77, base + 78).trim());
				request.getDriverDataFacts().add(raw);
			}
			return 0;
		}
		case "LoadTrans": { // AUHNPCON.txt:190
			for (int row = 0; row < 1; row++) {
				int base = row * 11;
				if (base >= buffer.length())
					break;
				if (buffer.length() - base < 11)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				TransData raw = new TransData();
				SourceFacts.set(raw, "TransType", buffer.substring(base + 0, base + 2).trim());
				SourceFacts.set(raw, "ClubCode", buffer.substring(base + 2, base + 6).trim());
				SourceFacts.set(raw, "Product", buffer.substring(base + 6, base + 11).trim());
				request.getTransDataFacts().add(raw);
			}
			return 0;
		}
		case "LoadCoverages": { // AUHNPCON.txt:211
			for (int row = 0; row < 400; row++) {
				int base = row * 25;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("X", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 25)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				CoverageData raw = new CoverageData();
				SourceFacts.set(raw, "Generation", buffer.substring(base + 0, base + 1).trim());
				SourceFacts.set(raw, "Action", buffer.substring(base + 1, base + 5).trim());
				SourceFacts.set(raw, "Vehicle_Number", buffer.substring(base + 5, base + 9).trim());
				SourceFacts.set(raw, "Line", buffer.substring(base + 9, base + 15).trim());
				SourceFacts.set(raw, "Limit", buffer.substring(base + 15, base + 25).trim());
				request.getCoverageDataFacts().add(raw);
			}
			return 0;
		}
		case "LoadEmployment": { // AUHNPCON.txt:241
			for (int row = 0; row < 100; row++) {
				int base = row * 40;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("X", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 40)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				EmploymentData raw = new EmploymentData();
				SourceFacts.set(raw, "Generation", buffer.substring(base + 0, base + 1).trim());
				SourceFacts.set(raw, "Action", buffer.substring(base + 1, base + 5).trim());
				SourceFacts.set(raw, "Driver_Number", buffer.substring(base + 5, base + 20).trim());
				SourceFacts.set(raw, "Occup_Title", buffer.substring(base + 20, base + 40).trim());
				request.getEmploymentDataFacts().add(raw);
			}
			return 0;
		}
		case "LoadVehicle": { // AUHNPCON.txt:270
			for (int row = 0; row < 50; row++) {
				int base = row * 115;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("X", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 115)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				VehicleData raw = new VehicleData();
				SourceFacts.set(raw, "Generation", buffer.substring(base + 0, base + 1).trim());
				SourceFacts.set(raw, "Action", buffer.substring(base + 1, base + 5).trim());
				SourceFacts.set(raw, "Vehicle_Number", buffer.substring(base + 5, base + 9).trim());
				SourceFacts.set(raw, "VINN", buffer.substring(base + 9, base + 26).trim());
				SourceFacts.set(raw, "Car_Group", buffer.substring(base + 26, base + 30).trim());
				SourceFacts.set(raw, "Use", buffer.substring(base + 30, base + 31).trim());
				SourceFacts.set(raw, "Year", SourceFacts.integer(buffer.substring(base + 31, base + 35)));
				SourceFacts.set(raw, "Trade_Name", buffer.substring(base + 35, base + 40).trim());
				SourceFacts.set(raw, "Symbol", buffer.substring(base + 40, base + 44).trim());
				SourceFacts.set(raw, "Purchase_Price", SourceFacts.integer(buffer.substring(base + 44, base + 50)));
				SourceFacts.set(raw, "Load_Capacity", buffer.substring(base + 50, base + 55).trim());
				SourceFacts.set(raw, "Limit_of_Liability", SourceFacts.integer(buffer.substring(base + 55, base + 64)));
				SourceFacts.set(raw, "Cycle_License_Ind", buffer.substring(base + 64, base + 65).trim());
				SourceFacts.set(raw, "Sequence_Number", buffer.substring(base + 65, base + 69).trim());
				SourceFacts.set(raw, "Reg_Own_Relationship", buffer.substring(base + 69, base + 71).trim());
				SourceFacts.set(raw, "Reg_Own_DOB", parseDate(buffer.substring(base + 71, base + 81)));
				SourceFacts.set(raw, "ParkedLocation", buffer.substring(base + 81, base + 82).trim());
				SourceFacts.set(raw, "AntiTheftCode", buffer.substring(base + 82, base + 83).trim());
				SourceFacts.set(raw, "PurchaseDate", parseDate(buffer.substring(base + 83, base + 93)));
				SourceFacts.set(raw, "EVRCode", buffer.substring(base + 93, base + 95).trim());
				SourceFacts.set(raw, "Body_Type", buffer.substring(base + 95, base + 96).trim());
				SourceFacts.set(raw, "Miles_Calc_Mth", buffer.substring(base + 96, base + 97).trim());
				SourceFacts.set(raw, "Annual_Miles_Code", buffer.substring(base + 97, base + 101).trim());
				SourceFacts.set(raw, "Pri_Rated_Drv", buffer.substring(base + 101, base + 102).trim());
				SourceFacts.set(raw, "Elim_Reason_Cd", buffer.substring(base + 102, base + 104).trim());
				SourceFacts.set(raw, "Annual_Mileage", SourceFacts.integer(buffer.substring(base + 104, base + 113)));
				SourceFacts.set(raw, "Vndr_Milg_Src", buffer.substring(base + 113, base + 114).trim());
				SourceFacts.set(raw, "Storage_Ind", buffer.substring(base + 114, base + 115).trim());
				request.getVehicleDataFacts().add(raw);
			}
			return 0;
		}
		case "LoadAccident": { // AUHNPCON.txt:327
			for (int row = 0; row < 400; row++) {
				int base = row * 38;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("X", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 38)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				AccidentData raw = new AccidentData();
				SourceFacts.set(raw, "Generation", buffer.substring(base + 0, base + 1).trim());
				SourceFacts.set(raw, "Action", buffer.substring(base + 1, base + 5).trim());
				SourceFacts.set(raw, "Driver_Number", buffer.substring(base + 5, base + 20).trim());
				SourceFacts.set(raw, "Loss_Type", buffer.substring(base + 20, base + 23).trim());
				SourceFacts.set(raw, "Acc_Id", SourceFacts.integer(buffer.substring(base + 23, base + 27)));
				SourceFacts.set(raw, "Acc_Date", parseDate(buffer.substring(base + 27, base + 37)));
				SourceFacts.set(raw, "Acc_ChrgInd", buffer.substring(base + 37, base + 38).trim());
				request.getAccidentDataFacts().add(raw);
			}
			return 0;
		}
		case "LoadCitations": { // AUHNPCON.txt:359
			for (int row = 0; row < 400; row++) {
				int base = row * 38;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("X", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 38)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				CitationData raw = new CitationData();
				SourceFacts.set(raw, "Generation", buffer.substring(base + 0, base + 1).trim());
				SourceFacts.set(raw, "Action", buffer.substring(base + 1, base + 5).trim());
				SourceFacts.set(raw, "Driver_Number", buffer.substring(base + 5, base + 20).trim());
				SourceFacts.set(raw, "Category", SourceFacts.integer(buffer.substring(base + 20, base + 24)));
				SourceFacts.set(raw, "Cit_ID", SourceFacts.integer(buffer.substring(base + 24, base + 28)));
				SourceFacts.set(raw, "Cit_Date", parseDate(buffer.substring(base + 28, base + 38)));
				request.getCitationDataFacts().add(raw);
			}
			return 0;
		}
		case "LoadEndorsement": { // AUHNPCON.txt:390
			for (int row = 0; row < 40; row++) {
				int base = row * 26;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("X", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 26)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				EndorsementData raw = new EndorsementData();
				SourceFacts.set(raw, "Generation", buffer.substring(base + 0, base + 1).trim());
				SourceFacts.set(raw, "Action", buffer.substring(base + 1, base + 5).trim());
				SourceFacts.set(raw, "Endorsement_Name", buffer.substring(base + 5, base + 11).trim());
				SourceFacts.set(raw, "Object_Id", buffer.substring(base + 11, base + 26).trim());
				request.getEndorsementDataFacts().add(raw);
			}
			return 0;
		}
		case "LoadInspection": { // AUHNPCON.txt:419
			for (int row = 0; row < 50; row++) {
				int base = row * 18;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("X", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 18)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				InspectionData raw = new InspectionData();
				SourceFacts.set(raw, "Generation", buffer.substring(base + 0, base + 1).trim());
				SourceFacts.set(raw, "Action", buffer.substring(base + 1, base + 5).trim());
				SourceFacts.set(raw, "Vehicle_Number", buffer.substring(base + 5, base + 9).trim());
				SourceFacts.set(raw, "Modified_Ind", buffer.substring(base + 9, base + 10).trim());
				SourceFacts.set(raw, "Photo_Code", buffer.substring(base + 10, base + 11).trim());
				request.getInspectionDataFacts().add(raw);
			}
			return 0;
		}
		case "LoadMVR1": { // AUHNPCON.txt:449
			for (int row = 0; row < 50; row++) {
				int base = row * 58;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("XXXXXXXXXX", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 58)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				MVR1Data raw = new MVR1Data();
				SourceFacts.set(raw, "License_Number", buffer.substring(base + 0, base + 10).trim());
				SourceFacts.set(raw, "Driver_Code", buffer.substring(base + 10, base + 11).trim());
				SourceFacts.set(raw, "Report_Date", parseDate(buffer.substring(base + 11, base + 21)));
				SourceFacts.set(raw, "Class", buffer.substring(base + 21, base + 22).trim());
				SourceFacts.set(raw, "Status", buffer.substring(base + 22, base + 30).trim());
				SourceFacts.set(raw, "Restrictions", buffer.substring(base + 30, base + 47).trim());
				SourceFacts.set(raw, "MVR_Record_Clear", buffer.substring(base + 47, base + 48).trim());
				SourceFacts.set(raw, "MVR_Lic_Exp_Date", parseDate(buffer.substring(base + 48, base + 58)));
				request.getMVR1DataFacts().add(raw);
			}
			return 0;
		}
		case "LoadMVR2": { // AUHNPCON.txt:484
			for (int row = 0; row < 200; row++) {
				int base = row * 85;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("XXXXXXXXXX", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 85)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				MVR2Data raw = new MVR2Data();
				SourceFacts.set(raw, "License_Number", buffer.substring(base + 0, base + 10).trim());
				SourceFacts.set(raw, "Sequence_Number", SourceFacts.integer(buffer.substring(base + 10, base + 13)));
				SourceFacts.set(raw, "Type", buffer.substring(base + 13, base + 17).trim());
				SourceFacts.set(raw, "Violation_Date", parseDate(buffer.substring(base + 17, base + 27)));
				SourceFacts.set(raw, "Conviction_Date", parseDate(buffer.substring(base + 27, base + 37)));
				SourceFacts.set(raw, "Good_Driver_Pts", SourceFacts.integer(buffer.substring(base + 37, base + 38)));
				SourceFacts.set(raw, "Category", buffer.substring(base + 38, base + 39).trim());
				SourceFacts.set(raw, "Surcharge", buffer.substring(base + 39, base + 40).trim());
				SourceFacts.set(raw, "Description", buffer.substring(base + 40, base + 85).trim());
				request.getMVR2DataFacts().add(raw);
			}
			return 0;
		}
		case "LoadMVR4": { // AUHNPCON.txt:521
			for (int row = 0; row < 200; row++) {
				int base = row * 58;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("XXXXXXXXXX", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 58)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				MVR4Data raw = new MVR4Data();
				SourceFacts.set(raw, "License_Number", buffer.substring(base + 0, base + 10).trim());
				SourceFacts.set(raw, "Sequence_Number", SourceFacts.integer(buffer.substring(base + 10, base + 13)));
				SourceFacts.set(raw, "Description", buffer.substring(base + 13, base + 58).trim());
				request.getMVR4DataFacts().add(raw);
			}
			return 0;
		}
		case "LoadMVR5": { // AUHNPCON.txt:549
			for (int row = 0; row < 200; row++) {
				int base = row * 82;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("XXXXXXXXXX", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 82)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				MVR5Data raw = new MVR5Data();
				SourceFacts.set(raw, "License_Number", buffer.substring(base + 0, base + 10).trim());
				SourceFacts.set(raw, "Sequence_Number", SourceFacts.integer(buffer.substring(base + 10, base + 13)));
				SourceFacts.set(raw, "Type", buffer.substring(base + 13, base + 17).trim());
				SourceFacts.set(raw, "Accident_Date", parseDate(buffer.substring(base + 17, base + 27)));
				SourceFacts.set(raw, "Description", buffer.substring(base + 27, base + 72).trim());
				SourceFacts.set(raw, "Lic_Rein_Date", parseDate(buffer.substring(base + 72, base + 82)));
				request.getMVR5DataFacts().add(raw);
			}
			return 0;
		}
		case "LoadMVR6": { // AUHNPCON.txt:582
			for (int row = 0; row < 200; row++) {
				int base = row * 58;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("XXXXXXXXXX", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 58)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				MVR6Data raw = new MVR6Data();
				SourceFacts.set(raw, "License_Number", buffer.substring(base + 0, base + 10).trim());
				SourceFacts.set(raw, "Sequence_Number", SourceFacts.integer(buffer.substring(base + 10, base + 13)));
				SourceFacts.set(raw, "Description", buffer.substring(base + 13, base + 58).trim());
				request.getMVR6DataFacts().add(raw);
			}
			return 0;
		}
		case "LoadPolicyCodes": { // AUHNPCON.txt:610
			for (int row = 0; row < 30; row++) {
				int base = row * 25;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("X", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 25)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				PolicyCodeData raw = new PolicyCodeData();
				SourceFacts.set(raw, "Generation", buffer.substring(base + 0, base + 1).trim());
				SourceFacts.set(raw, "Action", buffer.substring(base + 1, base + 5).trim());
				SourceFacts.set(raw, "Name", buffer.substring(base + 5, base + 15).trim());
				SourceFacts.set(raw, "Code", buffer.substring(base + 15, base + 25).trim());
				request.getPolicyCodeDataFacts().add(raw);
			}
			return 0;
		}
		case "LoadPACE": { // AUHNPCON.txt:639
			for (int row = 0; row < 80; row++) {
				int base = row * 29;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("0000", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 29)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				PACEData raw = new PACEData();
				SourceFacts.set(raw, "DriverNumber", buffer.substring(base + 0, base + 4).trim());
				SourceFacts.set(raw, "LossDate", parseDate(buffer.substring(base + 4, base + 14)));
				SourceFacts.set(raw, "LossType", buffer.substring(base + 14, base + 19).trim());
				SourceFacts.set(raw, "LossStatus", buffer.substring(base + 19, base + 21).trim());
				SourceFacts.set(raw, "LossAmount", SourceFacts.integer(buffer.substring(base + 21, base + 29)));
				request.getPACEDataFacts().add(raw);
			}
			return 0;
		}
		case "LoadDriversOfVehicle": { // AUHNPCON.txt:669
			for (int row = 0; row < 500; row++) {
				int base = row * 25;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("X", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 25)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				DriverOfVehicleData raw = new DriverOfVehicleData();
				SourceFacts.set(raw, "Generation", buffer.substring(base + 0, base + 1).trim());
				SourceFacts.set(raw, "Action", buffer.substring(base + 1, base + 5).trim());
				SourceFacts.set(raw, "Vehicle_Number", buffer.substring(base + 5, base + 9).trim());
				SourceFacts.set(raw, "Driver_Number", buffer.substring(base + 9, base + 24).trim());
				SourceFacts.set(raw, "PrimaryDriverInd", buffer.substring(base + 24, base + 25).trim());
				request.getDriverOfVehicleDataFacts().add(raw);
			}
			return 0;
		}
		case "LoadMVR3": { // AUHNPCON.txt:781
			for (int row = 0; row < 200; row++) {
				int base = row * 61;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("XXXXXXXXXX", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 61)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				MVR3Data raw = new MVR3Data();
				SourceFacts.set(raw, "License_Number", buffer.substring(base + 0, base + 10).trim());
				SourceFacts.set(raw, "Sequence_Number", SourceFacts.integer(buffer.substring(base + 10, base + 13)));
				SourceFacts.set(raw, "Good_Driver_Pts", SourceFacts.integer(buffer.substring(base + 13, base + 14)));
				SourceFacts.set(raw, "Category", buffer.substring(base + 14, base + 15).trim());
				SourceFacts.set(raw, "Surcharge", buffer.substring(base + 15, base + 16).trim());
				SourceFacts.set(raw, "Description", buffer.substring(base + 16, base + 61).trim());
				request.getMVR3DataFacts().add(raw);
			}
			return 0;
		}
		case "LoadSuspension": { // AUHNPCON.txt:812
			for (int row = 0; row < 400; row++) {
				int base = row * 44;
				if (base >= buffer.length())
					break;
				if (buffer.startsWith("X", base))
					break;
				if (buffer.startsWith("     ", base))
					break;
				if (buffer.length() - base < 44)
					throw new IllegalArgumentException(loader + ": truncated record " + (row + 1));
				SuspensionData raw = new SuspensionData();
				SourceFacts.set(raw, "Generation", buffer.substring(base + 0, base + 1).trim());
				SourceFacts.set(raw, "Action", buffer.substring(base + 1, base + 5).trim());
				SourceFacts.set(raw, "Driver_number", buffer.substring(base + 5, base + 20).trim());
				SourceFacts.set(raw, "Susp_id", SourceFacts.integer(buffer.substring(base + 20, base + 24)));
				SourceFacts.set(raw, "Susp_Date", parseDate(buffer.substring(base + 24, base + 34)));
				SourceFacts.set(raw, "Rein_Date", parseDate(buffer.substring(base + 34, base + 44)));
				request.getSuspensionDataFacts().add(raw);
			}
			return 0;
		}
		default:
			throw new IllegalArgumentException("Unknown AION loader: " + loader);
		}
	}

	public static java.util.Date parseDate(String value) {
		if (value == null || (value.length() != 8 && value.length() != 10))
			return null;
		try {
			int y, m, d;
			if (value.length() == 10) {
				m = Integer.parseInt(value.substring(0, 2));
				d = Integer.parseInt(value.substring(3, 5));
				y = Integer.parseInt(value.substring(6, 10));
			} else {
				y = Integer.parseInt(value.substring(0, 4));
				m = Integer.parseInt(value.substring(4, 6));
				d = Integer.parseInt(value.substring(6, 8));
			}
			return AuhnValues.date(y, m, d);
		} catch (RuntimeException error) {
			return null;
		}
	}

	/**
	 * GetResults: route padded to five, then code/vehicle/driver, X, spaces to 664.
	 */
	public static String results(AuhnResponse response) {
		String route = response.getRoutingDestination();
		if (route == null)
			throw new IllegalStateException("No routing destination");
		StringBuilder out = new StringBuilder(route);
		if (route.length() == 3)
			out.append("  ");
		else if (route.length() == 4)
			out.append(" ");
		for (Referral result : response.getReferrals())
			out.append(result.getCode()).append(result.getVehicle()).append(result.getDriver());
		out.append('X');
		while (out.length() < 664)
			out.append(' ');
		return out.substring(0, 664);
	}
}
