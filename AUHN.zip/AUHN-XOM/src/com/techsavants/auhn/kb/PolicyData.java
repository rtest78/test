package com.techsavants.auhn.kb;
public class PolicyData {
    private String vBusiness_Class;
    public String getVBusiness_Class() { return vBusiness_Class; }
    public void setVBusiness_Class(String value) { vBusiness_Class = value; }
    private String vComments_Ind;
    public String getVComments_Ind() { return vComments_Ind; }
    public void setVComments_Ind(String value) { vComments_Ind = value; }
    private String vCLUE_Not_Received;
    public String getVCLUE_Not_Received() { return vCLUE_Not_Received; }
    public void setVCLUE_Not_Received(String value) { vCLUE_Not_Received = value; }
    private String vExcess_Nb_POL_Ind;
    public String getVExcess_Nb_POL_Ind() { return vExcess_Nb_POL_Ind; }
    public void setVExcess_Nb_POL_Ind(String value) { vExcess_Nb_POL_Ind = value; }
    private String vExcess_Pol_Ind;
    public String getVExcess_Pol_Ind() { return vExcess_Pol_Ind; }
    public void setVExcess_Pol_Ind(String value) { vExcess_Pol_Ind = value; }
    private java.util.Date vGen_Eff_Date;
    public java.util.Date getVGen_Eff_Date() { return vGen_Eff_Date; }
    public void setVGen_Eff_Date(java.util.Date value) { vGen_Eff_Date = value; }
    private java.util.Date vLongevity_Date;
    public java.util.Date getVLongevity_Date() { return vLongevity_Date; }
    public void setVLongevity_Date(java.util.Date value) { vLongevity_Date = value; }
    private String vMgr_Approval;
    public String getVMgr_Approval() { return vMgr_Approval; }
    public void setVMgr_Approval(String value) { vMgr_Approval = value; }
    private String vNamed_Insured_Changed;
    public String getVNamed_Insured_Changed() { return vNamed_Insured_Changed; }
    public void setVNamed_Insured_Changed(String value) { vNamed_Insured_Changed = value; }
    private String vNamed_Insured_Status;
    public String getVNamed_Insured_Status() { return vNamed_Insured_Status; }
    public void setVNamed_Insured_Status(String value) { vNamed_Insured_Status = value; }
    private String vClue_Received;
    public String getVClue_Received() { return vClue_Received; }
    public void setVClue_Received(String value) { vClue_Received = value; }
    private String vAgent_Change;
    public String getVAgent_Change() { return vAgent_Change; }
    public void setVAgent_Change(String value) { vAgent_Change = value; }
    private String vSD_LNH;
    public String getVSD_LNH() { return vSD_LNH; }
    public void setVSD_LNH(String value) { vSD_LNH = value; }
    private String vSD_LSH;
    public String getVSD_LSH() { return vSD_LSH; }
    public void setVSD_LSH(String value) { vSD_LSH = value; }
    private String vSD_LSHM;
    public String getVSD_LSHM() { return vSD_LSHM; }
    public void setVSD_LSHM(String value) { vSD_LSHM = value; }
    private java.util.Date vTrans_Date;
    public java.util.Date getVTrans_Date() { return vTrans_Date; }
    public void setVTrans_Date(java.util.Date value) { vTrans_Date = value; }
    private String vVADINS;
    public String getVVADINS() { return vVADINS; }
    public void setVVADINS(String value) { vVADINS = value; }
    private String vInception_Change;
    public String getVInception_Change() { return vInception_Change; }
    public void setVInception_Change(String value) { vInception_Change = value; }
    private String vNB_Regd_Owner_Other;
    public String getVNB_Regd_Owner_Other() { return vNB_Regd_Owner_Other; }
    public void setVNB_Regd_Owner_Other(String value) { vNB_Regd_Owner_Other = value; }
    private String vJewel_HUON_Prem_Discrepancy;
    public String getVJewel_HUON_Prem_Discrepancy() { return vJewel_HUON_Prem_Discrepancy; }
    public void setVJewel_HUON_Prem_Discrepancy(String value) { vJewel_HUON_Prem_Discrepancy = value; }
    private String vNew_Renew_Code;
    public String getVNew_Renew_Code() { return vNew_Renew_Code; }
    public void setVNew_Renew_Code(String value) { vNew_Renew_Code = value; }
    private String vMgr_EAD_Approval;
    public String getVMgr_EAD_Approval() { return vMgr_EAD_Approval; }
    public void setVMgr_EAD_Approval(String value) { vMgr_EAD_Approval = value; }
    private String vCAC_Loss_Exists;
    public String getVCAC_Loss_Exists() { return vCAC_Loss_Exists; }
    public void setVCAC_Loss_Exists(String value) { vCAC_Loss_Exists = value; }
    private String vCAC_DrvCd_Error_Exists;
    public String getVCAC_DrvCd_Error_Exists() { return vCAC_DrvCd_Error_Exists; }
    public void setVCAC_DrvCd_Error_Exists(String value) { vCAC_DrvCd_Error_Exists = value; }
    private String vAnn_Mile_Override_Exists;
    public String getVAnn_Mile_Override_Exists() { return vAnn_Mile_Override_Exists; }
    public void setVAnn_Mile_Override_Exists(String value) { vAnn_Mile_Override_Exists = value; }
    private String vTrans_Type;
    public String getVTrans_Type() { return vTrans_Type; }
    public void setVTrans_Type(String value) { vTrans_Type = value; }
    private String vBusinessClass_Score;
    public String getVBusinessClass_Score() { return vBusinessClass_Score; }
    public void setVBusinessClass_Score(String value) { vBusinessClass_Score = value; }
    private String vPol_Prd_Eff_Dte;
    public String getVPol_Prd_Eff_Dte() { return vPol_Prd_Eff_Dte; }
    public void setVPol_Prd_Eff_Dte(String value) { vPol_Prd_Eff_Dte = value; }
    private String vProd_Rlse_Eff_Dte;
    public String getVProd_Rlse_Eff_Dte() { return vProd_Rlse_Eff_Dte; }
    public void setVProd_Rlse_Eff_Dte(String value) { vProd_Rlse_Eff_Dte = value; }
    private String vRefer_Branch_Exists;
    public String getVRefer_Branch_Exists() { return vRefer_Branch_Exists; }
    public void setVRefer_Branch_Exists(String value) { vRefer_Branch_Exists = value; }
    private String vRefer_Agent_Exists;
    public String getVRefer_Agent_Exists() { return vRefer_Agent_Exists; }
    public void setVRefer_Agent_Exists(String value) { vRefer_Agent_Exists = value; }
    private String vLiab_Only_Covg_Exists;
    public String getVLiab_Only_Covg_Exists() { return vLiab_Only_Covg_Exists; }
    public void setVLiab_Only_Covg_Exists(String value) { vLiab_Only_Covg_Exists = value; }
    private String vRewritten_Policy;
    public String getVRewritten_Policy() { return vRewritten_Policy; }
    public void setVRewritten_Policy(String value) { vRewritten_Policy = value; }
    private String vSpinOff_Policy;
    public String getVSpinOff_Policy() { return vSpinOff_Policy; }
    public void setVSpinOff_Policy(String value) { vSpinOff_Policy = value; }
    private String vNNO_Policy;
    public String getVNNO_Policy() { return vNNO_Policy; }
    public void setVNNO_Policy(String value) { vNNO_Policy = value; }
    private String vBackdated_Eff_Dt;
    public String getVBackdated_Eff_Dt() { return vBackdated_Eff_Dt; }
    public void setVBackdated_Eff_Dt(String value) { vBackdated_Eff_Dt = value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction=value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
}
