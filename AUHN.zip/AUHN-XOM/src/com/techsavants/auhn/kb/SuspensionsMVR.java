package com.techsavants.auhn.kb;
public class SuspensionsMVR {
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction=value; }
    private String vACTION_ADDED;
    public String getVACTION_ADDED() { return vACTION_ADDED; }
    public void setVACTION_ADDED(String value) { vACTION_ADDED=value; }
    private String vACTION_CHANGED;
    public String getVACTION_CHANGED() { return vACTION_CHANGED; }
    public void setVACTION_CHANGED(String value) { vACTION_CHANGED=value; }
    private String vACTION_ELIMINATED;
    public String getVACTION_ELIMINATED() { return vACTION_ELIMINATED; }
    public void setVACTION_ELIMINATED(String value) { vACTION_ELIMINATED=value; }
    private java.util.Date vActivityDate;
    public java.util.Date getVActivityDate() { return vActivityDate; }
    public void setVActivityDate(java.util.Date value) { vActivityDate=value; }
    private Integer vDAY_DIFF_TO_MATCH;
    public Integer getVDAY_DIFF_TO_MATCH() { return vDAY_DIFF_TO_MATCH; }
    public void setVDAY_DIFF_TO_MATCH(Integer value) { vDAY_DIFF_TO_MATCH=value; }
    private Boolean vIsWithinExperiencePeriod;
    public Boolean getVIsWithinExperiencePeriod() { return vIsWithinExperiencePeriod; }
    public void setVIsWithinExperiencePeriod(Boolean value) { vIsWithinExperiencePeriod=value; }
    private Boolean vIsCountable;
    public Boolean getVIsCountable() { return vIsCountable; }
    public void setVIsCountable(Boolean value) { vIsCountable=value; }
    private String vDriverNumber;
    public String getVDriverNumber() { return vDriverNumber; }
    public void setVDriverNumber(String value) { vDriverNumber=value; }
    private Integer vExperiencePeriod;
    public Integer getVExperiencePeriod() { return vExperiencePeriod; }
    public void setVExperiencePeriod(Integer value) { vExperiencePeriod=value; }
    private Integer vSuspID;
    public Integer getVSuspID() { return vSuspID; }
    public void setVSuspID(Integer value) { vSuspID=value; }
    private String vVALID_RECORD_TYPE;
    public String getVVALID_RECORD_TYPE() { return vVALID_RECORD_TYPE; }
    public void setVVALID_RECORD_TYPE(String value) { vVALID_RECORD_TYPE=value; }
    private Boolean vIsCurrentInfo;
    public Boolean getVIsCurrentInfo() { return vIsCurrentInfo; }
    public void setVIsCurrentInfo(Boolean value) { vIsCurrentInfo=value; }
    private Boolean vIsAddedOrNew;
    public Boolean getVIsAddedOrNew() { return vIsAddedOrNew; }
    public void setVIsAddedOrNew(Boolean value) { vIsAddedOrNew=value; }
    private Boolean vIsNewInfo;
    public Boolean getVIsNewInfo() { return vIsNewInfo; }
    public void setVIsNewInfo(Boolean value) { vIsNewInfo=value; }
    private Boolean vIsExistingInfo;
    public Boolean getVIsExistingInfo() { return vIsExistingInfo; }
    public void setVIsExistingInfo(Boolean value) { vIsExistingInfo=value; }
    private String vRecordType;
    public String getVRecordType() { return vRecordType; }
    public void setVRecordType(String value) { vRecordType=value; }
}
