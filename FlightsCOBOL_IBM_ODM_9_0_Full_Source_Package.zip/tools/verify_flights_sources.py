#!/usr/bin/env python3
"""Flight-only static checks; no IBM marshaller is built by this script."""
from pathlib import Path
import re,sys
ROOT=Path(__file__).resolve().parent.parent
copy=ROOT/'zos'/'copybooks'
in_text=(copy/'FLTIN.cpy').read_text()
out_text=(copy/'FLTOUT.cpy').read_text()
master=(copy/'FLIGHTOD.cpy').read_text()
batch=(ROOT/'zos/src/FLTBATCH.cbl').read_text()
call=(ROOT/'zos/src/FLTCALL.cbl').read_text()
assert '01 FLC-DECISION-AREA.' in master
assert 'COPY FLTIN.' in master and 'COPY FLTOUT.' in master
assert 'OCCURS 100 TIMES' in in_text
assert 'OCCURS 100 TIMES' in out_text and 'OCCURS 50 TIMES' in out_text
assert 'FLC-MILES' in in_text and 'FLC-VISITED-CITY' in out_text
expected=32+32+1+3+100*(32+32+9)+3+100*(32+10+2+50*32)
assert expected==171771
assert "MOVE '/FlightsDep/1.0/FlightsCOBOL/1.0'" in batch
assert 'ACCEPT ODM-RULESET-PATH' not in batch
assert "MOVE 'flightDecisionArea' TO WS-PARAM-NAME" in call
assert (ROOT/'Flights/deployment/FlightsCOBOL.dop').exists()
assert not list((ROOT/'Flights-COBOL-XOM/src').rglob('*.java')), (
    'The IBM XOM project is expected empty until importer generation')
print('OK: Flights source, copybook layout, ruleset path and native parameter name')
print('Expected COBOL buffer length: ',expected,'bytes')
print('IBM XOM/marshaller: NOT generated (requires IBM Rule Designer)')
