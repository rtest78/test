# Native COBOL XOM generation is required

This Eclipse project deliberately has an empty `src/` directory. The old handwritten
classes were moved to `test-support/java-contract-stubs/`, where they can be used for
*local contract tests only*. They **cannot** marshal COBOL raw data in IBM ODM.

In IBM ODM **9.0 Rule Designer** import the `Flights/Copybooks/FLIGHTOD.cpy`
root with `FLTIN.cpy` and `FLTOUT.cpy` on the COPY search path. Configure the
COBOL XOM Java package to match the decision variable currently referencing
`com.techsavants.flights.cobol.Flc_decision_area`. If the importer generates
a different class name, update `Flights/rules/Flight.var`, the bridge BOM,
and mapper together and rebuild. Do not rename the deployed ruleset path.

Generate the IBM-supplied marshalling artifacts. Check and deploy the actual XOM,
associated marshaller and RuleApp to the same RES persistence backing `D0R1`.
`tools/check_generated_artifacts.py` tests for missing outputs but **does not**
substitute for the IBM marshaller generator.
