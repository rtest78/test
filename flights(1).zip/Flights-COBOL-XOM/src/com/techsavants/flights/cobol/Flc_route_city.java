/* Hand-written contract model for local verification.
 * NOT an IBM-generated COBOL XOM and NOT a marshaller.
 * Replace these classes using the IBM COBOL importer before deployment.
 */
package com.techsavants.flights.cobol;

public class Flc_route_city {
    private String flc_visited_city = "";
    public Flc_route_city() {}
    public String getFlc_visited_city() { return flc_visited_city; }
    public void setFlc_visited_city(String value) { flc_visited_city = value; }
}
