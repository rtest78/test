package com.techsavants.auhn.kb;

public class ApplicationData {
	private String vAction;

	public String getVAction() {
		return vAction;
	}

	public void setVAction(String value) {
		vAction = value;
	}

	private String vGeneration;

	public String getVGeneration() {
		return vGeneration;
	}

	public void setVGeneration(String value) {
		vGeneration = value;
	}
}
