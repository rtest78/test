       >>SOURCE FORMAT FREE
*> TEST DOUBLE ONLY. NO IBM RUNTIME OR BUSINESS RULE EXECUTION.
identification division.
program-id. HBRRULE.
data division.
working-storage section.
01 TEST-INDEX binary-long.
       >>SOURCE FORMAT FIXED
           COPY CONTROL.
       >>SOURCE FORMAT FREE
linkage section.
       >>SOURCE FORMAT FIXED
           COPY HBRWS.
           COPY FLIGHTOD.
           COPY AUODM-WRAPPER.
       >>SOURCE FORMAT FREE
procedure division using HBRA-CONN-AREA.
    add 1 to rule-count
    if TEST-HBR-HEADER not = 'FIXTURE!'
        add 1 to fixture-errors
    end-if
    move zero to HBRA-CONN-COMPLETION-CODE HBRA-CONN-REASON-CODE
    move spaces to HBRA-RESPONSE-MESSAGE
    perform varying test-index from 2 by 1 until test-index > 32
        if HBRA-RA-PARAMETER-NAME(test-index) not = spaces or
           HBRA-RA-DATA-LENGTH(test-index) not = zero or
           HBRA-RA-DATA-ADDRESS(test-index) not = null
            add 1 to fixture-errors
        end-if
    end-perform
    if HBRA-RA-DATA-ADDRESS(1) = null
        add 1 to fixture-errors
        goback
    end-if
    evaluate HBRA-RA-PARAMETER-NAME(1)
      when 'flightDecisionArea'
        if HBRA-CONN-RULEAPP-PATH not = '/FlightsDep/FlightsCOBOL'
            or HBRA-RA-DATA-LENGTH(1) not = 171771
            add 1 to fixture-errors
        end-if
        set address of FLC-DECISION-AREA
            to HBRA-RA-DATA-ADDRESS(1)
        if FLC-FLIGHT-COUNT not = 3 or FLC-FROM-CITY not = 'A'
            or FLC-TO-CITY not = 'C' or FLC-SHORTEST not = 'Y'
            or FLC-MILES(1) not = 100 or FLC-MILES(2) not = 200
            or FLC-MILES(3) not = 500
            add 1 to fixture-errors
        end-if
        if test-case not = 'RULE-FAIL' and not = 'BOTH-FAIL'
            move 1 to FLC-ROUTE-COUNT
            move 'C' to FLC-CURRENT-CITY(1)
            move 300 to FLC-TOTAL-MILES(1)
            move 3 to FLC-CITY-COUNT(1)
            move 'A' to FLC-VISITED-CITY(1, 1)
            move 'B' to FLC-VISITED-CITY(1, 2)
            move 'C' to FLC-VISITED-CITY(1, 3)
        end-if
      when 'auDecisionArea'
        if HBRA-CONN-RULEAPP-PATH not =
            '/AUHN_KB_RuleApp/AUHN_KB_Rules'
            or HBRA-RA-DATA-LENGTH(1) not = 164063
            add 1 to fixture-errors
        end-if
        set address of AUODM-DECISION-AREA
            to HBRA-RA-DATA-ADDRESS(1)
        if WUC100-POLICY not = 123456789 or
            WUC101-TRAN-TYPE not = 'NB'
            or WUC102-POL-GENERATION(1) not = 'C'
            or WUC102-POL-GEN-EFF-DATE(1) not = '10/14/2026'
            add 1 to fixture-errors
        end-if
        if test-case not = 'RULE-FAIL' and not = 'BOTH-FAIL'
            move 'PDS' to WUC121-ROUTING-DESTINATION
            move '010' to WUC121-RSN-CODE(1)
            move 7 to WUC121-RSN-VEHICLE-NUMBER(1)
            move 12 to WUC121-RSN-DRIVER-NUMBER(1)
            move 'X' to WUC121-RSN-CODE(2)
        end-if
      when other
        add 1 to fixture-errors
    end-evaluate
    if test-case = 'RULE-WARN'
        move 4 to HBRA-CONN-COMPLETION-CODE
        move 2011 to HBRA-CONN-REASON-CODE
        move 'TEST RULE WARNING'to HBRA-RESPONSE-MESSAGE
    end-if
    if test-case = 'RULE-FAIL' or test-case = 'BOTH-FAIL'
        move 8 to HBRA-CONN-COMPLETION-CODE
        move 2001 to HBRA-CONN-REASON-CODE
        move 'TEST RULE FAILURE' to HBRA-RESPONSE-MESSAGE
    end-if
    goback.
end program HBRRULE.
