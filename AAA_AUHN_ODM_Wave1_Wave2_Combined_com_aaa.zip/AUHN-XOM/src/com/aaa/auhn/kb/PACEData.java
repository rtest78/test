package com.aaa.auhn.kb;
public class PACEData {
    private java.util.Date vLossDate;
    public java.util.Date getVLossDate() { return vLossDate; }
    public void setVLossDate(java.util.Date value) { vLossDate = value; }
    private Integer vLossAmount;
    public Integer getVLossAmount() { return vLossAmount; }
    public void setVLossAmount(Integer value) { vLossAmount = value; }
    private String vLossType;
    public String getVLossType() { return vLossType; }
    public void setVLossType(String value) { vLossType = value; }
    private String vDriverNumber;
    public String getVDriverNumber() { return vDriverNumber; }
    public void setVDriverNumber(String value) { vDriverNumber = value; }
    private String vLossStatus;
    public String getVLossStatus() { return vLossStatus; }
    public void setVLossStatus(String value) { vLossStatus = value; }
}
