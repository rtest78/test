package com.aaa.auhn.kb;
public class PolicyCodeData {
    private String vName;
    public String getVName() { return vName; }
    public void setVName(String value) { vName = value; }
    private String vCode;
    public String getVCode() { return vCode; }
    public void setVCode(String value) { vCode = value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction=value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
}
