/* Hand-written contract model for local verification.
 * NOT an IBM-generated COBOL XOM and NOT a marshaller.
 * Replace these classes using the IBM COBOL importer before deployment.
 */
package com.techsavants.flights.cobol;

public class Flc_decision_area {
    private String flc_from_city = "";
    private String flc_to_city = "";
    private String flc_shortest = "";
    private short flc_flight_count = 0;
    private Flc_flight[] flc_flight = null;
    private short flc_route_count = 0;
    private Flc_route[] flc_route = null;
    public Flc_decision_area() {}
    public String getFlc_from_city() { return flc_from_city; }
    public void setFlc_from_city(String value) { flc_from_city = value; }
    public String getFlc_to_city() { return flc_to_city; }
    public void setFlc_to_city(String value) { flc_to_city = value; }
    public String getFlc_shortest() { return flc_shortest; }
    public void setFlc_shortest(String value) { flc_shortest = value; }
    public short getFlc_flight_count() { return flc_flight_count; }
    public void setFlc_flight_count(short value) { flc_flight_count = value; }
    public Flc_flight[] getFlc_flight() { return flc_flight; }
    public void setFlc_flight(Flc_flight[] value) { flc_flight = value; }
    public short getFlc_route_count() { return flc_route_count; }
    public void setFlc_route_count(short value) { flc_route_count = value; }
    public Flc_route[] getFlc_route() { return flc_route; }
    public void setFlc_route(Flc_route[] value) { flc_route = value; }
}
