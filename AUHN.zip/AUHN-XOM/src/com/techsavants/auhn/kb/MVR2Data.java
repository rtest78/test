package com.techsavants.auhn.kb;
public class MVR2Data {
    private String vCategory;
    public String getVCategory() { return vCategory; }
    public void setVCategory(String value) { vCategory = value; }
    private java.util.Date vConviction_Date;
    public java.util.Date getVConviction_Date() { return vConviction_Date; }
    public void setVConviction_Date(java.util.Date value) { vConviction_Date = value; }
    private String vDescription;
    public String getVDescription() { return vDescription; }
    public void setVDescription(String value) { vDescription = value; }
    private Integer vGood_Driver_Pts;
    public Integer getVGood_Driver_Pts() { return vGood_Driver_Pts; }
    public void setVGood_Driver_Pts(Integer value) { vGood_Driver_Pts = value; }
    private String vLicense_Number;
    public String getVLicense_Number() { return vLicense_Number; }
    public void setVLicense_Number(String value) { vLicense_Number = value; }
    private Integer vSequence_Number;
    public Integer getVSequence_Number() { return vSequence_Number; }
    public void setVSequence_Number(Integer value) { vSequence_Number = value; }
    private String vSurcharge;
    public String getVSurcharge() { return vSurcharge; }
    public void setVSurcharge(String value) { vSurcharge = value; }
    private String vType;
    public String getVType() { return vType; }
    public void setVType(String value) { vType = value; }
    private java.util.Date vViolation_Date;
    public java.util.Date getVViolation_Date() { return vViolation_Date; }
    public void setVViolation_Date(java.util.Date value) { vViolation_Date = value; }
}
