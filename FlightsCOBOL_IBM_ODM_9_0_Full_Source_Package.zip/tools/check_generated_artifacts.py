#!/usr/bin/env python3
"""Post-import release gate; scans only for files and reports blockers."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent.parent
java=list((ROOT/'Flights-COBOL-XOM/src').rglob('*.java'))
if not java:
    print('BLOCK: no IBM-generated Java XOM found in Flights-COBOL-XOM/src/')
    sys.exit(2)
placeholders=[str(p) for p in java if 'Hand-written contract model' in p.read_text(errors='replace')]
if placeholders:
    print('BLOCK: handwritten stubs are present in the deployable project',placeholders)
    sys.exit(2)
classes={p.name for p in java}
if 'Flc_decision_area.java' not in classes:
    print('REVIEW: importer class naming differs: update variable/BOM/adapter before deploy.')
    sys.exit(2)
jar=list((ROOT/'generated-artifacts').rglob('*xmarshaller*.jar')) if (ROOT/'generated-artifacts').exists() else []
if not jar:
    print('BLOCK: generated-artifacts/ has no IBM-generated *xmarshaller*.jar')
    print('Export actual IBM-generated marshaller from Rule Designer and copy here.')
    sys.exit(2)
print('File presence PASS. ALSO verify adapter compile, XOM mapping, association in RES and native execution.')
for path in jar: print(path.relative_to(ROOT))
