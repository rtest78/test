       >>SOURCE FORMAT FREE
identification division.
program-id. TESTCALL.
data division.
working-storage section.
       >>SOURCE FORMAT FIXED
           COPY FLIGHTOD.
           COPY AUODM-WRAPPER.
           COPY ODMPATH.
           COPY ODMSTAT.
           COPY CONTROL.
       >>SOURCE FORMAT FREE
01 app-index binary-long.
01 case-index binary-long.
01 assertions binary-long value 0.
01 failures binary-long value 0.
01 cases.
  02 pic x(16) value 'OK'.
  02 pic x(16) value 'CONN-WARN'.
  02 pic x(16) value 'RULE-WARN'.
  02 pic x(16) value 'DISC-WARN'.
  02 pic x(16) value 'CONN-FAIL'.
  02 pic x(16) value 'RULE-FAIL'.
  02 pic x(16) value 'DISC-FAIL'.
  02 pic x(16) value 'BOTH-FAIL'.
  02 pic x(16) value 'BLANK-PATH'.
  02 pic x(16) value 'OK'.
01 case-table redefines cases.
  02 case-name pic x(16) occurs 10.
procedure division.
main.
  perform varying app-index from 1 by 1 until app-index > 2
    perform varying case-index from 1 by 1 until case-index > 10
      initialize TEST-CONTROL FLC-DECISION-AREA AUODM-DECISION-AREA
      move case-name(case-index) to test-case
      move 'A' to FLC-FROM-CITY FLC-START-CITY(1) FLC-START-CITY(3)
      move 'B' to FLC-STOP-CITY(1) FLC-START-CITY(2)
      move 'C' to FLC-TO-CITY FLC-STOP-CITY(2) FLC-STOP-CITY(3)
      move 'Y' to FLC-SHORTEST
      move 3 to FLC-FLIGHT-COUNT
      move 100 to FLC-MILES(1)
      move 200 to FLC-MILES(2)
      move 500 to FLC-MILES(3)
      move 123456789 to WUC100-POLICY
      move 'NB' to WUC101-TRAN-TYPE
      move 'C' to WUC102-POL-GENERATION(1)
      move '10/14/2026' to WUC102-POL-GEN-EFF-DATE(1)
      if app-index = 1
        move '/FlightsDep/FlightsCOBOL' to ODM-RULESET-PATH
      else
        move '/AUHN_KB_RuleApp/AUHN_KB_Rules' to ODM-RULESET-PATH
      end-if
      if test-case = 'BLANK-PATH' move spaces to ODM-RULESET-PATH end-if
      if app-index = 1
        call 'FLTCALL' using FLC-DECISION-AREA
          ODM-RULESET-PATH ODM-CALL-STATUS
      else
        call 'AUHNCB' using AUODM-DECISION-AREA
          ODM-RULESET-PATH ODM-CALL-STATUS
      end-if
      add 1 to assertions
      if fixture-errors not = zero perform fail end-if
      evaluate true
        when case-index <= 4 or case-index = 10
          add 7 to assertions
          if ODM-APP-RC not = 0 or return-code not = 0
             or conn-count not = 1 or rule-count not = 1
             or disc-count not = 1 or ODM-RULE-SUCCESS not = 'Y'
             or ODM-ERROR-STAGE not = spaces perform fail end-if
        when test-case = 'CONN-FAIL'
          add 8 to assertions
          if ODM-APP-RC not = 500 or return-code not = 12
             or conn-count not = 1 or rule-count not = 0
             or disc-count not = 0 or ODM-CONN-CC not = 8
             or ODM-CONN-RC not = 1001
             or ODM-ERROR-STAGE not = '1000-CONNECT'
            perform fail
          end-if
        when test-case = 'RULE-FAIL' or 'BOTH-FAIL'
          add 9 to assertions
          if ODM-APP-RC not = 500 or return-code not = 12
             or conn-count not = 1 or rule-count not = 1
             or disc-count not = 1 or ODM-RULE-CC not = 8
             or ODM-RULE-RC not = 2001
             or ODM-ERROR-STAGE not = '2000-CALL-ODM'
             or ODM-ERROR-MESSAGE not = 'TEST RULE FAILURE'
            perform fail
          end-if
        when test-case = 'DISC-FAIL'
          add 5 to assertions
          if ODM-APP-RC not = 500 or return-code not = 12
             or ODM-DISC-CC not = 8 or ODM-DISC-RC not = 3001
             or ODM-ERROR-STAGE not = '3000-DISCONNECT'
            perform fail
          end-if
        when test-case = 'BLANK-PATH'
          add 5 to assertions
          if ODM-APP-RC not = 500 or conn-count not = 0
             or rule-count not = 0 or disc-count not = 0
             or ODM-ERROR-STAGE not = 'VALIDATE-PATH'
            perform fail
          end-if
      end-evaluate
      add 1 to assertions
      if case-index >= 2 and <= 4
        if ODM-WARNING not = 'Y' perform fail end-if
      else
        if ODM-WARNING not = 'N' perform fail end-if
      end-if
      if case-index <= 4 or case-index = 7 or = 10
        add 1 to assertions
        if app-index = 1
          if FLC-ROUTE-COUNT not = 1 or FLC-TOTAL-MILES(1) not = 300
             or FLC-VISITED-CITY(1,3) not = 'C' perform fail end-if
        else
          if WUC121-ROUTING-DESTINATION not = 'PDS'
             or WUC121-RSN-CODE(1) not = '010'
             or WUC121-RSN-CODE(2) not = 'X' perform fail end-if
        end-if
      end-if
      if test-case = 'BOTH-FAIL'
        add 3 to assertions
        if ODM-DISC-CC not = 8 or ODM-DISC-RC not = 3001
           or ODM-RULE-MESSAGE not = 'TEST RULE FAILURE'
          perform fail
        end-if
      end-if
    end-perform
  end-perform
  if failures not = 0
    display 'FAILURES: ' failures move 12 to return-code
  else
    display 'PASS: 20 caller scenarios; ' assertions ' checks'
    move 0 to return-code
  end-if
  goback.
fail.
  display 'FAIL APP ' app-index ' CASE ' test-case
    ' STAGE ' ODM-ERROR-STAGE ' APP-RC ' ODM-APP-RC
  add 1 to failures.
