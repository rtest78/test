#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="${TMPDIR:-/tmp}/flight-bridge-java-$$"
trap 'rm -rf "$BUILD"' EXIT
mkdir -p "$BUILD/classes"
find "$ROOT/Flights-XOM/src" "$ROOT/Flights-COBOL-Adapter/src" \
     "$ROOT/test-support/java-contract-stubs" -name '*.java' | sort > "$BUILD/sources.txt"
# The stubs do not perform IBM marshalling; these tests verify mapper logic only.
find "$ROOT/test-support" -maxdepth 1 -name 'FlightBridgeTest.java' >> "$BUILD/sources.txt"
javac --release 8 -d "$BUILD/classes" @"$BUILD/sources.txt"
(cd "$BUILD" && java -cp classes FlightBridgeTest)
echo 'LOCAL JAVA TEST PASSED. IBM-native marshalling still needs generation/deployment.'
