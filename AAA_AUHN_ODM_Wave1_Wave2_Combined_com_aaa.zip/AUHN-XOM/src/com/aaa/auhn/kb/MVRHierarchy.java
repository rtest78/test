package com.aaa.auhn.kb;
public class MVRHierarchy {
    private Boolean vProcessed;
    public Boolean getVProcessed() { return vProcessed; }
    public void setVProcessed(Boolean value) { vProcessed = value; }
    private String vLicenseNumber;
    public String getVLicenseNumber() { return vLicenseNumber; }
    public void setVLicenseNumber(String value) { vLicenseNumber = value; }
    private Integer vSequenceNumber;
    public Integer getVSequenceNumber() { return vSequenceNumber; }
    public void setVSequenceNumber(Integer value) { vSequenceNumber = value; }
    private Integer vNextSequenceNumber;
    public Integer getVNextSequenceNumber() { return vNextSequenceNumber; }
    public void setVNextSequenceNumber(Integer value) { vNextSequenceNumber = value; }
    private Object vAdditionalMVRData;
    public Object getVAdditionalMVRData() { return vAdditionalMVRData; }
    public void setVAdditionalMVRData(Object value) { vAdditionalMVRData = value; }
    private final java.util.List<Object> attached = new java.util.ArrayList<Object>();
    public java.util.List<Object> getAttached() { return attached; }
    public void attach(Object detail) { if (!attached.contains(detail)) attached.add(detail); }
    private Object topicRecord;
    public Object getTopicRecord(){return topicRecord;}
    public void setTopicRecord(Object value){topicRecord=value;}
}
