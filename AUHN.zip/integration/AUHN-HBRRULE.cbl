       >>SOURCE FORMAT FREE
identification division.
program-id. AUHNCALL.
environment division.
data division.
working-storage section.
*> Use the HBRWS from your installed ODM z/OS release.
       >>SOURCE FORMAT FIXED
           COPY HBRWS.
       >>SOURCE FORMAT FREE
01 ws-status pic s9(9) comp-5 value 0.
01 ws-index pic s9(9) comp-5.
linkage section.
*> Caller supplies the COMPLETE initialized area, including valid numeric
*> values in unused occurrences. Compile COPY members in fixed format.
       >>SOURCE FORMAT FIXED
           COPY AUODM-WRAPPER.
       >>SOURCE FORMAT FREE
procedure division using AUODM-DECISION-AREA.
main.
    move zero to ws-status
    *> Preserve HBRWS header VALUE clauses. Clear only the parameter table.
    perform varying ws-index from 1 by 1 until ws-index > 32
        move spaces to HBRA-RA-PARAMETER-NAME(ws-index)
        move zero to HBRA-RA-DATA-LENGTH(ws-index)
        set HBRA-RA-DATA-ADDRESS(ws-index) to null
    end-perform
    *> Replace versions with the exact path shown after deployment.
    move '/AUHN_KB_RuleApp/1.0/AUHN_KB_Rules/1.0'
        to HBRA-CONN-RULEAPP-PATH
    move 'auDecisionArea' to HBRA-RA-PARAMETER-NAME(1)
    move length of AUODM-DECISION-AREA
        to HBRA-RA-DATA-LENGTH(1)
    set HBRA-RA-DATA-ADDRESS(1)
        to address of AUODM-DECISION-AREA
    call 'HBRCONN' using HBRA-CONN-AREA
    if HBRA-CONN-COMPLETION-CODE not = zero
        display 'HBRCONN failed: ' HBRA-CONN-COMPLETION-CODE
            ' reason: ' HBRA-CONN-REASON-CODE
        move 12 to return-code
        goback
    end-if
    call 'HBRRULE' using HBRA-CONN-AREA
    if HBRA-CONN-COMPLETION-CODE not = zero
        display 'HBRRULE failed: ' HBRA-CONN-COMPLETION-CODE
            ' reason: ' HBRA-CONN-REASON-CODE
        display HBRA-RESPONSE-MESSAGE
        move 12 to ws-status
    end-if
    *> Save execution outcome before disconnect overwrites API status.
    call 'HBRDISC' using HBRA-CONN-AREA
    if HBRA-CONN-COMPLETION-CODE not = zero
        display 'HBRDISC failed: ' HBRA-CONN-COMPLETION-CODE
            ' reason: ' HBRA-CONN-REASON-CODE
        if ws-status = zero move 8 to ws-status end-if
    end-if
    move ws-status to return-code
    goback.
