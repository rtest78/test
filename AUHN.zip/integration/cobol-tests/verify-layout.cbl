       >>SOURCE FORMAT FREE
identification division.
program-id. VERIFYLAYOUT.
environment division.
input-output section.
file-control.
    select area-file assign to 'decision-area.bin'
        organization sequential access mode sequential
        file status ws-file-status.
data division.
file section.
fd area-file.
01 area-record pic x(164063).
working-storage section.
01 ws-file-status pic xx.
01 ws-base usage pointer.
01 ws-base-number redefines ws-base usage binary-double unsigned.
01 ws-address usage pointer.
01 ws-address-number redefines ws-address usage binary-double unsigned.
01 ws-offset usage binary-long signed.
01 ws-checks usage binary-long unsigned value zero.
       >>SOURCE FORMAT FIXED
           COPY AUODM-WRAPPER.
       >>SOURCE FORMAT FREE
procedure division.
main.
    initialize AUODM-DECISION-AREA
    if length of AUODM-DECISION-AREA not = 164063
        display 'FAIL: total size ' length of AUODM-DECISION-AREA
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-base to address of AUODM-DECISION-AREA
    *> FIELD-OFFSET-CHECKS
    set ws-address to address of WUC100-COMPANY
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 0
        display 'FAIL: WUC100-COMPANY offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC100-CLUB-CODE
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1
        display 'FAIL: WUC100-CLUB-CODE offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC100-REFTYPE
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 5
        display 'FAIL: WUC100-REFTYPE offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC100-PRODUCT
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 8
        display 'FAIL: WUC100-PRODUCT offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC100-POLICY
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 11
        display 'FAIL: WUC100-POLICY offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC100-BUSTRNNO
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 20
        display 'FAIL: WUC100-BUSTRNNO offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC100-TRANTYPE
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 24
        display 'FAIL: WUC100-TRANTYPE offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC100-STATE
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 28
        display 'FAIL: WUC100-STATE offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC100-SUBCOY
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 30
        display 'FAIL: WUC100-SUBCOY offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC100-BTCHTHREAD
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 34
        display 'FAIL: WUC100-BTCHTHREAD offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC100-TRANCNT
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 43
        display 'FAIL: WUC100-TRANCNT offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC100-EFFECTDTE
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 45
        display 'FAIL: WUC100-EFFECTDTE offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC100-INCEPTION
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 49
        display 'FAIL: WUC100-INCEPTION offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC100-TERMINCEP
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 53
        display 'FAIL: WUC100-TERMINCEP offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC100-DUEDATE
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 57
        display 'FAIL: WUC100-DUEDATE offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC101-TRAN-TYPE
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61
        display 'FAIL: WUC101-TRAN-TYPE offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC101-TRAN-CLUB-CODE
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 63
        display 'FAIL: WUC101-TRAN-CLUB-CODE offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC101-TRAN-PRODUCT
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 67
        display 'FAIL: WUC101-TRAN-PRODUCT offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-GENERATION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 72
        display 'FAIL: WUC102-POL-GENERATION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-GENERATION(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 155
        display 'FAIL: WUC102-POL-GENERATION(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-NEW-RENEW-CODE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 73
        display 'FAIL: WUC102-POL-NEW-RENEW-CODE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-NEW-RENEW-CODE(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 156
        display 'FAIL: WUC102-POL-NEW-RENEW-CODE(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-NAMED-INSURD-STATUS(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 76
        display 'FAIL: WUC102-POL-NAMED-INSURD-STATUS(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-NAMED-INSURD-STATUS(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 159
        display 'FAIL: WUC102-POL-NAMED-INSURD-STATUS(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-EXCESS-POL-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 77
        display 'FAIL: WUC102-POL-EXCESS-POL-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-EXCESS-POL-IND(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 160
        display 'FAIL: WUC102-POL-EXCESS-POL-IND(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-COMMENTS-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 78
        display 'FAIL: WUC102-POL-COMMENTS-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-COMMENTS-IND(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 161
        display 'FAIL: WUC102-POL-COMMENTS-IND(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-GEN-EFF-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 79
        display 'FAIL: WUC102-POL-GEN-EFF-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-GEN-EFF-DATE(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 162
        display 'FAIL: WUC102-POL-GEN-EFF-DATE(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-TRANS-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 89
        display 'FAIL: WUC102-POL-TRANS-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-TRANS-DATE(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 172
        display 'FAIL: WUC102-POL-TRANS-DATE(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-LONGEVITY-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 99
        display 'FAIL: WUC102-POL-LONGEVITY-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-LONGEVITY-DATE(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 182
        display 'FAIL: WUC102-POL-LONGEVITY-DATE(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-EXCESS-NB-POL-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 109
        display 'FAIL: WUC102-POL-EXCESS-NB-POL-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-EXCESS-NB-POL-IND(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 192
        display 'FAIL: WUC102-POL-EXCESS-NB-POL-IND(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-MGR-APPROVAL(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 110
        display 'FAIL: WUC102-POL-MGR-APPROVAL(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-MGR-APPROVAL(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 193
        display 'FAIL: WUC102-POL-MGR-APPROVAL(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-NAMED-INSRD-CHANGE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 111
        display 'FAIL: WUC102-POL-NAMED-INSRD-CHANGE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-NAMED-INSRD-CHANGE(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 194
        display 'FAIL: WUC102-POL-NAMED-INSRD-CHANGE(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-JWL-HUON-PRM-DISCR(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 112
        display 'FAIL: WUC102-POL-JWL-HUON-PRM-DISCR(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-JWL-HUON-PRM-DISCR(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 195
        display 'FAIL: WUC102-POL-JWL-HUON-PRM-DISCR(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-NB-REGD-OWNER-OTHER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 113
        display 'FAIL: WUC102-POL-NB-REGD-OWNER-OTHER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-NB-REGD-OWNER-OTHER(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 196
        display 'FAIL: WUC102-POL-NB-REGD-OWNER-OTHER(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-BUSINESS-CLASS(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 114
        display 'FAIL: WUC102-POL-BUSINESS-CLASS(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-BUSINESS-CLASS(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 197
        display 'FAIL: WUC102-POL-BUSINESS-CLASS(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-EXCHLONGV-CHANGE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 115
        display 'FAIL: WUC102-POL-EXCHLONGV-CHANGE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-EXCHLONGV-CHANGE(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 198
        display 'FAIL: WUC102-POL-EXCHLONGV-CHANGE(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-AGENT-CHANGE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 116
        display 'FAIL: WUC102-POL-AGENT-CHANGE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-AGENT-CHANGE(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 199
        display 'FAIL: WUC102-POL-AGENT-CHANGE(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-CLUE-STATUS(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 117
        display 'FAIL: WUC102-POL-CLUE-STATUS(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-CLUE-STATUS(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 200
        display 'FAIL: WUC102-POL-CLUE-STATUS(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-VADINS(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 118
        display 'FAIL: WUC102-POL-VADINS(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-VADINS(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 201
        display 'FAIL: WUC102-POL-VADINS(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-SD-LNH(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 119
        display 'FAIL: WUC102-POL-SD-LNH(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-SD-LNH(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 202
        display 'FAIL: WUC102-POL-SD-LNH(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-SD-LSH(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 120
        display 'FAIL: WUC102-POL-SD-LSH(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-SD-LSH(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 203
        display 'FAIL: WUC102-POL-SD-LSH(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-SD-LSHM(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 121
        display 'FAIL: WUC102-POL-SD-LSHM(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-SD-LSHM(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 204
        display 'FAIL: WUC102-POL-SD-LSHM(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-CLUE-NOT-RECD-DUMMY(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 122
        display 'FAIL: WUC102-POL-CLUE-NOT-RECD-DUMMY(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-CLUE-NOT-RECD-DUMMY(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 205
        display 'FAIL: WUC102-POL-CLUE-NOT-RECD-DUMMY(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-EAD-MGR-APPROVAL(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 123
        display 'FAIL: WUC102-EAD-MGR-APPROVAL(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-EAD-MGR-APPROVAL(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 206
        display 'FAIL: WUC102-EAD-MGR-APPROVAL(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-CAC-LOSS-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 124
        display 'FAIL: WUC102-POL-CAC-LOSS-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-CAC-LOSS-IND(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 207
        display 'FAIL: WUC102-POL-CAC-LOSS-IND(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-CAC-DRV-ERR-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 125
        display 'FAIL: WUC102-POL-CAC-DRV-ERR-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-CAC-DRV-ERR-IND(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 208
        display 'FAIL: WUC102-POL-CAC-DRV-ERR-IND(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-ANN-MILE-OVR-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 126
        display 'FAIL: WUC102-POL-ANN-MILE-OVR-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-ANN-MILE-OVR-IND(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 209
        display 'FAIL: WUC102-POL-ANN-MILE-OVR-IND(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-REF-FOR-BRANCH-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 127
        display 'FAIL: WUC102-POL-REF-FOR-BRANCH-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-REF-FOR-BRANCH-IND(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 210
        display 'FAIL: WUC102-POL-REF-FOR-BRANCH-IND(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-REF-FOR-AGENT-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 128
        display 'FAIL: WUC102-POL-REF-FOR-AGENT-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-REF-FOR-AGENT-IND(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 211
        display 'FAIL: WUC102-POL-REF-FOR-AGENT-IND(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-LIAB-ONLY-COVG-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 129
        display 'FAIL: WUC102-POL-LIAB-ONLY-COVG-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-LIAB-ONLY-COVG-IND(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 212
        display 'FAIL: WUC102-POL-LIAB-ONLY-COVG-IND(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-TRANS-TYPE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 130
        display 'FAIL: WUC102-POL-TRANS-TYPE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-TRANS-TYPE(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 213
        display 'FAIL: WUC102-POL-TRANS-TYPE(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-BUS-CLASS-SCR(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 132
        display 'FAIL: WUC102-POL-BUS-CLASS-SCR(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-BUS-CLASS-SCR(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 215
        display 'FAIL: WUC102-POL-BUS-CLASS-SCR(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-PRD-EFF-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 135
        display 'FAIL: WUC102-POL-PRD-EFF-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-POL-PRD-EFF-DATE(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 218
        display 'FAIL: WUC102-POL-PRD-EFF-DATE(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-PRD-RLS-EFF-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 143
        display 'FAIL: WUC102-PRD-RLS-EFF-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-PRD-RLS-EFF-DATE(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 226
        display 'FAIL: WUC102-PRD-RLS-EFF-DATE(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-RE-WRITTEN-POLICY-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 151
        display 'FAIL: WUC102-RE-WRITTEN-POLICY-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-RE-WRITTEN-POLICY-IND(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 234
        display 'FAIL: WUC102-RE-WRITTEN-POLICY-IND(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-SPIN-OFF-POLICY-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 152
        display 'FAIL: WUC102-SPIN-OFF-POLICY-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-SPIN-OFF-POLICY-IND(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 235
        display 'FAIL: WUC102-SPIN-OFF-POLICY-IND(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-NNO-POLICY-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 153
        display 'FAIL: WUC102-NNO-POLICY-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-NNO-POLICY-IND(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 236
        display 'FAIL: WUC102-NNO-POLICY-IND(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-BACKDATED-EFF-DATE-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 154
        display 'FAIL: WUC102-BACKDATED-EFF-DATE-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC102-BACKDATED-EFF-DATE-IND(2)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 237
        display 'FAIL: WUC102-BACKDATED-EFF-DATE-IND(2) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC103-POC-GENERATION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 238
        display 'FAIL: WUC103-POC-GENERATION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC103-POC-GENERATION(30)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 963
        display 'FAIL: WUC103-POC-GENERATION(30) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC103-POC-ACTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 239
        display 'FAIL: WUC103-POC-ACTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC103-POC-ACTION(30)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 964
        display 'FAIL: WUC103-POC-ACTION(30) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC103-POC-NAME(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 243
        display 'FAIL: WUC103-POC-NAME(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC103-POC-NAME(30)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 968
        display 'FAIL: WUC103-POC-NAME(30) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC103-POC-CODE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 253
        display 'FAIL: WUC103-POC-CODE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC103-POC-CODE(30)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 978
        display 'FAIL: WUC103-POC-CODE(30) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-GENERATION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 988
        display 'FAIL: WUC104-DRV-GENERATION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-GENERATION(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7015
        display 'FAIL: WUC104-DRV-GENERATION(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-DOP-ACTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 989
        display 'FAIL: WUC104-DRV-DOP-ACTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-DOP-ACTION(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7016
        display 'FAIL: WUC104-DRV-DOP-ACTION(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-DRIVER-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 993
        display 'FAIL: WUC104-DRV-DRIVER-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-DRIVER-NUMBER(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7020
        display 'FAIL: WUC104-DRV-DRIVER-NUMBER(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-LICENSE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1008
        display 'FAIL: WUC104-DRV-LICENSE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-LICENSE-NUMBER(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7035
        display 'FAIL: WUC104-DRV-LICENSE-NUMBER(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-DRIVER-CODE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1018
        display 'FAIL: WUC104-DRV-DRIVER-CODE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-DRIVER-CODE(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7045
        display 'FAIL: WUC104-DRV-DRIVER-CODE(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-YR-FIRST-LICENSED(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1019
        display 'FAIL: WUC104-DRV-YR-FIRST-LICENSED(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-YR-FIRST-LICENSED(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7046
        display 'FAIL: WUC104-DRV-YR-FIRST-LICENSED(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-GOOD-DRIVER-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1023
        display 'FAIL: WUC104-DRV-GOOD-DRIVER-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-GOOD-DRIVER-IND(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7050
        display 'FAIL: WUC104-DRV-GOOD-DRIVER-IND(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-RELATION-TO-APPLCNT(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1024
        display 'FAIL: WUC104-DRV-RELATION-TO-APPLCNT(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-RELATION-TO-APPLCNT(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7051
        display 'FAIL: WUC104-DRV-RELATION-TO-APPLCNT(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-NAMED-INSURED-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1026
        display 'FAIL: WUC104-DRV-NAMED-INSURED-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-NAMED-INSURED-IND(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7053
        display 'FAIL: WUC104-DRV-NAMED-INSURED-IND(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-ID-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1027
        display 'FAIL: WUC104-DRV-ID-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-ID-NUMBER(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7054
        display 'FAIL: WUC104-DRV-ID-NUMBER(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-OUT-OF-STAT-LIC-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1031
        display 'FAIL: WUC104-DRV-OUT-OF-STAT-LIC-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-OUT-OF-STAT-LIC-IND(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7058
        display 'FAIL: WUC104-DRV-OUT-OF-STAT-LIC-IND(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-OWN-CAR-AND-INS-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1032
        display 'FAIL: WUC104-DRV-OWN-CAR-AND-INS-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-OWN-CAR-AND-INS-IND(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7059
        display 'FAIL: WUC104-DRV-OWN-CAR-AND-INS-IND(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-RSN-DRVR-ELIMD-C(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1033
        display 'FAIL: WUC104-DRV-RSN-DRVR-ELIMD-C(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-RSN-DRVR-ELIMD-C(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7060
        display 'FAIL: WUC104-DRV-RSN-DRVR-ELIMD-C(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-PROOF-OF-DEPEND-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1035
        display 'FAIL: WUC104-DRV-PROOF-OF-DEPEND-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-PROOF-OF-DEPEND-IND(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7062
        display 'FAIL: WUC104-DRV-PROOF-OF-DEPEND-IND(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-BIRTHDATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1036
        display 'FAIL: WUC104-DRV-BIRTHDATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-BIRTHDATE(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7063
        display 'FAIL: WUC104-DRV-BIRTHDATE(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-TOTAL-POINTS(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1046
        display 'FAIL: WUC104-DRV-TOTAL-POINTS(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-TOTAL-POINTS(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7073
        display 'FAIL: WUC104-DRV-TOTAL-POINTS(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-TOTAL-SUSP-COUNT(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1050
        display 'FAIL: WUC104-DRV-TOTAL-SUSP-COUNT(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-TOTAL-SUSP-COUNT(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7077
        display 'FAIL: WUC104-DRV-TOTAL-SUSP-COUNT(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-CA-LIC-ISSUE-YEAR(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1054
        display 'FAIL: WUC104-DRV-CA-LIC-ISSUE-YEAR(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-CA-LIC-ISSUE-YEAR(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7081
        display 'FAIL: WUC104-DRV-CA-LIC-ISSUE-YEAR(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-PREV-LIC-OUT-OF-ST(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1058
        display 'FAIL: WUC104-DRV-PREV-LIC-OUT-OF-ST(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-PREV-LIC-OUT-OF-ST(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7085
        display 'FAIL: WUC104-DRV-PREV-LIC-OUT-OF-ST(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-STUDENT-AWAY-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1059
        display 'FAIL: WUC104-DRV-STUDENT-AWAY-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-STUDENT-AWAY-IND(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7086
        display 'FAIL: WUC104-DRV-STUDENT-AWAY-IND(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-STUDENT-AWAY-REAPPL(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1060
        display 'FAIL: WUC104-DRV-STUDENT-AWAY-REAPPL(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-STUDENT-AWAY-REAPPL(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7087
        display 'FAIL: WUC104-DRV-STUDENT-AWAY-REAPPL(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-OTH-COUNTRY-LIC-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1064
        display 'FAIL: WUC104-DRV-OTH-COUNTRY-LIC-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-OTH-COUNTRY-LIC-IND(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7091
        display 'FAIL: WUC104-DRV-OTH-COUNTRY-LIC-IND(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-CUR-OTH-CNTRY-LIC-I(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1065
        display 'FAIL: WUC104-DRV-CUR-OTH-CNTRY-LIC-I(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-CUR-OTH-CNTRY-LIC-I(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7092
        display 'FAIL: WUC104-DRV-CUR-OTH-CNTRY-LIC-I(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-FIRST-NAME(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1066
        display 'FAIL: WUC104-DRV-FIRST-NAME(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-FIRST-NAME(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7093
        display 'FAIL: WUC104-DRV-FIRST-NAME(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-LAST-NAME(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 1081
        display 'FAIL: WUC104-DRV-LAST-NAME(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC104-DRV-LAST-NAME(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7108
        display 'FAIL: WUC104-DRV-LAST-NAME(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC105-EMP-GENERATION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7138
        display 'FAIL: WUC105-EMP-GENERATION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC105-EMP-GENERATION(100)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 11098
        display 'FAIL: WUC105-EMP-GENERATION(100) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC105-EMP-ACTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7139
        display 'FAIL: WUC105-EMP-ACTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC105-EMP-ACTION(100)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 11099
        display 'FAIL: WUC105-EMP-ACTION(100) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC105-EMP-DRIVER-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7143
        display 'FAIL: WUC105-EMP-DRIVER-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC105-EMP-DRIVER-NUMBER(100)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 11103
        display 'FAIL: WUC105-EMP-DRIVER-NUMBER(100) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC105-EMP-OCCUP-TITLE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 7158
        display 'FAIL: WUC105-EMP-OCCUP-TITLE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC105-EMP-OCCUP-TITLE(100)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 11118
        display 'FAIL: WUC105-EMP-OCCUP-TITLE(100) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC106-END-GENERATION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 11138
        display 'FAIL: WUC106-END-GENERATION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC106-END-GENERATION(40)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12152
        display 'FAIL: WUC106-END-GENERATION(40) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC106-END-ACTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 11139
        display 'FAIL: WUC106-END-ACTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC106-END-ACTION(40)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12153
        display 'FAIL: WUC106-END-ACTION(40) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC106-END-ENDORSEMENT-NAME(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 11143
        display 'FAIL: WUC106-END-ENDORSEMENT-NAME(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC106-END-ENDORSEMENT-NAME(40)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12157
        display 'FAIL: WUC106-END-ENDORSEMENT-NAME(40) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC106-END-OBJECT-ID(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 11149
        display 'FAIL: WUC106-END-OBJECT-ID(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC106-END-OBJECT-ID(40)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12163
        display 'FAIL: WUC106-END-OBJECT-ID(40) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-GENERATION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12178
        display 'FAIL: WUC107-VEH-GENERATION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-GENERATION(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17813
        display 'FAIL: WUC107-VEH-GENERATION(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-DTL-ACTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12179
        display 'FAIL: WUC107-VEH-DTL-ACTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-DTL-ACTION(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17814
        display 'FAIL: WUC107-VEH-DTL-ACTION(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-VEHICLE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12183
        display 'FAIL: WUC107-VEH-VEHICLE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-VEHICLE-NUMBER(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17818
        display 'FAIL: WUC107-VEH-VEHICLE-NUMBER(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-VINN(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12187
        display 'FAIL: WUC107-VEH-VINN(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-VINN(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17822
        display 'FAIL: WUC107-VEH-VINN(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-CAR-GROUP(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12204
        display 'FAIL: WUC107-VEH-CAR-GROUP(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-CAR-GROUP(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17839
        display 'FAIL: WUC107-VEH-CAR-GROUP(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-USE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12208
        display 'FAIL: WUC107-VEH-USE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-USE(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17843
        display 'FAIL: WUC107-VEH-USE(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-YEAR(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12209
        display 'FAIL: WUC107-VEH-YEAR(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-YEAR(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17844
        display 'FAIL: WUC107-VEH-YEAR(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-TRADE-NAME(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12213
        display 'FAIL: WUC107-VEH-TRADE-NAME(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-TRADE-NAME(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17848
        display 'FAIL: WUC107-VEH-TRADE-NAME(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-SYMBOL(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12218
        display 'FAIL: WUC107-VEH-SYMBOL(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-SYMBOL(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17853
        display 'FAIL: WUC107-VEH-SYMBOL(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-PURCHASE-PRICE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12222
        display 'FAIL: WUC107-VEH-PURCHASE-PRICE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-PURCHASE-PRICE(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17857
        display 'FAIL: WUC107-VEH-PURCHASE-PRICE(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-LOAD-CAPACITY(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12228
        display 'FAIL: WUC107-VEH-LOAD-CAPACITY(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-LOAD-CAPACITY(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17863
        display 'FAIL: WUC107-VEH-LOAD-CAPACITY(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-LIMIT-OF-LIABILITY(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12233
        display 'FAIL: WUC107-VEH-LIMIT-OF-LIABILITY(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-LIMIT-OF-LIABILITY(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17868
        display 'FAIL: WUC107-VEH-LIMIT-OF-LIABILITY(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-CYCLE-LICENSE-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12242
        display 'FAIL: WUC107-VEH-CYCLE-LICENSE-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-CYCLE-LICENSE-IND(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17877
        display 'FAIL: WUC107-VEH-CYCLE-LICENSE-IND(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-SEQUENCE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12243
        display 'FAIL: WUC107-VEH-SEQUENCE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-SEQUENCE-NUMBER(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17878
        display 'FAIL: WUC107-VEH-SEQUENCE-NUMBER(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-REG-OWN-RELATIONSHP(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12247
        display 'FAIL: WUC107-VEH-REG-OWN-RELATIONSHP(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-REG-OWN-RELATIONSHP(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17882
        display 'FAIL: WUC107-VEH-REG-OWN-RELATIONSHP(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-REG-OWN-DOB(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12249
        display 'FAIL: WUC107-VEH-REG-OWN-DOB(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-REG-OWN-DOB(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17884
        display 'FAIL: WUC107-VEH-REG-OWN-DOB(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-PARKED-LOCATION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12259
        display 'FAIL: WUC107-VEH-PARKED-LOCATION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-PARKED-LOCATION(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17894
        display 'FAIL: WUC107-VEH-PARKED-LOCATION(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-ANTI-THEFT-CODE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12260
        display 'FAIL: WUC107-VEH-ANTI-THEFT-CODE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-ANTI-THEFT-CODE(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17895
        display 'FAIL: WUC107-VEH-ANTI-THEFT-CODE(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-PURCHASE-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12261
        display 'FAIL: WUC107-VEH-PURCHASE-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-PURCHASE-DATE(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17896
        display 'FAIL: WUC107-VEH-PURCHASE-DATE(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-EVR-C(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12271
        display 'FAIL: WUC107-VEH-EVR-C(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-EVR-C(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17906
        display 'FAIL: WUC107-VEH-EVR-C(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VDT-BODY-TYPE-X(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12273
        display 'FAIL: WUC107-VDT-BODY-TYPE-X(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VDT-BODY-TYPE-X(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17908
        display 'FAIL: WUC107-VDT-BODY-TYPE-X(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VDT-MILES-CALC-MTH(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12274
        display 'FAIL: WUC107-VDT-MILES-CALC-MTH(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VDT-MILES-CALC-MTH(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17909
        display 'FAIL: WUC107-VDT-MILES-CALC-MTH(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VDT-ANN-MILES-C(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12275
        display 'FAIL: WUC107-VDT-ANN-MILES-C(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VDT-ANN-MILES-C(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17910
        display 'FAIL: WUC107-VDT-ANN-MILES-C(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-PRI-RATE-DRV(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12279
        display 'FAIL: WUC107-PRI-RATE-DRV(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-PRI-RATE-DRV(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17914
        display 'FAIL: WUC107-PRI-RATE-DRV(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-ELIM-REASON-CD(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12280
        display 'FAIL: WUC107-VEH-ELIM-REASON-CD(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-ELIM-REASON-CD(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17915
        display 'FAIL: WUC107-VEH-ELIM-REASON-CD(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-ANNUAL-MILEAGE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12282
        display 'FAIL: WUC107-VEH-ANNUAL-MILEAGE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-ANNUAL-MILEAGE(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17917
        display 'FAIL: WUC107-VEH-ANNUAL-MILEAGE(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-VNDR-SRC-MILG(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12291
        display 'FAIL: WUC107-VEH-VNDR-SRC-MILG(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-VNDR-SRC-MILG(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17926
        display 'FAIL: WUC107-VEH-VNDR-SRC-MILG(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-MVSTORAGE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 12292
        display 'FAIL: WUC107-VEH-MVSTORAGE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC107-VEH-MVSTORAGE(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17927
        display 'FAIL: WUC107-VEH-MVSTORAGE(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC108-COV-GENERATION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17928
        display 'FAIL: WUC108-COV-GENERATION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC108-COV-GENERATION(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 27903
        display 'FAIL: WUC108-COV-GENERATION(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC108-COV-ACTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17929
        display 'FAIL: WUC108-COV-ACTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC108-COV-ACTION(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 27904
        display 'FAIL: WUC108-COV-ACTION(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC108-COV-VEHICLE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17933
        display 'FAIL: WUC108-COV-VEHICLE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC108-COV-VEHICLE-NUMBER(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 27908
        display 'FAIL: WUC108-COV-VEHICLE-NUMBER(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC108-COV-LINE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17937
        display 'FAIL: WUC108-COV-LINE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC108-COV-LINE(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 27912
        display 'FAIL: WUC108-COV-LINE(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC108-COV-LIMIT(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 17943
        display 'FAIL: WUC108-COV-LIMIT(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC108-COV-LIMIT(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 27918
        display 'FAIL: WUC108-COV-LIMIT(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC109-INS-GENERATION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 27928
        display 'FAIL: WUC109-INS-GENERATION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC109-INS-GENERATION(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 28810
        display 'FAIL: WUC109-INS-GENERATION(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC109-INS-ACTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 27929
        display 'FAIL: WUC109-INS-ACTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC109-INS-ACTION(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 28811
        display 'FAIL: WUC109-INS-ACTION(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC109-INS-VEHICLE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 27933
        display 'FAIL: WUC109-INS-VEHICLE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC109-INS-VEHICLE-NUMBER(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 28815
        display 'FAIL: WUC109-INS-VEHICLE-NUMBER(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC109-INS-MODIFIED-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 27937
        display 'FAIL: WUC109-INS-MODIFIED-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC109-INS-MODIFIED-IND(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 28819
        display 'FAIL: WUC109-INS-MODIFIED-IND(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC109-INS-PHOTO-CODE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 27938
        display 'FAIL: WUC109-INS-PHOTO-CODE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC109-INS-PHOTO-CODE(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 28820
        display 'FAIL: WUC109-INS-PHOTO-CODE(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC109-FILLER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 27939
        display 'FAIL: WUC109-FILLER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC109-FILLER(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 28821
        display 'FAIL: WUC109-FILLER(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC110-DOV-GENERATION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 28828
        display 'FAIL: WUC110-DOV-GENERATION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC110-DOV-GENERATION(500)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 41303
        display 'FAIL: WUC110-DOV-GENERATION(500) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC110-DOV-ACTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 28829
        display 'FAIL: WUC110-DOV-ACTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC110-DOV-ACTION(500)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 41304
        display 'FAIL: WUC110-DOV-ACTION(500) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC110-DOV-VEHICLE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 28833
        display 'FAIL: WUC110-DOV-VEHICLE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC110-DOV-VEHICLE-NUMBER(500)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 41308
        display 'FAIL: WUC110-DOV-VEHICLE-NUMBER(500) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC110-DOV-DRIVER-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 28837
        display 'FAIL: WUC110-DOV-DRIVER-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC110-DOV-DRIVER-NUMBER(500)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 41312
        display 'FAIL: WUC110-DOV-DRIVER-NUMBER(500) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC110-DOV-PRIMARY-DRVR-IND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 28852
        display 'FAIL: WUC110-DOV-PRIMARY-DRVR-IND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC110-DOV-PRIMARY-DRVR-IND(500)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 41327
        display 'FAIL: WUC110-DOV-PRIMARY-DRVR-IND(500) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-LICENSE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 41328
        display 'FAIL: WUC111-MVR1-LICENSE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-LICENSE-NUMBER(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44170
        display 'FAIL: WUC111-MVR1-LICENSE-NUMBER(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-DRIVER-CODE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 41338
        display 'FAIL: WUC111-MVR1-DRIVER-CODE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-DRIVER-CODE(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44180
        display 'FAIL: WUC111-MVR1-DRIVER-CODE(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-REPORT-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 41339
        display 'FAIL: WUC111-MVR1-REPORT-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-REPORT-DATE(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44181
        display 'FAIL: WUC111-MVR1-REPORT-DATE(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-CLASS(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 41349
        display 'FAIL: WUC111-MVR1-CLASS(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-CLASS(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44191
        display 'FAIL: WUC111-MVR1-CLASS(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-STATUS(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 41350
        display 'FAIL: WUC111-MVR1-STATUS(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-STATUS(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44192
        display 'FAIL: WUC111-MVR1-STATUS(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-RESTRICTIONS(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 41358
        display 'FAIL: WUC111-MVR1-RESTRICTIONS(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-RESTRICTIONS(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44200
        display 'FAIL: WUC111-MVR1-RESTRICTIONS(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-RECORD-CLEAR(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 41375
        display 'FAIL: WUC111-MVR1-RECORD-CLEAR(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-RECORD-CLEAR(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44217
        display 'FAIL: WUC111-MVR1-RECORD-CLEAR(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-LIC-EXP-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 41376
        display 'FAIL: WUC111-MVR1-LIC-EXP-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC111-MVR1-LIC-EXP-DATE(50)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44218
        display 'FAIL: WUC111-MVR1-LIC-EXP-DATE(50) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-LICENSE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44228
        display 'FAIL: WUC112-MVR2-LICENSE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-LICENSE-NUMBER(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61143
        display 'FAIL: WUC112-MVR2-LICENSE-NUMBER(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-SEQUENCE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44238
        display 'FAIL: WUC112-MVR2-SEQUENCE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-SEQUENCE-NUMBER(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61153
        display 'FAIL: WUC112-MVR2-SEQUENCE-NUMBER(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-TYPE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44241
        display 'FAIL: WUC112-MVR2-TYPE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-TYPE(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61156
        display 'FAIL: WUC112-MVR2-TYPE(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-VIOLATION-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44245
        display 'FAIL: WUC112-MVR2-VIOLATION-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-VIOLATION-DATE(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61160
        display 'FAIL: WUC112-MVR2-VIOLATION-DATE(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-CONVICTION-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44255
        display 'FAIL: WUC112-MVR2-CONVICTION-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-CONVICTION-DATE(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61170
        display 'FAIL: WUC112-MVR2-CONVICTION-DATE(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-GOOD-DRIVER-PTS(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44265
        display 'FAIL: WUC112-MVR2-GOOD-DRIVER-PTS(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-GOOD-DRIVER-PTS(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61180
        display 'FAIL: WUC112-MVR2-GOOD-DRIVER-PTS(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-CATEGORY(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44266
        display 'FAIL: WUC112-MVR2-CATEGORY(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-CATEGORY(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61181
        display 'FAIL: WUC112-MVR2-CATEGORY(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-SURCHARGE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44267
        display 'FAIL: WUC112-MVR2-SURCHARGE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-SURCHARGE(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61182
        display 'FAIL: WUC112-MVR2-SURCHARGE(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-DESCRIPTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 44268
        display 'FAIL: WUC112-MVR2-DESCRIPTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC112-MVR2-DESCRIPTION(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61183
        display 'FAIL: WUC112-MVR2-DESCRIPTION(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC113-MVR3-LICENSE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61228
        display 'FAIL: WUC113-MVR3-LICENSE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC113-MVR3-LICENSE-NUMBER(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 73367
        display 'FAIL: WUC113-MVR3-LICENSE-NUMBER(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC113-MVR3-SEQUENCE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61238
        display 'FAIL: WUC113-MVR3-SEQUENCE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC113-MVR3-SEQUENCE-NUMBER(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 73377
        display 'FAIL: WUC113-MVR3-SEQUENCE-NUMBER(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC113-MVR3-GOOD-DRIVER-PTS(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61241
        display 'FAIL: WUC113-MVR3-GOOD-DRIVER-PTS(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC113-MVR3-GOOD-DRIVER-PTS(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 73380
        display 'FAIL: WUC113-MVR3-GOOD-DRIVER-PTS(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC113-MVR3-CATEGORY(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61242
        display 'FAIL: WUC113-MVR3-CATEGORY(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC113-MVR3-CATEGORY(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 73381
        display 'FAIL: WUC113-MVR3-CATEGORY(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC113-MVR3-SURCHARGE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61243
        display 'FAIL: WUC113-MVR3-SURCHARGE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC113-MVR3-SURCHARGE(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 73382
        display 'FAIL: WUC113-MVR3-SURCHARGE(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC113-MVR3-DESCRIPTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 61244
        display 'FAIL: WUC113-MVR3-DESCRIPTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC113-MVR3-DESCRIPTION(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 73383
        display 'FAIL: WUC113-MVR3-DESCRIPTION(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC114-MVR4-LICENSE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 73428
        display 'FAIL: WUC114-MVR4-LICENSE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC114-MVR4-LICENSE-NUMBER(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 84970
        display 'FAIL: WUC114-MVR4-LICENSE-NUMBER(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC114-MVR4-SEQUENCE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 73438
        display 'FAIL: WUC114-MVR4-SEQUENCE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC114-MVR4-SEQUENCE-NUMBER(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 84980
        display 'FAIL: WUC114-MVR4-SEQUENCE-NUMBER(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC114-MVR4-DESCRIPTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 73441
        display 'FAIL: WUC114-MVR4-DESCRIPTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC114-MVR4-DESCRIPTION(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 84983
        display 'FAIL: WUC114-MVR4-DESCRIPTION(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC115-MVR5-LICENSE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 85028
        display 'FAIL: WUC115-MVR5-LICENSE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC115-MVR5-LICENSE-NUMBER(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 101346
        display 'FAIL: WUC115-MVR5-LICENSE-NUMBER(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC115-MVR5-SEQUENCE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 85038
        display 'FAIL: WUC115-MVR5-SEQUENCE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC115-MVR5-SEQUENCE-NUMBER(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 101356
        display 'FAIL: WUC115-MVR5-SEQUENCE-NUMBER(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC115-MVR5-TYPE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 85041
        display 'FAIL: WUC115-MVR5-TYPE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC115-MVR5-TYPE(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 101359
        display 'FAIL: WUC115-MVR5-TYPE(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC115-MVR5-ACCIDENT-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 85045
        display 'FAIL: WUC115-MVR5-ACCIDENT-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC115-MVR5-ACCIDENT-DATE(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 101363
        display 'FAIL: WUC115-MVR5-ACCIDENT-DATE(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC115-MVR5-DESCRIPTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 85055
        display 'FAIL: WUC115-MVR5-DESCRIPTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC115-MVR5-DESCRIPTION(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 101373
        display 'FAIL: WUC115-MVR5-DESCRIPTION(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC115-MVR5-LIC-REIN-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 85100
        display 'FAIL: WUC115-MVR5-LIC-REIN-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC115-MVR5-LIC-REIN-DATE(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 101418
        display 'FAIL: WUC115-MVR5-LIC-REIN-DATE(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC116-MVR6-LICENSE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 101428
        display 'FAIL: WUC116-MVR6-LICENSE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC116-MVR6-LICENSE-NUMBER(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 112970
        display 'FAIL: WUC116-MVR6-LICENSE-NUMBER(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC116-MVR6-SEQUENCE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 101438
        display 'FAIL: WUC116-MVR6-SEQUENCE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC116-MVR6-SEQUENCE-NUMBER(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 112980
        display 'FAIL: WUC116-MVR6-SEQUENCE-NUMBER(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC116-MVR6-DESCRIPTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 101441
        display 'FAIL: WUC116-MVR6-DESCRIPTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC116-MVR6-DESCRIPTION(200)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 112983
        display 'FAIL: WUC116-MVR6-DESCRIPTION(200) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC117-ACC-GENERATION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 113028
        display 'FAIL: WUC117-ACC-GENERATION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC117-ACC-GENERATION(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 128190
        display 'FAIL: WUC117-ACC-GENERATION(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC117-ACC-ACTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 113029
        display 'FAIL: WUC117-ACC-ACTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC117-ACC-ACTION(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 128191
        display 'FAIL: WUC117-ACC-ACTION(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC117-ACC-DRIVER-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 113033
        display 'FAIL: WUC117-ACC-DRIVER-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC117-ACC-DRIVER-NUMBER(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 128195
        display 'FAIL: WUC117-ACC-DRIVER-NUMBER(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC117-ACC-LOSS-TYPE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 113048
        display 'FAIL: WUC117-ACC-LOSS-TYPE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC117-ACC-LOSS-TYPE(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 128210
        display 'FAIL: WUC117-ACC-LOSS-TYPE(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC117-ACC-ID(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 113051
        display 'FAIL: WUC117-ACC-ID(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC117-ACC-ID(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 128213
        display 'FAIL: WUC117-ACC-ID(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC117-ACC-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 113055
        display 'FAIL: WUC117-ACC-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC117-ACC-DATE(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 128217
        display 'FAIL: WUC117-ACC-DATE(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC117-ACC-CHRGIND(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 113065
        display 'FAIL: WUC117-ACC-CHRGIND(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC117-ACC-CHRGIND(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 128227
        display 'FAIL: WUC117-ACC-CHRGIND(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC118-CIT-GENERATION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 128228
        display 'FAIL: WUC118-CIT-GENERATION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC118-CIT-GENERATION(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 143390
        display 'FAIL: WUC118-CIT-GENERATION(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC118-CIT-ACTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 128229
        display 'FAIL: WUC118-CIT-ACTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC118-CIT-ACTION(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 143391
        display 'FAIL: WUC118-CIT-ACTION(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC118-CIT-DRIVER-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 128233
        display 'FAIL: WUC118-CIT-DRIVER-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC118-CIT-DRIVER-NUMBER(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 143395
        display 'FAIL: WUC118-CIT-DRIVER-NUMBER(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC118-CIT-CATEGORY(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 128248
        display 'FAIL: WUC118-CIT-CATEGORY(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC118-CIT-CATEGORY(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 143410
        display 'FAIL: WUC118-CIT-CATEGORY(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC118-CIT-ID(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 128252
        display 'FAIL: WUC118-CIT-ID(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC118-CIT-ID(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 143414
        display 'FAIL: WUC118-CIT-ID(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC118-CIT-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 128256
        display 'FAIL: WUC118-CIT-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC118-CIT-DATE(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 143418
        display 'FAIL: WUC118-CIT-DATE(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC119-SUSP-GENERATION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 143428
        display 'FAIL: WUC119-SUSP-GENERATION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC119-SUSP-GENERATION(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 160984
        display 'FAIL: WUC119-SUSP-GENERATION(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC119-SUSP-ACTION(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 143429
        display 'FAIL: WUC119-SUSP-ACTION(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC119-SUSP-ACTION(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 160985
        display 'FAIL: WUC119-SUSP-ACTION(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC119-SUSP-DRIVER-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 143433
        display 'FAIL: WUC119-SUSP-DRIVER-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC119-SUSP-DRIVER-NUMBER(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 160989
        display 'FAIL: WUC119-SUSP-DRIVER-NUMBER(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC119-SUSP-ID(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 143448
        display 'FAIL: WUC119-SUSP-ID(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC119-SUSP-ID(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 161004
        display 'FAIL: WUC119-SUSP-ID(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC119-SUSP-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 143452
        display 'FAIL: WUC119-SUSP-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC119-SUSP-DATE(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 161008
        display 'FAIL: WUC119-SUSP-DATE(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC119-REIN-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 143462
        display 'FAIL: WUC119-REIN-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC119-REIN-DATE(400)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 161018
        display 'FAIL: WUC119-REIN-DATE(400) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC120-PACE-DRVR-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 161028
        display 'FAIL: WUC120-PACE-DRVR-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC120-PACE-DRVR-NUMBER(80)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 163319
        display 'FAIL: WUC120-PACE-DRVR-NUMBER(80) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC120-PACE-DATE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 161032
        display 'FAIL: WUC120-PACE-DATE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC120-PACE-DATE(80)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 163323
        display 'FAIL: WUC120-PACE-DATE(80) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC120-PACE-TYPE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 161042
        display 'FAIL: WUC120-PACE-TYPE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC120-PACE-TYPE(80)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 163333
        display 'FAIL: WUC120-PACE-TYPE(80) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC120-PACE-STATUS(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 161047
        display 'FAIL: WUC120-PACE-STATUS(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC120-PACE-STATUS(80)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 163338
        display 'FAIL: WUC120-PACE-STATUS(80) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC120-PACE-PAID-AMOUNT(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 161049
        display 'FAIL: WUC120-PACE-PAID-AMOUNT(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC120-PACE-PAID-AMOUNT(80)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 163340
        display 'FAIL: WUC120-PACE-PAID-AMOUNT(80) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC122-POL-CAC-EXISTS
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 163348
        display 'FAIL: WUC122-POL-CAC-EXISTS offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC122-POL-CAU-EXISTS
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 163349
        display 'FAIL: WUC122-POL-CAU-EXISTS offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC122-POL-JWL-HUON-PRM-DISCR
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 163350
        display 'FAIL: WUC122-POL-JWL-HUON-PRM-DISCR offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC122-POL-PRV-AGENT
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 163351
        display 'FAIL: WUC122-POL-PRV-AGENT offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC122-POL-CUR-AGENT
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 163360
        display 'FAIL: WUC122-POL-CUR-AGENT offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC122-FILLER
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 163369
        display 'FAIL: WUC122-FILLER offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC121-ROUTING-DESTINATION
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 163398
        display 'FAIL: WUC121-ROUTING-DESTINATION offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC121-RSN-CODE(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 163403
        display 'FAIL: WUC121-RSN-CODE(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC121-RSN-CODE(60)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 164052
        display 'FAIL: WUC121-RSN-CODE(60) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC121-RSN-VEHICLE-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 163406
        display 'FAIL: WUC121-RSN-VEHICLE-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC121-RSN-VEHICLE-NUMBER(60)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 164055
        display 'FAIL: WUC121-RSN-VEHICLE-NUMBER(60) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC121-RSN-DRIVER-NUMBER(1)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 163410
        display 'FAIL: WUC121-RSN-DRIVER-NUMBER(1) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    set ws-address to address of WUC121-RSN-DRIVER-NUMBER(60)
    compute ws-offset = ws-address-number - ws-base-number
    if ws-offset not = 164059
        display 'FAIL: WUC121-RSN-DRIVER-NUMBER(60) offset ' ws-offset
        move 12 to return-code goback
    end-if
    add 1 to ws-checks
    *> END-FIELD-OFFSET-CHECKS
    move 'NB' to WUC101-TRAN-TYPE
    move 'C' to WUC102-POL-GENERATION(1)
    move '10/12/2026' to WUC102-POL-GEN-EFF-DATE(1)
    move 'C' to WUC104-DRV-GENERATION(1)
    move 'ADD' to WUC104-DRV-DOP-ACTION(1)
    move 12 to WUC104-DRV-DRIVER-NUMBER(1)
    move 'LIC1234' to WUC104-DRV-LICENSE-NUMBER(1)
    move 'C' to WUC107-VEH-GENERATION(1)
    move 'ADD' to WUC107-VEH-DTL-ACTION(1)
    move 7 to WUC107-VEH-VEHICLE-NUMBER(1)
    move 1234 to WUC100-TRANCNT
    move 20261012 to WUC100-EFFECTDTE
    move 'PDS' to WUC121-ROUTING-DESTINATION
    move '010' to WUC121-RSN-CODE(1)
    move 7 to WUC121-RSN-VEHICLE-NUMBER(1)
    move 12 to WUC121-RSN-DRIVER-NUMBER(1)
    move 'X' to WUC121-RSN-CODE(2)
    if WUC121-RSN-VEHICLE-NUMBER(1) not = 7 or
        WUC121-RSN-DRIVER-NUMBER(1) not = 12
        display 'FAIL: numeric move' move 12 to return-code goback
    end-if
    add 1 to ws-checks
    open output area-file
    if ws-file-status not = '00'
        display 'FAIL: file open ' ws-file-status
        move 12 to return-code goback
    end-if
    move AUODM-DECISION-AREA to area-record
    write area-record
    if ws-file-status not = '00'
        display 'FAIL: file write ' ws-file-status
        move 12 to return-code goback
    end-if
    close area-file
    display 'PASS: copybook layout and field checks = ' ws-checks
    display 'DECISION-AREA-BYTES=' length of AUODM-DECISION-AREA
    move zero to return-code
    goback.
