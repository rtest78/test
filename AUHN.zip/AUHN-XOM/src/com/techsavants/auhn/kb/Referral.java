package com.techsavants.auhn.kb;
public class Referral { private final String code,driver,vehicle; public Referral(String c,String d,String v){code=c;driver=d;vehicle=v;} public String getCode(){return code;} public String getDriver(){return driver;} public String getVehicle(){return vehicle;} }
