import com.techsavants.auhn.cobol.*;
import com.techsavants.auhn.kb.*;
import com.techsavants.auhn.adapter.AuDecisionAreaMapper;
import java.lang.reflect.*;
import java.nio.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
/** TEST-ONLY ASCII codec. This neither replaces nor executes IBM's marshaller. */
public class BufferBridgeTest {
    static int checks;
    static void equal(Object a, Object b) {checks++;if(!Objects.equals(a,b))throw new AssertionError(a+" != "+b);}
    static String method(String prefix,String field) {return prefix+Character.toUpperCase(field.charAt(0))+field.substring(1);}
    public static void main(String[] args) throws Exception {
        byte[] input=Files.readAllBytes(Paths.get(args[1])); equal(164063,input.length);
        List<String[]> descriptors=new ArrayList<String[]>();
        for(String s:Files.readAllLines(Paths.get(args[0])))descriptors.add(s.split("\\t"));
        Auodm_decision_area area=new Auodm_decision_area(); Map<String,Object> arrays=new HashMap<String,Object>();
        for(String[] f:descriptors) {
            int count=Integer.parseInt(f[4]);
            if(!f[0].equals("Auodm_decision_area")&&!arrays.containsKey(f[0])) {
                Class<?> cls=Class.forName("com.techsavants.auhn.cobol."+f[0]);Object values=Array.newInstance(cls,count);
                for(int i=0;i<count;i++)Array.set(values,i,cls.newInstance());
                arrays.put(f[0],values);area.getClass().getMethod("set"+f[0],values.getClass()).invoke(area,values);
            }
            for(int i=0;i<count;i++) {
                Object bean=f[0].equals("Auodm_decision_area")?area:Array.get(arrays.get(f[0]),i);
                int start=Integer.parseInt(f[2])+i*Integer.parseInt(f[5]),size=Integer.parseInt(f[3]);
                Method getter=bean.getClass().getMethod(method("get",f[1]));Class<?> t=getter.getReturnType();Object value;
                if(f[6].equals("binary")) {
                    ByteBuffer b=ByteBuffer.wrap(input,start,size).order(ByteOrder.BIG_ENDIAN);
                    value=size==2?Short.valueOf(b.getShort()):Integer.valueOf(b.getInt());
                    // Conditional-expression numeric promotion must not change the boxed type.
                    if(t==short.class)value=Short.valueOf(((Number)value).shortValue());
                } else {
                    String s=new String(input,start,size,StandardCharsets.US_ASCII);
                    if(t==String.class)value=s;
                    else if(t==short.class)value=Short.valueOf(s);
                    else if(t==int.class)value=Integer.valueOf(s);
                    else value=Long.valueOf(s);
                }
                bean.getClass().getMethod(method("set",f[1]),t).invoke(bean,value);
            }
        }
        AuhnRequest request=AuDecisionAreaMapper.toRequest(area);
        equal("NB",request.getTransactionType());equal("FULL",request.getExecutionPhase());
        equal(1,request.getPolicyDataFacts().size());equal(1,request.getDriverDataFacts().size());equal(1,request.getVehicleDataFacts().size());
        equal("000000000000012",request.getDriverDataFacts().get(0).getVDriver_Number());
        equal("0007",request.getVehicleDataFacts().get(0).getVVehicle_Number());
        equal(AuhnValues.date(2026,10,12),request.getPolicyDataFacts().get(0).getVGen_Eff_Date());
        // Synthetic response tests only the real Java output mapper, not decisions.
        AuhnResponse response=new AuhnResponse();response.setRoutingDestination("PAO");
        response.getReferrals().add(new Referral("011","000000000000012","0007"));
        response.getReferrals().add(new Referral("012","9999","9999"));
        AuDecisionAreaMapper.writeResponse(area,response);
        byte[] output=input.clone();
        for(String[] f:descriptors) {
            int count=Integer.parseInt(f[4]);
            for(int i=0;i<count;i++) {
                Object bean=f[0].equals("Auodm_decision_area")?area:Array.get(area.getClass().getMethod("get"+f[0]).invoke(area),i);
                int start=Integer.parseInt(f[2])+i*Integer.parseInt(f[5]),size=Integer.parseInt(f[3]);
                Object value=bean.getClass().getMethod(method("get",f[1])).invoke(bean);
                if(f[6].equals("binary")) {
                    ByteBuffer b=ByteBuffer.wrap(output,start,size).order(ByteOrder.BIG_ENDIAN);
                    if(size==2)b.putShort(((Number)value).shortValue());else b.putInt(((Number)value).intValue());
                } else {
                    String s=value.toString();
                    if(value instanceof String)while(s.length()<size)s+=" ";
                    else while(s.length()<size)s="0"+s;
                    if(s.length()!=size)throw new AssertionError("Field size "+f[1]);
                    System.arraycopy(s.getBytes(StandardCharsets.US_ASCII),0,output,start,size);
                }
            }
        }
        for(int i=0;i<163398;i++)equal(input[i],output[i]);
        equal("PAO  0110007001201299999999X  00000000",new String(output,163398,38,StandardCharsets.US_ASCII));
        Files.write(Paths.get(args[2]),output);
        System.out.println("PASS: native COBOL -> test ASCII codec -> real Java mapper -> native COBOL buffer; "+checks+" assertions, all 163398 input bytes retained. No IBM marshaller or rules executed.");
    }
}
