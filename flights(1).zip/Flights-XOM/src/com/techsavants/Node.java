package com.techsavants;


import java.util.ArrayList;
import java.util.List;

public class Node {

    private String currentCity;
    private List<String> visitedCities = new ArrayList<String>();
    private int totalMiles;

    public Node() {
    }

    public String getCurrentCity() {
        return currentCity;
    }

    public void setCurrentCity(String currentCity) {
        this.currentCity = currentCity;
    }

    public List<String> getVisitedCities() {
        return visitedCities;
    }

    public void setVisitedCities(List<String> visitedCities) {
        this.visitedCities = visitedCities;
    }

    public int getTotalMiles() {
        return totalMiles;
    }

    public void setTotalMiles(int totalMiles) {
        this.totalMiles = totalMiles;
    }

    public void addCity(String city) {
        visitedCities.add(city);
    }

    public boolean hasVisitedCity(String city) {
        return visitedCities.contains(city);
    }
}
