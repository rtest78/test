000100******************************************************************00010000
000200* WUC116 - MVR116 DATA COBOL II RECORD LAYOUT.                   *00020000
000300******************************************************************00030000
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00040000
000500* MVR116 DATA TO BE PASSED TO AION.                              *00050000
000600*                                                                *00060000
000700******************************************************************00070000
000800*01 WUC116-MVR6-REC.                                              00080000
000900   05 WUC116-MVR6-INFORMATION OCCURS 200 TIMES                    00090000
001000             INDEXED BY MVR6-IDX.                                 00100000
001100      10 WUC116-MVR6-LICENSE-NUMBER        PIC  X(10).            00110000
001200      10 WUC116-MVR6-SEQUENCE-NUMBER       PIC  9(03).            00120000
001300      10 WUC116-MVR6-DESCRIPTION           PIC  X(45).            00130000
