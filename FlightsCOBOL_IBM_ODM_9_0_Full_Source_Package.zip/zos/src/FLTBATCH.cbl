       IDENTIFICATION DIVISION.
       PROGRAM-ID. FLTBATCH.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
           COPY FLIGHTOD.
           COPY ODMPATH.
           COPY ODMSTAT.
       01 WS-ROUTE                     PIC 9(3) COMP-5.
       01 WS-CITY                      PIC 9(3) COMP-5.
       PROCEDURE DIVISION.
       MAIN.
      * SYNTHETIC SMOKE INPUT: A-B-C = 300; A-C = 500.
           INITIALIZE FLC-DECISION-AREA
           MOVE 'A' TO FLC-FROM-CITY FLC-START-CITY(1)
               FLC-START-CITY(3)
           MOVE 'C' TO FLC-TO-CITY FLC-STOP-CITY(2)
               FLC-STOP-CITY(3)
           MOVE 'B' TO FLC-STOP-CITY(1) FLC-START-CITY(2)
           MOVE 'Y' TO FLC-SHORTEST
           MOVE 3 TO FLC-FLIGHT-COUNT
           MOVE 100 TO FLC-MILES(1)
           MOVE 200 TO FLC-MILES(2)
           MOVE 500 TO FLC-MILES(3)
      * SET EXACT VERSIONS FROM YOUR DEPLOYMENT CONSOLE FOR PRODUCTION.
           MOVE '/FlightsDep/1.0/FlightsCOBOL/1.0'
               TO ODM-RULESET-PATH
           DISPLAY 'RULESET: ['
               FUNCTION TRIM(ODM-RULESET-PATH) ']'
           DISPLAY 'SHORTEST FLAG: [' FLC-SHORTEST ']'
           DISPLAY 'COBOL AREA LENGTH: '
               LENGTH OF FLC-DECISION-AREA
           CALL 'FLTCALL' USING FLC-DECISION-AREA
               ODM-RULESET-PATH ODM-CALL-STATUS
           IF NOT ODM-CALL-OK
               PERFORM REPORT-ERROR
               MOVE 12 TO RETURN-CODE
               GOBACK
           END-IF
           DISPLAY 'ODM WARNING: ' ODM-WARNING
           IF FLC-ROUTE-COUNT > 100
               DISPLAY 'INVALID RETURNED ROUTE COUNT'
               MOVE 12 TO RETURN-CODE
               GOBACK
           END-IF
           DISPLAY 'ROUTES: ' FLC-ROUTE-COUNT
           PERFORM VARYING WS-ROUTE FROM 1 BY 1
               UNTIL WS-ROUTE > FLC-ROUTE-COUNT
               DISPLAY 'DESTINATION: ' FLC-CURRENT-CITY(WS-ROUTE)
                   ' MILES: ' FLC-TOTAL-MILES(WS-ROUTE)
               IF FLC-CITY-COUNT(WS-ROUTE) > 50
                   DISPLAY 'INVALID RETURNED CITY COUNT'
                   MOVE 12 TO RETURN-CODE
                   GOBACK
               END-IF
               PERFORM VARYING WS-CITY FROM 1 BY 1
                   UNTIL WS-CITY > FLC-CITY-COUNT(WS-ROUTE)
                   DISPLAY 'CITY: '
                       FLC-VISITED-CITY(WS-ROUTE, WS-CITY)
               END-PERFORM
           END-PERFORM
           IF FLC-ROUTE-COUNT NOT = 1 OR
               FLC-CURRENT-CITY(1) NOT = 'C' OR
               FLC-TOTAL-MILES(1) NOT = 300 OR
               FLC-CITY-COUNT(1) NOT = 3 OR
               FLC-VISITED-CITY(1, 1) NOT = 'A' OR
               FLC-VISITED-CITY(1, 2) NOT = 'B' OR
               FLC-VISITED-CITY(1, 3) NOT = 'C'
               DISPLAY 'SHORTEST ROUTE SMOKE TEST FAILED'
               MOVE 8 TO RETURN-CODE
               GOBACK
           END-IF
           DISPLAY 'SHORTEST ROUTE SMOKE TEST PASSED'
           MOVE ZERO TO RETURN-CODE
           GOBACK.
       REPORT-ERROR.
           DISPLAY ODM-ERROR-STAGE ' ' ODM-ERROR-MESSAGE
           DISPLAY 'CONN: ' ODM-CONN-CC '/' ODM-CONN-RC
           DISPLAY 'RULE: ' ODM-RULE-CC '/' ODM-RULE-RC
           DISPLAY 'DISC: ' ODM-DISC-CC '/' ODM-DISC-RC.
