import com.techsavants.*;
import com.techsavants.flights.cobol.*;
import com.techsavants.flights.adapter.FlightDecisionAreaMapper;
import java.util.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;

/** Contract tests. The ASCII codec here is a test fixture, not IBM marshalling. */
public class FlightBridgeTest {
    private static int checks;
    private interface Work { void run(); }
    private static void check(boolean ok, String label) {
        checks++; if (!ok) throw new AssertionError(label);
    }
    private static void rejects(Work work, String label) {
        try { work.run(); } catch (IllegalArgumentException expected) {
            checks++; return;
        }
        throw new AssertionError("Expected rejection: " + label);
    }
    private static Flc_decision_area area() {
        Flc_decision_area a = new Flc_decision_area();
        a.setFlc_from_city("A                               ");
        a.setFlc_to_city("C"); a.setFlc_shortest("Y");
        a.setFlc_flight_count((short)3);
        Flc_flight[] rows = new Flc_flight[100];
        for (int i=0;i<100;i++) rows[i]=new Flc_flight();
        String[] from={"A","B","A"}, to={"B","C","C"};
        int[] miles={100,200,500};
        for (int i=0;i<3;i++) {
            rows[i].setFlc_start_city(from[i]);
            rows[i].setFlc_stop_city(to[i]); rows[i].setFlc_miles(miles[i]);
        }
        a.setFlc_flight(rows); return a;
    }
    private static Node node(String... cities) {
        Node n=new Node(); n.setCurrentCity(cities[cities.length-1]);
        n.setVisitedCities(new ArrayList<String>(Arrays.asList(cities)));
        n.setTotalMiles(300); return n;
    }
    private static FlightResponse response(Node... nodes) {
        FlightResponse r=new FlightResponse();
        r.setRoutes(new ArrayList<Node>(Arrays.asList(nodes)));return r;
    }
    public static void main(String[] args) throws Exception {
        final Flc_decision_area a=area();
        FlightRequest request=FlightDecisionAreaMapper.toRequest(a);
        check(request.getFromCity().equals("A"),"remove COBOL trailing padding");
        check(request.getToCity().equals("C"),"target city");
        check(request.isShortestRoute(),"Y flag");
        check(request.getFlights().size()==3,"only active input rows");
        check(request.getFlights().get(1).getMiles()==200,"mileage");
        a.setFlc_shortest("N");
        check(!FlightDecisionAreaMapper.toRequest(a).isShortestRoute(),"N flag");
        a.setFlc_shortest("y");
        rejects(()->FlightDecisionAreaMapper.toRequest(a),"strict flag");
        a.setFlc_shortest("Y");
        a.setFlc_flight_count((short)0); a.setFlc_flight(null);
        check(FlightDecisionAreaMapper.toRequest(a).getFlights().isEmpty(),"empty graph");
        a.setFlc_flight_count((short)101);
        rejects(()->FlightDecisionAreaMapper.toRequest(a),"count overflow");
        a.setFlc_flight_count((short)-1);
        rejects(()->FlightDecisionAreaMapper.toRequest(a),"negative count");
        a.setFlc_flight_count((short)1);
        rejects(()->FlightDecisionAreaMapper.toRequest(a),"null array");
        a.setFlc_flight(new Flc_flight[0]);
        rejects(()->FlightDecisionAreaMapper.toRequest(a),"short array");
        a.setFlc_flight(new Flc_flight[1]);
        rejects(()->FlightDecisionAreaMapper.toRequest(a),"null active row");
        final Flc_decision_area b=area();
        b.getFlc_flight()[0].setFlc_miles(-1);
        rejects(()->FlightDecisionAreaMapper.toRequest(b),"negative leg miles");
        b.getFlc_flight()[0].setFlc_miles(1000000000);
        rejects(()->FlightDecisionAreaMapper.toRequest(b),"PIC mileage overflow");
        for(int i=0;i<3;i++)b.getFlc_flight()[i].setFlc_miles(999999999);
        rejects(()->FlightDecisionAreaMapper.toRequest(b),"int route sum protection");
        final Flc_decision_area c=area();
        c.setFlc_from_city(" ");
        rejects(()->FlightDecisionAreaMapper.toRequest(c),"blank city");
        c.setFlc_from_city(null);
        rejects(()->FlightDecisionAreaMapper.toRequest(c),"null city");
        c.setFlc_from_city(String.join("",Collections.nCopies(33,"a")));
        rejects(()->FlightDecisionAreaMapper.toRequest(c),"city overflow");
        c.setFlc_from_city("a\u0000");
        rejects(()->FlightDecisionAreaMapper.toRequest(c),"control character");
        c.setFlc_from_city("Montr\u00e9al");
        rejects(()->FlightDecisionAreaMapper.toRequest(c),"portable character set");
        c.setFlc_from_city(String.join("",Collections.nCopies(32,"a")));
        check(FlightDecisionAreaMapper.toRequest(c).getFromCity().length()==32,"32 char city");
        c.setFlc_flight_count((short)100);
        for(Flc_flight f:c.getFlc_flight()) {
            f.setFlc_start_city("A");f.setFlc_stop_city("C");f.setFlc_miles(0);
        }
        check(FlightDecisionAreaMapper.toRequest(c).getFlights().size()==100,"100 legs");
        rejects(()->FlightDecisionAreaMapper.toRequest(null),"null area");

        FlightDecisionAreaMapper.writeResponse(a,response(node("A","B","C")));
        check(a.getFlc_route_count()==1,"route count");
        check(a.getFlc_route().length==100,"full route storage");
        check(a.getFlc_route()[0].getFlc_total_miles()==300,"route miles");
        check(a.getFlc_route()[0].getFlc_city_count()==3,"city count");
        check(a.getFlc_route()[0].getFlc_route_city()[2].getFlc_visited_city().equals("C"),"path");
        for(int i=0;i<100;i++) {
            Flc_route r=a.getFlc_route()[i];
            check(r.getFlc_route_city().length==50,"full city storage");
            for(int j=(i==0?3:0);j<50;j++)
                check(r.getFlc_route_city()[j].getFlc_visited_city().equals(""),"unused blank city");
            if(i>0)check(r.getFlc_city_count()==0 && r.getFlc_total_miles()==0 && r.getFlc_current_city().equals(""),"unused numeric rows");
        }
        final Flc_route[] original=a.getFlc_route();
        final FlightResponse tooMany=response();
        for(int i=0;i<101;i++)tooMany.getRoutes().add(node("A","C"));
        rejects(()->FlightDecisionAreaMapper.writeResponse(a,tooMany),"101 routes");
        check(a.getFlc_route()==original && a.getFlc_route_count()==1,"atomic route overflow");
        final Node longPath=node("C");
        longPath.setVisitedCities(new ArrayList<String>(Collections.nCopies(51,"A")));
        rejects(()->FlightDecisionAreaMapper.writeResponse(a,response(longPath)),"51 cities");
        check(a.getFlc_route()==original && a.getFlc_route_count()==1,"atomic path overflow");
        final Node badMiles=node("C"); badMiles.setTotalMiles(-1);
        rejects(()->FlightDecisionAreaMapper.writeResponse(a,response(badMiles)),"overflowed node miles");
        rejects(()->FlightDecisionAreaMapper.writeResponse(a,response((Node)null)),"null route");
        rejects(()->FlightDecisionAreaMapper.writeResponse(a,null),"null response");
        final FlightResponse nullRoutes=response();nullRoutes.setRoutes(null);
        rejects(()->FlightDecisionAreaMapper.writeResponse(a,nullRoutes),"null routes");
        final Node badCity=node(String.join("",Collections.nCopies(33,"A")));
        rejects(()->FlightDecisionAreaMapper.writeResponse(a,response(badCity)),"output city overflow");
        check(a.getFlc_route()==original,"atomic output validation");
        FlightResponse boundary=response();
        Node fifty=node("A");fifty.setVisitedCities(new ArrayList<String>(Collections.nCopies(50,"A")));
        fifty.setTotalMiles(Integer.MAX_VALUE);
        for(int i=0;i<100;i++)boundary.getRoutes().add(fifty);
        FlightDecisionAreaMapper.writeResponse(a,boundary);
        check(a.getFlc_route_count()==100 && a.getFlc_route()[99].getFlc_city_count()==50,"100 routes by 50 cities");
        check(a.getFlc_route()[99].getFlc_total_miles()==Integer.MAX_VALUE,"10 digit output miles");
        FlightDecisionAreaMapper.writeResponse(a,response());
        check(a.getFlc_route_count()==0 && a.getFlc_route()[0].getFlc_total_miles()==0,"clear prior output");
        if(args.length==2) roundTrip(Paths.get(args[0]),Paths.get(args[1]));
        System.out.println("PASS: Flights Java mapper "+checks+" contract checks; no IBM engine execution");
    }

    private static String text(byte[] b,int off,int len) {
        return new String(b,off,len,StandardCharsets.US_ASCII);
    }
    private static void field(byte[] b,int off,int len,String value,boolean numeric) {
        if(value.length()>len)throw new AssertionError("test codec overflow");
        byte[] bytes=value.getBytes(StandardCharsets.US_ASCII);
        Arrays.fill(b,off,off+len,(byte)(numeric?'0':' '));
        System.arraycopy(bytes,0,b,numeric?off+len-bytes.length:off,bytes.length);
    }
    private static void roundTrip(Path input,Path output)throws Exception {
        byte[] bytes=Files.readAllBytes(input);
        check(bytes.length==171771,"native buffer size");
        Flc_decision_area a=new Flc_decision_area();
        a.setFlc_from_city(text(bytes,0,32));a.setFlc_to_city(text(bytes,32,32));
        a.setFlc_shortest(text(bytes,64,1));a.setFlc_flight_count(Short.parseShort(text(bytes,65,3)));
        Flc_flight[] flights=new Flc_flight[100];
        for(int i=0;i<100;i++) {
            int o=68+i*73;flights[i]=new Flc_flight();
            flights[i].setFlc_start_city(text(bytes,o,32));
            flights[i].setFlc_stop_city(text(bytes,o+32,32));
            flights[i].setFlc_miles(Integer.parseInt(text(bytes,o+64,9)));
        }
        a.setFlc_flight(flights);
        FlightRequest request=FlightDecisionAreaMapper.toRequest(a);
        check(request.getFlights().size()==1 && request.getFlights().get(0).getMiles()==100,"native input decoding");
        // Exercise actual supplied Java Node builders, not an emulated rule engine.
        Node first=FlightUtils.createInitialNode(request);
        Node second=FlightUtils.createNextNode(first,request.getFlights().get(0));
        Node third=FlightUtils.createNextNode(second,new Flight("B","C",200));
        FlightDecisionAreaMapper.writeResponse(a,response(third));
        field(bytes,7368,3,Integer.toString(a.getFlc_route_count()),true);
        for(int i=0;i<100;i++) {
            int o=7371+i*1644;Flc_route r=a.getFlc_route()[i];
            field(bytes,o,32,r.getFlc_current_city(),false);
            field(bytes,o+32,10,Long.toString(r.getFlc_total_miles()),true);
            field(bytes,o+42,2,Short.toString(r.getFlc_city_count()),true);
            for(int j=0;j<50;j++)field(bytes,o+44+j*32,32,r.getFlc_route_city()[j].getFlc_visited_city(),false);
        }
        byte[] before=Files.readAllBytes(input);
        check(Arrays.equals(Arrays.copyOf(before,7368),Arrays.copyOf(bytes,7368)),"input bytes unchanged");
        Files.write(output,bytes);
    }
}
