package com.techsavants.auhn.kb;
public class Vehicles {
    private String vVehicleNumber;
    public String getVVehicleNumber() { return vVehicleNumber; }
    public void setVVehicleNumber(String value) { vVehicleNumber = value; }
    private Boolean vIsCurrentInfo;
    public Boolean getVIsCurrentInfo() { return vIsCurrentInfo; }
    public void setVIsCurrentInfo(Boolean value) { vIsCurrentInfo = value; }
    private String vCarGroup;
    public String getVCarGroup() { return vCarGroup; }
    public void setVCarGroup(String value) { vCarGroup = value; }
    private Boolean vIsAddedOrNew;
    public Boolean getVIsAddedOrNew() { return vIsAddedOrNew; }
    public void setVIsAddedOrNew(Boolean value) { vIsAddedOrNew = value; }
    private String vSequenceNumber;
    public String getVSequenceNumber() { return vSequenceNumber; }
    public void setVSequenceNumber(String value) { vSequenceNumber = value; }
    private Boolean vHasNonGoodDriver;
    public Boolean getVHasNonGoodDriver() { return vHasNonGoodDriver; }
    public void setVHasNonGoodDriver(Boolean value) { vHasNonGoodDriver = value; }
    private String vSymbol;
    public String getVSymbol() { return vSymbol; }
    public void setVSymbol(String value) { vSymbol = value; }
    private Integer vLimitOfLiability;
    public Integer getVLimitOfLiability() { return vLimitOfLiability; }
    public void setVLimitOfLiability(Integer value) { vLimitOfLiability = value; }
    private String vUse;
    public String getVUse() { return vUse; }
    public void setVUse(String value) { vUse = value; }
    private String vMilesCalcMth;
    public String getVMilesCalcMth() { return vMilesCalcMth; }
    public void setVMilesCalcMth(String value) { vMilesCalcMth = value; }
    private String vBodyType;
    public String getVBodyType() { return vBodyType; }
    public void setVBodyType(String value) { vBodyType = value; }
    private String vLoadCapacity;
    public String getVLoadCapacity() { return vLoadCapacity; }
    public void setVLoadCapacity(String value) { vLoadCapacity = value; }
    private Boolean vIsExistingInfo;
    public Boolean getVIsExistingInfo() { return vIsExistingInfo; }
    public void setVIsExistingInfo(Boolean value) { vIsExistingInfo = value; }
    private String vAnnualMilesCode;
    public String getVAnnualMilesCode() { return vAnnualMilesCode; }
    public void setVAnnualMilesCode(String value) { vAnnualMilesCode = value; }
    private Integer vAnnualMileage;
    public Integer getVAnnualMileage() { return vAnnualMileage; }
    public void setVAnnualMileage(Integer value) { vAnnualMileage = value; }
    private String vPriRatedDrv;
    public String getVPriRatedDrv() { return vPriRatedDrv; }
    public void setVPriRatedDrv(String value) { vPriRatedDrv = value; }
    private String vVndrMilgSrc;
    public String getVVndrMilgSrc() { return vVndrMilgSrc; }
    public void setVVndrMilgSrc(String value) { vVndrMilgSrc = value; }
    private Boolean vIsNewInfo;
    public Boolean getVIsNewInfo() { return vIsNewInfo; }
    public void setVIsNewInfo(Boolean value) { vIsNewInfo = value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction = value; }
    private String vStorageInd;
    public String getVStorageInd() { return vStorageInd; }
    public void setVStorageInd(String value) { vStorageInd = value; }
    private Integer vNetVehicleCount;
    public Integer getVNetVehicleCount() { return vNetVehicleCount; }
    public void setVNetVehicleCount(Integer value) { vNetVehicleCount = value; }
    private Integer vHHAnuMilgChange;
    public Integer getVHHAnuMilgChange() { return vHHAnuMilgChange; }
    public void setVHHAnuMilgChange(Integer value) { vHHAnuMilgChange = value; }
    private String vRegOwnRelationship;
    public String getVRegOwnRelationship() { return vRegOwnRelationship; }
    public void setVRegOwnRelationship(String value) { vRegOwnRelationship = value; }
    private Integer vMonthsOfOwnership;
    public Integer getVMonthsOfOwnership() { return vMonthsOfOwnership; }
    public void setVMonthsOfOwnership(Integer value) { vMonthsOfOwnership = value; }
    private Integer vPurchasePrice;
    public Integer getVPurchasePrice() { return vPurchasePrice; }
    public void setVPurchasePrice(Integer value) { vPurchasePrice = value; }
    private Integer vAge;
    public Integer getVAge() { return vAge; }
    public void setVAge(Integer value) { vAge = value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
    private String vACTION_ADDED;
    public String getVACTION_ADDED() { return vACTION_ADDED; }
    public void setVACTION_ADDED(String value) { vACTION_ADDED=value; }
    private String vACTION_CHANGED;
    public String getVACTION_CHANGED() { return vACTION_CHANGED; }
    public void setVACTION_CHANGED(String value) { vACTION_CHANGED=value; }
    private String vACTION_ELIMINATED;
    public String getVACTION_ELIMINATED() { return vACTION_ELIMINATED; }
    public void setVACTION_ELIMINATED(String value) { vACTION_ELIMINATED=value; }
    private Boolean vGaragedFlag;
    public Boolean getVGaragedFlag() { return vGaragedFlag; }
    public void setVGaragedFlag(Boolean value) { vGaragedFlag=value; }
    private String vAntiTheftCode;
    public String getVAntiTheftCode() { return vAntiTheftCode; }
    public void setVAntiTheftCode(String value) { vAntiTheftCode=value; }
    private java.util.Date vPurchaseDate;
    public java.util.Date getVPurchaseDate() { return vPurchaseDate; }
    public void setVPurchaseDate(java.util.Date value) { vPurchaseDate=value; }
    private Boolean vAllAreMotorcycles;
    public Boolean getVAllAreMotorcycles() { return vAllAreMotorcycles; }
    public void setVAllAreMotorcycles(Boolean value) { vAllAreMotorcycles=value; }
    private String vACTION_REPLACED;
    public String getVACTION_REPLACED() { return vACTION_REPLACED; }
    public void setVACTION_REPLACED(String value) { vACTION_REPLACED=value; }
    private Integer vPassengerCarCount;
    public Integer getVPassengerCarCount() { return vPassengerCarCount; }
    public void setVPassengerCarCount(Integer value) { vPassengerCarCount=value; }
    private Integer vYear;
    public Integer getVYear() { return vYear; }
    public void setVYear(Integer value) { vYear=value; }
    private String vEVRCode;
    public String getVEVRCode() { return vEVRCode; }
    public void setVEVRCode(String value) { vEVRCode=value; }
}
