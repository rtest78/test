package com.techsavants.auhn.kb;
public class Endorsements {
    private Boolean vIsAddedOrNew;
    public Boolean getVIsAddedOrNew() { return vIsAddedOrNew; }
    public void setVIsAddedOrNew(Boolean value) { vIsAddedOrNew = value; }
    private String vEndorsementNumber;
    public String getVEndorsementNumber() { return vEndorsementNumber; }
    public void setVEndorsementNumber(String value) { vEndorsementNumber = value; }
    private String vObjectId;
    public String getVObjectId() { return vObjectId; }
    public void setVObjectId(String value) { vObjectId = value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction=value; }
    private String vACTION_ADDED;
    public String getVACTION_ADDED() { return vACTION_ADDED; }
    public void setVACTION_ADDED(String value) { vACTION_ADDED=value; }
    private String vACTION_CHANGED;
    public String getVACTION_CHANGED() { return vACTION_CHANGED; }
    public void setVACTION_CHANGED(String value) { vACTION_CHANGED=value; }
    private String vACTION_ELIMINATED;
    public String getVACTION_ELIMINATED() { return vACTION_ELIMINATED; }
    public void setVACTION_ELIMINATED(String value) { vACTION_ELIMINATED=value; }
    private Integer vExcludedEndCount;
    public Integer getVExcludedEndCount() { return vExcludedEndCount; }
    public void setVExcludedEndCount(Integer value) { vExcludedEndCount=value; }
    private Integer vExcludedEndAddCount;
    public Integer getVExcludedEndAddCount() { return vExcludedEndAddCount; }
    public void setVExcludedEndAddCount(Integer value) { vExcludedEndAddCount=value; }
    private Boolean vIsCurrentInfo;
    public Boolean getVIsCurrentInfo() { return vIsCurrentInfo; }
    public void setVIsCurrentInfo(Boolean value) { vIsCurrentInfo=value; }
    private Boolean vIsNewInfo;
    public Boolean getVIsNewInfo() { return vIsNewInfo; }
    public void setVIsNewInfo(Boolean value) { vIsNewInfo=value; }
    private Boolean vIsExistingInfo;
    public Boolean getVIsExistingInfo() { return vIsExistingInfo; }
    public void setVIsExistingInfo(Boolean value) { vIsExistingInfo=value; }
}
