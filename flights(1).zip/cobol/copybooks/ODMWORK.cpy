      * USE INSTALLED IBM COPYBOOKS, NOT THE TEST FIXTURES.
       01 WS-REASON-CODES.
          COPY HBRC.
          COPY HBRWS.
       01 WS-PARAM-NAME               PIC X(48).
       01 WS-PARAM-ADDRESS            USAGE POINTER.
       01 WS-PARAM-LENGTH             PIC S9(9) COMP-5.
       01 WS-PARAM-INDEX              PIC S9(9) COMP-5.
       01 WS-CONNECTION-OPEN          PIC X.
       01 WS-API-MISSING              PIC X.
