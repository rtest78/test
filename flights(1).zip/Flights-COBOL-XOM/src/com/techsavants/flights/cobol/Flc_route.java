/* Hand-written contract model for local verification.
 * NOT an IBM-generated COBOL XOM and NOT a marshaller.
 * Replace these classes using the IBM COBOL importer before deployment.
 */
package com.techsavants.flights.cobol;

public class Flc_route {
    private String flc_current_city = "";
    private long flc_total_miles = 0L;
    private short flc_city_count = 0;
    private Flc_route_city[] flc_route_city = null;
    public Flc_route() {}
    public String getFlc_current_city() { return flc_current_city; }
    public void setFlc_current_city(String value) { flc_current_city = value; }
    public long getFlc_total_miles() { return flc_total_miles; }
    public void setFlc_total_miles(long value) { flc_total_miles = value; }
    public short getFlc_city_count() { return flc_city_count; }
    public void setFlc_city_count(short value) { flc_city_count = value; }
    public Flc_route_city[] getFlc_route_city() { return flc_route_city; }
    public void setFlc_route_city(Flc_route_city[] value) { flc_route_city = value; }
}
