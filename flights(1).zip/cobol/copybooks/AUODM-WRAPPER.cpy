      ******************************************************************
      * AUODM-WRAPPER - TOP-LEVEL COBOL PARAMETER AREA FOR AUHN ODM
      ******************************************************************
       01 AUODM-DECISION-AREA.
          COPY WUC100.
          COPY WUC101.
          COPY WUC102.
          COPY WUC103.
          COPY WUC104.
          COPY WUC105.
          COPY WUC106.
          COPY WUC107.
          COPY WUC108.
          COPY WUC109.
          COPY WUC110.
          COPY WUC111.
          COPY WUC112.
          COPY WUC113.
          COPY WUC114.
          COPY WUC115.
          COPY WUC116.
          COPY WUC117.
          COPY WUC118.
          COPY WUC119.
          COPY WUC120.
          COPY WUC122.
          COPY WUC121.
