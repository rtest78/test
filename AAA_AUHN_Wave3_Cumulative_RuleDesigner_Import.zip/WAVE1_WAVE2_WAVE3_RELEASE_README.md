# AAA AUHN — IBM ODM Wave 3 artifacts

**Package status:** Rule Designer source release candidate · **Target date:** November 30, 2026.

This package contains the IBM ODM Rule Designer source project for Waves 1, 2 and 3, plus the Wave 3-only delta and source-grounded traceability documents. It has **not** been compiled, deployed, or execution-tested in AAA RES by this build.

## Contents

1. `01_Rule_Designer_Project/AAA_AUHN_Wave3_Cumulative_RuleDesigner_Import.zip` — complete cumulative Eclipse/ODM workspace projects. Import this ZIP into IBM ODM Rule Designer 9.0.
2. `02_Wave3_Delta/AAA_AUHN_Wave3_54_BAL_Rules_Delta.zip` — only 54 original Wave 3 BAL files, reference flows, and source manifest. **Not independently executable.**
3. `03_Documentation/Wave3_Rule_Manifest_Verified.csv` — complete 54-rule inventory, source checksums, actual ruleflow/task mappings and execution-selection status.
4. `03_Documentation/Wave3_Rule_Source_Browser.html` — searchable source business definitions for each rule.
5. `03_Documentation/Ruleflow_Task_Map.csv` — actual Rule Designer tasks, rule count and execution modes.
6. `04_Validation/Wave3_Static_Validation.txt` — static audit results and scope limitations.
7. `04_Validation/Wave2_to_Wave3_File_Diff.csv` — precise changed/added files against the Wave 2 baseline.

## Rules in this wave

| Group | Source files | Selected in flows |
|---|---:|---:|
| Shared policy | 1 | 1 |
| AO driver | 24 | 23 |
| Shared vehicle | 18 | 18 |
| AO vehicle | 11 | 11 |
| **Total** | **54** | **53** |

All 54 source BALs are copied byte-for-byte from `AUHN (2)(1).zip`. Cumulatively the Rule Designer project contains **120 BALs** (66 earlier-wave BALs including five support, plus 54 in Wave 3), **9 lifecycle BALs**, and **9 ruleflows**. **119 of the 120 BALs** are selected for execution. All 9 lifecycle rules are selected.

## Important scope and behavior notes

- `REF-070_DriverAORules` / referral `348` is included but **not** selected in AO ruleflow; the source-migration review conflicts with the full original Rule Designer flow. This needs a decision before activating it.
- `REF-071` (350) and `REF-072` (351) are selected; confirm source traceability before final delivery.
- `REF-073` (370) is retained from the earlier Wave 2 project; it is not duplicated in Wave 3.
- Wave 4 umbrella/notepad rules are not part of this release candidate. `REF-107` is also excluded from the current Wave 1–3 scope.
- No previous-wave BAL content was changed. The **only existing project files changed from the Wave 1+2 baseline** are `BAL_AO_Referrals.rfl` and `BAL_Shared_Referrals.rfl`. Both add Wave 3 execution tasks.

## Import / compile in IBM ODM Rule Designer 9.0

1. Back up the current approved workspace. Unzip the cumulative Rule Designer archive into a clean directory.
2. Import the five `AUHN-*` projects via **File → Import → Existing Projects into Workspace**.
3. Verify the project references for `AUHN-BOM`, `AUHN-XOM`, `AUHN-COBOL-XOM`, `AUHN-COBOL-Adapter`, and `AUHN-Rules`.
4. Refresh projects and perform a clean build. Check all BAL compilation errors, BOM/XOM mappings, and Java class references.
5. Open the operation `AUHN-Rules/deployment/AUHN_KB_Rules.dop`: confirm `auDecisionArea` `IN_OUT` and `BAL_AUHN_KB_Main`.
6. Open `BAL_AO_Referrals` and verify **PolicyAORules → DriverAORules → VehicleAORules**. Open `BAL_Shared_Referrals` and verify **PolicyRules → DriverRules → VehicleRules**.
7. Verify generated COBOL XOM and marshaller linked resources, the packaged `com.aaa.auhn` Java classes, and execute at least one read/write marshalling round trip.
8. Configure a **new Wave 3 version** in the deployment configuration. Do not overwrite the approved Wave 2 ruleset accidentally. The actual Wave 3 versioned ruleset path is **not confirmed**; obtain it from RES after publication. Do not assume `/3.0` until confirmed.
9. Check the deployed RES RuleApp/ruleset and update both `HBRA-CONN-RULEAPP-PATH` / COBOL test driver and SOAP/REST tests to the exact same path.
10. Run selected AO and shared-vehicle cases; compare the entire meaningful `WUC121` result (routing, ordered referrals, driver/vehicle IDs) to approved AION baseline through `X`. Log separate issues for fixed-width padding differences.
11. Re-run Wave 1 and Wave 2 regression coverage, including known referral `343` and `362` investigation cases; record pass/fail evidence and unresolved defects.
12. Publish/hand over only after compilation, linked resources, functional parity testing and stakeholder approval.

## Static-validation limitations

Static verification is **not** equivalent to an IBM ODM 9.0 compile, RES deployment, or AION outcome parity. The build does not claim that Rule Designer, Decision Center, mainframe batch, or zRES was accessed.
