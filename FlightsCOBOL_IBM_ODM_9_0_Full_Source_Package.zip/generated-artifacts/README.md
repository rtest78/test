Place IBM Rule Designer generated XOM ZIP and matching marshaller JAR here after import. Do not use handwritten stubs as deployment artifacts.
