package com.aaa.auhn.kb;

public class CitationsAdmitted extends Citations {
	private Integer vCitationID;

	public Integer getVCitationID() {
		return vCitationID;
	}

	public void setVCitationID(Integer value) {
		vCitationID = value;
	}
}
