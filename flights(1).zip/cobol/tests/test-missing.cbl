       >>SOURCE FORMAT FREE
identification division.
program-id. TESTMISSING.
data division.
working-storage section.
       >>SOURCE FORMAT FIXED
           COPY FLIGHTOD.
           COPY ODMPATH.
           COPY ODMSTAT.
           COPY CONTROL.
       >>SOURCE FORMAT FREE
01 expected-stage pic x(24).
procedure division.
  accept expected-stage from command-line
  initialize TEST-CONTROL FLC-DECISION-AREA
  move 'OK' to TEST-CASE
  move 'A' to FLC-FROM-CITY FLC-START-CITY(1) FLC-START-CITY(3)
  move 'B' to FLC-STOP-CITY(1) FLC-START-CITY(2)
  move 'C' to FLC-TO-CITY FLC-STOP-CITY(2) FLC-STOP-CITY(3)
  move 'Y' to FLC-SHORTEST
  move 3 to FLC-FLIGHT-COUNT
  move 100 to FLC-MILES(1)
  move 200 to FLC-MILES(2)
  move 500 to FLC-MILES(3)
  move '/FlightsDep/FlightsCOBOL' to ODM-RULESET-PATH
  call 'FLTCALL' using FLC-DECISION-AREA
    ODM-RULESET-PATH ODM-CALL-STATUS
  if ODM-APP-RC not = 500 or return-code not = 12
     or ODM-API-LOAD-ERROR not = 'Y'
     or ODM-ERROR-STAGE not = expected-stage
     or fixture-errors not = 0
    display 'FAIL MISSING MODULE: ' expected-stage ' ' ODM-ERROR-STAGE
    move 12 to return-code
  else
    display 'PASS: missing API module at ' expected-stage
    move 0 to return-code
  end-if
  goback.
