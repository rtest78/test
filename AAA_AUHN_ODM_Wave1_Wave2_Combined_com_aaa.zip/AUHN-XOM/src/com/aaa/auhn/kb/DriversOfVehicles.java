package com.aaa.auhn.kb;
public class DriversOfVehicles {
    private Boolean vIsCurrentInfo;
    public Boolean getVIsCurrentInfo() { return vIsCurrentInfo; }
    public void setVIsCurrentInfo(Boolean value) { vIsCurrentInfo = value; }
    private String vVehicleNumber;
    public String getVVehicleNumber() { return vVehicleNumber; }
    public void setVVehicleNumber(String value) { vVehicleNumber = value; }
    private String vDriverNumber;
    public String getVDriverNumber() { return vDriverNumber; }
    public void setVDriverNumber(String value) { vDriverNumber = value; }
    private Boolean vPrimaryDriverFlag;
    public Boolean getVPrimaryDriverFlag() { return vPrimaryDriverFlag; }
    public void setVPrimaryDriverFlag(Boolean value) { vPrimaryDriverFlag = value; }
    private Boolean vIsExistingInfo;
    public Boolean getVIsExistingInfo() { return vIsExistingInfo; }
    public void setVIsExistingInfo(Boolean value) { vIsExistingInfo = value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction=value; }
    private String vACTION_ADDED;
    public String getVACTION_ADDED() { return vACTION_ADDED; }
    public void setVACTION_ADDED(String value) { vACTION_ADDED=value; }
    private String vACTION_CHANGED;
    public String getVACTION_CHANGED() { return vACTION_CHANGED; }
    public void setVACTION_CHANGED(String value) { vACTION_CHANGED=value; }
    private String vACTION_ELIMINATED;
    public String getVACTION_ELIMINATED() { return vACTION_ELIMINATED; }
    public void setVACTION_ELIMINATED(String value) { vACTION_ELIMINATED=value; }
    private Boolean vIsAddedOrNew;
    public Boolean getVIsAddedOrNew() { return vIsAddedOrNew; }
    public void setVIsAddedOrNew(Boolean value) { vIsAddedOrNew=value; }
    private Boolean vIsNewInfo;
    public Boolean getVIsNewInfo() { return vIsNewInfo; }
    public void setVIsNewInfo(Boolean value) { vIsNewInfo=value; }
}
