package com.aaa.auhn.kb;
final class SourceTables {
static boolean aboveLossThreshold(String type,Integer amount,String status) {
if(amount==null)return false;
if ("BI".equals(type) && amount >= 0 && "O".equals(status)) return true; // IBI1, line 12519
if ("BI".equals(type) && amount >= 0 && "C".equals(status)) return true; // IBI2, line 12537
if ("CO".equals(type) && amount >= 1 && "O".equals(status)) return true; // ICO1, line 12555
if ("CO".equals(type) && amount >= 750 && "C".equals(status)) return true; // ICO2, line 12573
if ("CP".equals(type) && amount >= 1000 && "O".equals(status)) return true; // ICP1, line 12591
if ("CP".equals(type) && amount >= 1000 && "C".equals(status)) return true; // ICP2, line 12609
if ("MP".equals(type) && amount >= 0 && "O".equals(status)) return true; // IMP1, line 12627
if ("MP".equals(type) && amount >= 0 && "C".equals(status)) return true; // IMP2, line 12645
if ("PD".equals(type) && amount >= 1 && "O".equals(status)) return true; // IPD1, line 12663
if ("PD".equals(type) && amount >= 1 && "C".equals(status)) return true; // IPD2, line 12681
if ("UIM".equals(type) && amount >= 0 && "O".equals(status)) return true; // IUIM1, line 12699
if ("UIM".equals(type) && amount >= 0 && "C".equals(status)) return true; // IUIM2, line 12717
if ("UM".equals(type) && amount >= 0 && "O".equals(status)) return true; // IUM1, line 12735
if ("UM".equals(type) && amount >= 0 && "C".equals(status)) return true; // IUM2, line 12753
if ("UMPD".equals(type) && amount >= 1 && "O".equals(status)) return true; // IUMPD1, line 12771
if ("UMPD".equals(type) && amount >= 750 && "C".equals(status)) return true; // IUMPD2, line 12789
if ("UC".equals(type) && amount >= 1 && "O".equals(status)) return true; // UC1, line 12807
if ("UC".equals(type) && amount >= 750 && "C".equals(status)) return true; // UC2, line 12825
return false;
}
}
