package com.aaa.auhn.kb;

public class CitationsMVR extends Citations {
	private String vVALID_RECORD_TYPE;

	public String getVVALID_RECORD_TYPE() {
		return vVALID_RECORD_TYPE;
	}

	public void setVVALID_RECORD_TYPE(String value) {
		vVALID_RECORD_TYPE = value;
	}

	private Boolean vDismissedFlag;

	public Boolean getVDismissedFlag() {
		return vDismissedFlag;
	}

	public void setVDismissedFlag(Boolean value) {
		vDismissedFlag = value;
	}
}
