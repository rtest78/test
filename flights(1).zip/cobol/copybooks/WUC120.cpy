000100******************************************************************00010000
000200* WUC120 - PACE DATA COBOL II RECORD LAYOUT.                     *00020000
000300******************************************************************00030000
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00040000
000500* PACE DATA TO BE PASSED TO AION.                                *00050000
000600*                                                                *00060000
000700******************************************************************00070000
000800*01 WUC120-PACE-REC.                                              00080000
000900   05 WUC120-PACE-INFORMATION OCCURS 80 TIMES                     00090000
001000             INDEXED BY PACE-IDX.                                 00100000
001100      10 WUC120-PACE-DRVR-NUMBER           PIC  9(04).            00110000
001200      10 WUC120-PACE-DATE                  PIC  X(10).            00120000
001300      10 WUC120-PACE-TYPE                  PIC  X(05).            00130000
001400      10 WUC120-PACE-STATUS                PIC  X(02).            00140000
001500      10 WUC120-PACE-PAID-AMOUNT           PIC  9(08).            00150000
