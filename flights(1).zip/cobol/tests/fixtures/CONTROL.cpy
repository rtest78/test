       01 TEST-CONTROL EXTERNAL.
          05 TEST-CASE                PIC X(16).
          05 CONN-COUNT               PIC 9(4) COMP-5.
          05 RULE-COUNT               PIC 9(4) COMP-5.
          05 DISC-COUNT               PIC 9(4) COMP-5.
          05 FIXTURE-ERRORS           PIC 9(4) COMP-5.
