#!/usr/bin/env python3
"""Rebuild all three Java projects and distributable XOMs. Requires JDK 9+.
Usage: python integration/build-xom.py --odm-classpath '<ODM jars/classpath>'
Do not use substitute IBM annotation classes.
"""
import argparse, glob, os, pathlib, shutil, subprocess, zipfile

root = pathlib.Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--odm-classpath', required=True, help='IBM ODM classpath containing ilog.rules.bom.annotations.CustomProperties')
args = parser.parse_args()
os.chdir(root)
out = root / '.xom-build'
out.mkdir(exist_ok=True)
projects = ['AUHN-XOM', 'AUHN-COBOL-XOM', 'AUHN-COBOL-Adapter']
classpath = os.pathsep.join(str(pathlib.Path(v).resolve()) for entry in args.odm_classpath.split(os.pathsep) for v in (sorted(glob.glob(entry)) if "*" in entry else [entry]))
for project in projects:
    dest = root / project / 'bin'
    if dest.exists(): shutil.rmtree(dest)
    dest.mkdir()
    sources = sorted((root / project / 'src').rglob('*.java'))
    argfile = out / (project + '.txt')
    argfile.write_text('\n'.join('"' + str(p).replace('\\', '/') + '"' for p in sources))
    subprocess.run(['java', 'com.sun.tools.javac.Main', '--release', '8', '-cp', classpath, '-d', str(dest), '@' + str(argfile)], check=True)
    classpath += os.pathsep + str(dest)
    target = root / 'integration/lib' / (project + '.jar')
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as jar:
        for f in sorted(dest.rglob('*.class')): jar.write(f, f.relative_to(dest))
    # Retain the project's existing resource naming convention for managed XOMs.
    shutil.copyfile(target, root / 'AUHN-Rules/resources/xom-libraries' / (project + '.zip'))
    print('Built', project, 'from', len(sources), 'sources')
test_dest = out / 'tests'
test_dest.mkdir(exist_ok=True)
test = root / 'AUHN-COBOL-Adapter/test/com/techsavants/auhn/adapter/MapperTest.java'
subprocess.run(['java', 'com.sun.tools.javac.Main', '--release', '8', '-cp', classpath, '-d', str(test_dest), str(test)], check=True)
subprocess.run(['java', '-cp', str(test_dest) + os.pathsep + classpath, 'com.techsavants.auhn.adapter.MapperTest', 'AUHN-COBOL-Adapter/test/loader-parity.tsv'], check=True)
linkage = root / 'AUHN-COBOL-Adapter/test/com/techsavants/auhn/adapter/XomLinkageTest.java'
subprocess.run(['java', 'com.sun.tools.javac.Main', '--release', '8', '-d', str(test_dest), str(linkage)], check=True)
packaged = os.pathsep.join(str(root / 'integration/lib' / (project + '.jar')) for project in projects)
subprocess.run(['java', '-cp', str(test_dest) + os.pathsep + packaged, 'com.techsavants.auhn.adapter.XomLinkageTest'], check=True)
print('PASS: all XOMs rebuilt and mapper tests passed. Rule Designer export is a separate gate.')
