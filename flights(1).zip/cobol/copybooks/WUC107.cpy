000100******************************************************************00000100
000200* WUC107 - VEHICLE COBOL II RECORD LAYOUT.                       *00000200
000300******************************************************************00000300
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00000400
000500* VEHICLE DATA TO BE PASSED TO AION.                             *00000500
000600*                                                                *00000600
000700* MODIFICATION LOG:                                              *00000700
001220* MM/DD/CCYY    PAR NO  USERID BRIEF DESCRIPTION                 *00001220
001230*================================================================*00001230
001240* 05/09/2013 PAC-12-04H CS0373 ADD WUC107-VEH-ANNUAL-MILEAGE     *00001240
001240* 12/11/2024 IUA-42895  CS0836 ADD WUC107-VEH-VNDR-SRC-MILG      *00001240
      * 10/15/2025 IUA-84553  CS0485 ADD WUC107-VEH-MVSTORAGE          *00001240
001300******************************************************************00001300
001400*01 WUC107-VEHICLE-REC.                                           00001400
001500   05 WUC107-VEHICLE-INFORMATION OCCURS 50 TIMES                  00001500
001600             INDEXED BY VEH-IDX.                                  00001600
001700      10 WUC107-VEH-GENERATION             PIC  X(01).            00001700
001800         88 WUC107-UNKNOWN-GENERATION                VALUE 'X'.   00001800
001900         88 WUC107-EXISTING-GENERATION               VALUE 'E'.   00001900
002000         88 WUC107-CHANGE-GENERATION                 VALUE 'C'.   00002000
002100      10 WUC107-VEH-DTL-ACTION             PIC  X(04).            00002100
002200      10 WUC107-VEH-VEHICLE-NUMBER         PIC  9(04).            00002200
002300      10 WUC107-VEH-VINN                   PIC  X(17).            00002300
002400      10 WUC107-VEH-CAR-GROUP              PIC  X(04).            00002400
002500      10 WUC107-VEH-USE                    PIC  X(01).            00002500
002600      10 WUC107-VEH-YEAR                   PIC  9(04).            00002600
002700      10 WUC107-VEH-TRADE-NAME             PIC  X(05).            00002700
002800      10 WUC107-VEH-SYMBOL                 PIC  X(04).            00002800
002900      10 WUC107-VEH-PURCHASE-PRICE         PIC  X(06).            00002900
003000      10 WUC107-VEH-LOAD-CAPACITY          PIC  X(05).            00003000
003100      10 WUC107-VEH-LIMIT-OF-LIABILITY     PIC  9(09).            00003100
003200      10 WUC107-VEH-CYCLE-LICENSE-IND      PIC  X(01).            00003200
003300      10 WUC107-VEH-SEQUENCE-NUMBER        PIC  9(04).            00003300
003400      10 WUC107-VEH-REG-OWN-RELATIONSHP    PIC  X(02).            00003400
003500      10 WUC107-VEH-REG-OWN-DOB            PIC  X(10).            00003500
003600      10 WUC107-VEH-PARKED-LOCATION        PIC  X(01).            00003600
003700      10 WUC107-VEH-ANTI-THEFT-CODE        PIC  X(01).            00003700
003800      10 WUC107-VEH-PURCHASE-DATE          PIC  X(10).            00003800
003900      10 WUC107-VEH-EVR-C                  PIC  X(02).            00003900
004000      10 WUC107-VDT-BODY-TYPE-X            PIC  X(01).            00004000
004100      10 WUC107-VDT-MILES-CALC-MTH         PIC  X(01).            00004100
004200      10 WUC107-VDT-ANN-MILES-C            PIC  9(04).            00004200
004300      10 WUC107-PRI-RATE-DRV               PIC  X(01).            00004300
004400      10 WUC107-VEH-ELIM-REASON-CD         PIC  X(02).            00004400
004500      10 WUC107-VEH-ANNUAL-MILEAGE         PIC  9(09).            00004500
      * 12/11/2024 IUA-42895 CS0836 - START                                     
            10 WUC107-VEH-VNDR-SRC-MILG          PIC  X(01).                    
      * 12/11/2024 IUA-42895 CS0836 - END                                       
      * 10/15/2025 IUA-84553 CS0485 - START                                     
            10 WUC107-VEH-MVSTORAGE              PIC  X(01).                    
      * 10/15/2025 IUA-84553 CS0485 - END                                       
