package com.aaa.auhn.kb;
public class InspectionData {
    private String vModified_Ind;
    public String getVModified_Ind() { return vModified_Ind; }
    public void setVModified_Ind(String value) { vModified_Ind = value; }
    private String vPhoto_Code;
    public String getVPhoto_Code() { return vPhoto_Code; }
    public void setVPhoto_Code(String value) { vPhoto_Code = value; }
    private String vVehicle_Number;
    public String getVVehicle_Number() { return vVehicle_Number; }
    public void setVVehicle_Number(String value) { vVehicle_Number = value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction=value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
}
