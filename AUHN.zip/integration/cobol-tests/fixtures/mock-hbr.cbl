       >>SOURCE FORMAT FREE
*> TEST DOUBLES ONLY: no IBM APIs and no business rules are executed.
identification division.
program-id. HBRCONN.
data division.
working-storage section.
       >>SOURCE FORMAT FIXED
           COPY TEST-CONTROL.
       >>SOURCE FORMAT FREE
linkage section.
       >>SOURCE FORMAT FIXED
           COPY HBRWS.
       >>SOURCE FORMAT FREE
procedure division using HBRA-CONN-AREA.
    add 1 to conn-count
    move zero to HBRA-CONN-COMPLETION-CODE HBRA-CONN-REASON-CODE
    if test-case = 'CONNECT-FAIL'
        move 8 to HBRA-CONN-COMPLETION-CODE
        move 1001 to HBRA-CONN-REASON-CODE
    end-if
    goback.
end program HBRCONN.

identification division.
program-id. HBRRULE.
data division.
working-storage section.
01 test-index binary-long unsigned.
       >>SOURCE FORMAT FIXED
           COPY TEST-CONTROL.
       >>SOURCE FORMAT FREE
linkage section.
       >>SOURCE FORMAT FIXED
           COPY HBRWS.
           COPY AUODM-WRAPPER.
       >>SOURCE FORMAT FREE
procedure division using HBRA-CONN-AREA.
    add 1 to rule-count
    move zero to HBRA-CONN-COMPLETION-CODE HBRA-CONN-REASON-CODE
    if HBRA-RA-PARAMETER-NAME(1) not = 'auDecisionArea'
        add 1 to fixture-errors
    end-if
    if HBRA-RA-DATA-LENGTH(1) not = 164063
        add 1 to fixture-errors
    end-if
    if HBRA-RA-DATA-ADDRESS(1) = null
        add 1 to fixture-errors
        move 12 to HBRA-CONN-COMPLETION-CODE goback
    end-if
    perform varying test-index from 2 by 1 until test-index > 32
        if HBRA-RA-DATA-LENGTH(test-index) not = zero or
            HBRA-RA-DATA-ADDRESS(test-index) not = null or
            HBRA-RA-PARAMETER-NAME(test-index) not = spaces
            add 1 to fixture-errors
        end-if
    end-perform
    set address of AUODM-DECISION-AREA
        to HBRA-RA-DATA-ADDRESS(1)
    if WUC100-POLICY not = 123456789 or
        WUC101-TRAN-TYPE not = 'NB'
        add 1 to fixture-errors
    end-if
    if test-case = 'RULE-FAIL' or 'BOTH-FAIL'
        move 12 to HBRA-CONN-COMPLETION-CODE
        move 2001 to HBRA-CONN-REASON-CODE
        move 'TEST RULE FAILURE' to HBRA-RESPONSE-MESSAGE
    else
        *> Sample output validates only in-place parameter addressing.
        move 'PDS' to WUC121-ROUTING-DESTINATION
        move '010' to WUC121-RSN-CODE(1)
        move 7 to WUC121-RSN-VEHICLE-NUMBER(1)
        move 12 to WUC121-RSN-DRIVER-NUMBER(1)
        move 'X' to WUC121-RSN-CODE(2)
    end-if
    goback.
end program HBRRULE.

identification division.
program-id. HBRDISC.
data division.
working-storage section.
       >>SOURCE FORMAT FIXED
           COPY TEST-CONTROL.
       >>SOURCE FORMAT FREE
linkage section.
       >>SOURCE FORMAT FIXED
           COPY HBRWS.
       >>SOURCE FORMAT FREE
procedure division using HBRA-CONN-AREA.
    add 1 to disc-count
    move zero to HBRA-CONN-COMPLETION-CODE HBRA-CONN-REASON-CODE
    if test-case = 'DISCONNECT-FAIL' or 'BOTH-FAIL'
        move 8 to HBRA-CONN-COMPLETION-CODE
        move 3001 to HBRA-CONN-REASON-CODE
    end-if
    goback.
end program HBRDISC.
