# COBOL batch package

Start with [cobol/README.md](cobol/README.md). It describes the physical buffers,
Java wrappers, both COBOL callers, IBM importer/build steps, batch connection
settings and live z/OS acceptance checks. See cobol/TEST_REPORT.md for local
verification and its limits.
