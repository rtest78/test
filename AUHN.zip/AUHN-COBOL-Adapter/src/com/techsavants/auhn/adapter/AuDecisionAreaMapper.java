package com.techsavants.auhn.adapter;

import com.techsavants.auhn.cobol.*;
import com.techsavants.auhn.kb.*;
import java.util.*;

/** Typed bridge. Field mappings follow the supplied AionRecordAdapter offsets.
 * Generated COBOL classes and existing decision rules are deliberately independent.
 * WUC100 and WUC122 are preserved in the area; existing loaders do not consume them.
 */
public final class AuDecisionAreaMapper {
    private AuDecisionAreaMapper() { }
    public static AuhnRequest toRequest(Auodm_decision_area area) {
        if (area == null) throw new IllegalArgumentException("auDecisionArea is required");
        AuhnRequest request = new AuhnRequest();
        request.setExecutionPhase("FULL");
        String transaction = text(area.getWuc101_tran_type());
        if (!"NB".equals(transaction) && !"AO".equals(transaction))
            throw new IllegalArgumentException("WUC101-TRAN-TYPE must be NB or AO");
        request.setTransactionType(transaction);

        request.getTransDataFacts().add(map101(area));
        if (area.getWuc102_policy_information() != null) {
            if (area.getWuc102_policy_information().length > 2) throw new IllegalArgumentException("WUC102 exceeds OCCURS 2");
            for (Wuc102_policy_information source : area.getWuc102_policy_information()) {
                if (source == null || text(source.getWuc102_pol_generation()).isEmpty() || "X".equals(text(source.getWuc102_pol_generation()))) break;
                request.getPolicyDataFacts().add(map102(source));
            }
        }
        if (area.getWuc103_policy_codes_data() != null) {
            if (area.getWuc103_policy_codes_data().length > 30) throw new IllegalArgumentException("WUC103 exceeds OCCURS 30");
            for (Wuc103_policy_codes_data source : area.getWuc103_policy_codes_data()) {
                if (source == null || endRecord(source.getWuc103_poc_generation(), source.getWuc103_poc_action())) break;
                request.getPolicyCodeDataFacts().add(map103(source));
            }
        }
        if (area.getWuc104_driver_information() != null) {
            if (area.getWuc104_driver_information().length > 50) throw new IllegalArgumentException("WUC104 exceeds OCCURS 50");
            for (Wuc104_driver_information source : area.getWuc104_driver_information()) {
                if (source == null || endRecord(source.getWuc104_drv_generation(), source.getWuc104_drv_dop_action())) break;
                request.getDriverDataFacts().add(map104(source));
            }
        }
        if (area.getWuc105_employment_information() != null) {
            if (area.getWuc105_employment_information().length > 100) throw new IllegalArgumentException("WUC105 exceeds OCCURS 100");
            for (Wuc105_employment_information source : area.getWuc105_employment_information()) {
                if (source == null || endRecord(source.getWuc105_emp_generation(), source.getWuc105_emp_action())) break;
                request.getEmploymentDataFacts().add(map105(source));
            }
        }
        if (area.getWuc106_endorsement_information() != null) {
            if (area.getWuc106_endorsement_information().length > 40) throw new IllegalArgumentException("WUC106 exceeds OCCURS 40");
            for (Wuc106_endorsement_information source : area.getWuc106_endorsement_information()) {
                if (source == null || endRecord(source.getWuc106_end_generation(), source.getWuc106_end_action())) break;
                request.getEndorsementDataFacts().add(map106(source));
            }
        }
        if (area.getWuc107_vehicle_information() != null) {
            if (area.getWuc107_vehicle_information().length > 50) throw new IllegalArgumentException("WUC107 exceeds OCCURS 50");
            for (Wuc107_vehicle_information source : area.getWuc107_vehicle_information()) {
                if (source == null || endRecord(source.getWuc107_veh_generation(), source.getWuc107_veh_dtl_action())) break;
                request.getVehicleDataFacts().add(map107(source));
            }
        }
        if (area.getWuc108_coverage_information() != null) {
            if (area.getWuc108_coverage_information().length > 400) throw new IllegalArgumentException("WUC108 exceeds OCCURS 400");
            for (Wuc108_coverage_information source : area.getWuc108_coverage_information()) {
                if (source == null || endRecord(source.getWuc108_cov_generation(), source.getWuc108_cov_action())) break;
                request.getCoverageDataFacts().add(map108(source));
            }
        }
        if (area.getWuc109_inspection_information() != null) {
            if (area.getWuc109_inspection_information().length > 50) throw new IllegalArgumentException("WUC109 exceeds OCCURS 50");
            for (Wuc109_inspection_information source : area.getWuc109_inspection_information()) {
                if (source == null || endRecord(source.getWuc109_ins_generation(), source.getWuc109_ins_action())) break;
                request.getInspectionDataFacts().add(map109(source));
            }
        }
        if (area.getWuc110_driver_of_vehicle_data() != null) {
            if (area.getWuc110_driver_of_vehicle_data().length > 500) throw new IllegalArgumentException("WUC110 exceeds OCCURS 500");
            for (Wuc110_driver_of_vehicle_data source : area.getWuc110_driver_of_vehicle_data()) {
                if (source == null || endRecord(source.getWuc110_dov_generation(), source.getWuc110_dov_action())) break;
                request.getDriverOfVehicleDataFacts().add(map110(source));
            }
        }
        if (area.getWuc111_mvr1_information() != null) {
            if (area.getWuc111_mvr1_information().length > 50) throw new IllegalArgumentException("WUC111 exceeds OCCURS 50");
            for (Wuc111_mvr1_information source : area.getWuc111_mvr1_information()) {
                if (source == null || endMvr(source.getWuc111_mvr1_license_number())) break;
                request.getMVR1DataFacts().add(map111(source));
            }
        }
        if (area.getWuc112_mvr2_information() != null) {
            if (area.getWuc112_mvr2_information().length > 200) throw new IllegalArgumentException("WUC112 exceeds OCCURS 200");
            for (Wuc112_mvr2_information source : area.getWuc112_mvr2_information()) {
                if (source == null || endMvr(source.getWuc112_mvr2_license_number())) break;
                request.getMVR2DataFacts().add(map112(source));
            }
        }
        if (area.getWuc113_mvr3_information() != null) {
            if (area.getWuc113_mvr3_information().length > 200) throw new IllegalArgumentException("WUC113 exceeds OCCURS 200");
            for (Wuc113_mvr3_information source : area.getWuc113_mvr3_information()) {
                if (source == null || endMvr(source.getWuc113_mvr3_license_number())) break;
                request.getMVR3DataFacts().add(map113(source));
            }
        }
        if (area.getWuc114_mvr4_information() != null) {
            if (area.getWuc114_mvr4_information().length > 200) throw new IllegalArgumentException("WUC114 exceeds OCCURS 200");
            for (Wuc114_mvr4_information source : area.getWuc114_mvr4_information()) {
                if (source == null || endMvr(source.getWuc114_mvr4_license_number())) break;
                request.getMVR4DataFacts().add(map114(source));
            }
        }
        if (area.getWuc115_mvr5_information() != null) {
            if (area.getWuc115_mvr5_information().length > 200) throw new IllegalArgumentException("WUC115 exceeds OCCURS 200");
            for (Wuc115_mvr5_information source : area.getWuc115_mvr5_information()) {
                if (source == null || endMvr(source.getWuc115_mvr5_license_number())) break;
                request.getMVR5DataFacts().add(map115(source));
            }
        }
        if (area.getWuc116_mvr6_information() != null) {
            if (area.getWuc116_mvr6_information().length > 200) throw new IllegalArgumentException("WUC116 exceeds OCCURS 200");
            for (Wuc116_mvr6_information source : area.getWuc116_mvr6_information()) {
                if (source == null || endMvr(source.getWuc116_mvr6_license_number())) break;
                request.getMVR6DataFacts().add(map116(source));
            }
        }
        if (area.getWuc117_accident_information() != null) {
            if (area.getWuc117_accident_information().length > 400) throw new IllegalArgumentException("WUC117 exceeds OCCURS 400");
            for (Wuc117_accident_information source : area.getWuc117_accident_information()) {
                if (source == null || endRecord(source.getWuc117_acc_generation(), source.getWuc117_acc_action())) break;
                request.getAccidentDataFacts().add(map117(source));
            }
        }
        if (area.getWuc118_citation_information() != null) {
            if (area.getWuc118_citation_information().length > 400) throw new IllegalArgumentException("WUC118 exceeds OCCURS 400");
            for (Wuc118_citation_information source : area.getWuc118_citation_information()) {
                if (source == null || endRecord(source.getWuc118_cit_generation(), source.getWuc118_cit_action())) break;
                request.getCitationDataFacts().add(map118(source));
            }
        }
        if (area.getWuc119_suspension_information() != null) {
            if (area.getWuc119_suspension_information().length > 400) throw new IllegalArgumentException("WUC119 exceeds OCCURS 400");
            for (Wuc119_suspension_information source : area.getWuc119_suspension_information()) {
                if (source == null || endRecord(source.getWuc119_susp_generation(), source.getWuc119_susp_action())) break;
                request.getSuspensionDataFacts().add(map119(source));
            }
        }
        if (area.getWuc120_pace_information() != null) {
            if (area.getWuc120_pace_information().length > 80) throw new IllegalArgumentException("WUC120 exceeds OCCURS 80");
            for (Wuc120_pace_information source : area.getWuc120_pace_information()) {
                if (source == null || source.getWuc120_pace_drvr_number() == 0) break;
                request.getPACEDataFacts().add(map120(source));
            }
        }
        if (request.getPolicyDataFacts().isEmpty())
            throw new IllegalArgumentException("WUC102 requires at least one policy record");
        if (request.getPolicyDataFacts().get(0).getVGen_Eff_Date() == null)
            throw new IllegalArgumentException("WUC102-POL-GEN-EFF-DATE is required");
        request.setEffectiveDate(request.getPolicyDataFacts().get(0).getVGen_Eff_Date());
        return request;
    }

    /** Validate completely before changing WUC121. Never silently truncate referrals. */
    public static void writeResponse(Auodm_decision_area area, AuhnResponse response) {
        if (area == null || response == null) throw new IllegalArgumentException("Area and response are required");
        String route = text(response.getRoutingDestination());
        if (route.isEmpty() || route.length() > 5) throw new IllegalArgumentException("Routing destination must contain 1 to 5 characters");
        List<Referral> referrals = response.getReferrals();
        if (referrals == null || referrals.size() > 60) throw new IllegalArgumentException("WUC121 supports at most 60 referrals");
        Wuc121_routing_reasons[] output = new Wuc121_routing_reasons[60];
        for (int i = 0; i < output.length; i++) {
            output[i] = new Wuc121_routing_reasons();
            output[i].setWuc121_rsn_code("   ");
        }
        for (int i = 0; i < referrals.size(); i++) {
            Referral referral = referrals.get(i);
            if (referral == null) throw new IllegalArgumentException("Null referral at index " + i);
            String reason = text(referral.getCode());
            if (reason.length() != 3 || reason.startsWith("X")) throw new IllegalArgumentException("Referral code must have 3 characters and cannot use the X terminator");
            output[i].setWuc121_rsn_code(reason);
            output[i].setWuc121_rsn_vehicle_number(identifier(referral.getVehicle(), "vehicle"));
            output[i].setWuc121_rsn_driver_number(identifier(referral.getDriver(), "driver"));
        }
        // The legacy result format uses X after the last reason. Numeric fields
        // must remain valid PIC 9, so unused numeric values are zero, not spaces.
        if (referrals.size() < 60) output[referrals.size()].setWuc121_rsn_code("X  ");
        area.setWuc121_routing_destination(pad(route, 5, ' '));
        area.setWuc121_routing_reasons(output);
    }

    private static short identifier(String value, String field) {
        String v = text(value);
        if (v.isEmpty() || !v.matches("[0-9]+")) throw new IllegalArgumentException("Invalid referral " + field + ": " + v);
        try {
            long n = Long.parseLong(v);
            if (n > 9999) throw new NumberFormatException();
            return (short)n;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Referral " + field + " does not fit PIC 9(4): " + v);
        }
    }
    private static String text(String value) { return value == null ? "" : value.trim(); }
    private static String pad(String v, int width, char ch) {
        StringBuilder b = new StringBuilder(v);
        while (b.length() < width) b.append(ch);
        return b.toString();
    }
    private static String digits(long value, int width, String field) {
        String s = Long.toString(value);
        if (value < 0 || s.length() > width) throw new IllegalArgumentException(field + " is outside its PIC range");
        StringBuilder b = new StringBuilder();
        while (b.length() + s.length() < width) b.append('0');
        return b.append(s).toString();
    }
    private static boolean endRecord(String generation, String action) {
        return "X".equals(text(generation)) || (text(generation).isEmpty() && text(action).isEmpty());
    }
    private static boolean endMvr(String license) {
        String s = text(license);
        return s.isEmpty() || "XXXXXXXXXX".equals(s) || (license != null && license.startsWith("     "));
    }
    private static Date date(String value, String field) {
        String s = text(value);
        // Existing loaders treat absent and unparseable dates as null. Reject
        // nonblank malformed dates here so the integration cannot hide them.
        if (s.isEmpty() || s.equals("00000000") || s.equals("00/00/0000")) return null;
        String format;
        if (s.matches("[0-9]{2}/[0-9]{2}/[0-9]{4}")) format = "MM/dd/yyyy";
        else if (s.matches("[0-9]{8}")) format = "yyyyMMdd";
        else throw new IllegalArgumentException("Invalid date in " + field + ": " + s);
        java.text.SimpleDateFormat parser = new java.text.SimpleDateFormat(format, Locale.ROOT);
        parser.setLenient(false);
        parser.setTimeZone(TimeZone.getTimeZone("UTC"));
        try { return parser.parse(s); }
        catch (java.text.ParseException e) { throw new IllegalArgumentException("Invalid date in " + field + ": " + s, e); }
    }

    private static TransData map101(Auodm_decision_area area) {
        TransData raw = new TransData();
        raw.setVTransType(text(area.getWuc101_tran_type()));
        raw.setVClubCode(text(area.getWuc101_tran_club_code()));
        raw.setVProduct(text(area.getWuc101_tran_product()));
        return raw;
    }
    private static PolicyData map102(Wuc102_policy_information source) {
        PolicyData raw = new PolicyData();
        raw.setVGeneration(text(source.getWuc102_pol_generation()));
        raw.setVNew_Renew_Code(text(source.getWuc102_pol_new_renew_code()));
        raw.setVNamed_Insured_Status(text(source.getWuc102_pol_named_insurd_status()));
        raw.setVExcess_Pol_Ind(text(source.getWuc102_pol_excess_pol_ind()));
        raw.setVComments_Ind(text(source.getWuc102_pol_comments_ind()));
        raw.setVGen_Eff_Date(date(source.getWuc102_pol_gen_eff_date(), "WUC102-POL-GEN-EFF-DATE"));
        raw.setVTrans_Date(date(source.getWuc102_pol_trans_date(), "WUC102-POL-TRANS-DATE"));
        raw.setVLongevity_Date(date(source.getWuc102_pol_longevity_date(), "WUC102-POL-LONGEVITY-DATE"));
        raw.setVExcess_Nb_POL_Ind(text(source.getWuc102_pol_excess_nb_pol_ind()));
        raw.setVMgr_Approval(text(source.getWuc102_pol_mgr_approval()));
        raw.setVNamed_Insured_Changed(text(source.getWuc102_pol_named_insrd_change()));
        raw.setVJewel_HUON_Prem_Discrepancy(text(source.getWuc102_pol_jwl_huon_prm_discr()));
        raw.setVNB_Regd_Owner_Other(text(source.getWuc102_pol_nb_regd_owner_other()));
        raw.setVBusiness_Class(text(source.getWuc102_pol_business_class()));
        raw.setVInception_Change(text(source.getWuc102_pol_exchlongv_change()));
        raw.setVAgent_Change(text(source.getWuc102_pol_agent_change()));
        raw.setVClue_Received(text(source.getWuc102_pol_clue_status()));
        raw.setVVADINS(text(source.getWuc102_pol_vadins()));
        raw.setVSD_LNH(text(source.getWuc102_pol_sd_lnh()));
        raw.setVSD_LSH(text(source.getWuc102_pol_sd_lsh()));
        raw.setVSD_LSHM(text(source.getWuc102_pol_sd_lshm()));
        raw.setVCLUE_Not_Received(text(source.getWuc102_pol_clue_not_recd_dummy()));
        raw.setVMgr_EAD_Approval(text(source.getWuc102_ead_mgr_approval()));
        raw.setVCAC_Loss_Exists(text(source.getWuc102_pol_cac_loss_ind()));
        raw.setVCAC_DrvCd_Error_Exists(text(source.getWuc102_pol_cac_drv_err_ind()));
        raw.setVAnn_Mile_Override_Exists(text(source.getWuc102_pol_ann_mile_ovr_ind()));
        raw.setVRefer_Branch_Exists(text(source.getWuc102_pol_ref_for_branch_ind()));
        raw.setVRefer_Agent_Exists(text(source.getWuc102_pol_ref_for_agent_ind()));
        raw.setVLiab_Only_Covg_Exists(text(source.getWuc102_pol_liab_only_covg_ind()));
        raw.setVTrans_Type(text(source.getWuc102_pol_trans_type()));
        raw.setVBusinessClass_Score(text(source.getWuc102_pol_bus_class_scr()));
        raw.setVPol_Prd_Eff_Dte(digits(source.getWuc102_pol_prd_eff_date(), 8, "WUC102-POL-PRD-EFF-DATE"));
        raw.setVProd_Rlse_Eff_Dte(text(source.getWuc102_prd_rls_eff_date()));
        raw.setVRewritten_Policy(text(source.getWuc102_re_written_policy_ind()));
        raw.setVSpinOff_Policy(text(source.getWuc102_spin_off_policy_ind()));
        raw.setVNNO_Policy(text(source.getWuc102_nno_policy_ind()));
        raw.setVBackdated_Eff_Dt(text(source.getWuc102_backdated_eff_date_ind()));
        return raw;
    }
    private static PolicyCodeData map103(Wuc103_policy_codes_data source) {
        PolicyCodeData raw = new PolicyCodeData();
        raw.setVGeneration(text(source.getWuc103_poc_generation()));
        raw.setVAction(text(source.getWuc103_poc_action()));
        raw.setVName(text(source.getWuc103_poc_name()));
        raw.setVCode(text(source.getWuc103_poc_code()));
        return raw;
    }
    private static DriverData map104(Wuc104_driver_information source) {
        DriverData raw = new DriverData();
        raw.setVGeneration(text(source.getWuc104_drv_generation()));
        raw.setVAction(text(source.getWuc104_drv_dop_action()));
        raw.setVDriver_Number(digits(source.getWuc104_drv_driver_number(), 15, "WUC104-DRV-DRIVER-NUMBER"));
        raw.setVLicense_Number(text(source.getWuc104_drv_license_number()));
        raw.setVDriver_Code(text(source.getWuc104_drv_driver_code()));
        raw.setVYR_First_Licensed(Integer.valueOf(source.getWuc104_drv_yr_first_licensed()));
        raw.setVGood_Driver_Ind(text(source.getWuc104_drv_good_driver_ind()));
        raw.setVRelation_to_Applicant(text(source.getWuc104_drv_relation_to_applcnt()));
        raw.setVNamed_Insured_Ind(text(source.getWuc104_drv_named_insured_ind()));
        raw.setVID_Number(digits(source.getWuc104_drv_id_number(), 4, "WUC104-DRV-ID-NUMBER"));
        raw.setVOut_of_State_Lic(text(source.getWuc104_drv_out_of_stat_lic_ind()));
        raw.setVOwn_Car_and_Ins(text(source.getWuc104_drv_own_car_and_ins_ind()));
        raw.setVRemovalCode(text(source.getWuc104_drv_rsn_drvr_elimd_c()));
        raw.setVProofOfDependencyInd(text(source.getWuc104_drv_proof_of_depend_ind()));
        raw.setVBirthdate(date(source.getWuc104_drv_birthdate(), "WUC104-DRV-BIRTHDATE"));
        raw.setVTOT_Points(Integer.valueOf(source.getWuc104_drv_total_points()));
        raw.setVTot_Susp_Count(Integer.valueOf(source.getWuc104_drv_total_susp_count()));
        raw.setVCAYR_First_Licensed(Integer.valueOf(source.getWuc104_drv_ca_lic_issue_year()));
        raw.setVPrev_Lic_Out_of_State(text(source.getWuc104_drv_prev_lic_out_of_st()));
        raw.setVStudent_Away_Ind(text(source.getWuc104_drv_student_away_ind()));
        raw.setVStudent_Away_Reapplied(Integer.valueOf(source.getWuc104_drv_student_away_reappl()));
        raw.setVOther_Country_Lic(text(source.getWuc104_drv_oth_country_lic_ind()));
        raw.setVCur_Other_Country_Lic(text(source.getWuc104_drv_cur_oth_cntry_lic_i()));
        return raw;
    }
    private static EmploymentData map105(Wuc105_employment_information source) {
        EmploymentData raw = new EmploymentData();
        raw.setVGeneration(text(source.getWuc105_emp_generation()));
        raw.setVAction(text(source.getWuc105_emp_action()));
        raw.setVDriver_Number(digits(source.getWuc105_emp_driver_number(), 15, "WUC105-EMP-DRIVER-NUMBER"));
        raw.setVOccup_Title(text(source.getWuc105_emp_occup_title()));
        return raw;
    }
    private static EndorsementData map106(Wuc106_endorsement_information source) {
        EndorsementData raw = new EndorsementData();
        raw.setVGeneration(text(source.getWuc106_end_generation()));
        raw.setVAction(text(source.getWuc106_end_action()));
        raw.setVEndorsement_Name(text(source.getWuc106_end_endorsement_name()));
        raw.setVObject_Id(digits(source.getWuc106_end_object_id(), 15, "WUC106-END-OBJECT-ID"));
        return raw;
    }
    private static VehicleData map107(Wuc107_vehicle_information source) {
        VehicleData raw = new VehicleData();
        raw.setVGeneration(text(source.getWuc107_veh_generation()));
        raw.setVAction(text(source.getWuc107_veh_dtl_action()));
        raw.setVVehicle_Number(digits(source.getWuc107_veh_vehicle_number(), 4, "WUC107-VEH-VEHICLE-NUMBER"));
        raw.setVVINN(text(source.getWuc107_veh_vinn()));
        raw.setVCar_Group(text(source.getWuc107_veh_car_group()));
        raw.setVUse(text(source.getWuc107_veh_use()));
        raw.setVYear(Integer.valueOf(source.getWuc107_veh_year()));
        raw.setVTrade_Name(text(source.getWuc107_veh_trade_name()));
        raw.setVSymbol(text(source.getWuc107_veh_symbol()));
        raw.setVPurchase_Price(SourceFacts.integer(text(source.getWuc107_veh_purchase_price())));
        raw.setVLoad_Capacity(text(source.getWuc107_veh_load_capacity()));
        raw.setVLimit_of_Liability(Integer.valueOf(source.getWuc107_veh_limit_of_liability()));
        raw.setVCycle_License_Ind(text(source.getWuc107_veh_cycle_license_ind()));
        raw.setVSequence_Number(digits(source.getWuc107_veh_sequence_number(), 4, "WUC107-VEH-SEQUENCE-NUMBER"));
        raw.setVReg_Own_Relationship(text(source.getWuc107_veh_reg_own_relationshp()));
        raw.setVReg_Own_DOB(date(source.getWuc107_veh_reg_own_dob(), "WUC107-VEH-REG-OWN-DOB"));
        raw.setVParkedLocation(text(source.getWuc107_veh_parked_location()));
        raw.setVAntiTheftCode(text(source.getWuc107_veh_anti_theft_code()));
        raw.setVPurchaseDate(date(source.getWuc107_veh_purchase_date(), "WUC107-VEH-PURCHASE-DATE"));
        raw.setVEVRCode(text(source.getWuc107_veh_evr_c()));
        raw.setVBody_Type(text(source.getWuc107_vdt_body_type_x()));
        raw.setVMiles_Calc_Mth(text(source.getWuc107_vdt_miles_calc_mth()));
        raw.setVAnnual_Miles_Code(digits(source.getWuc107_vdt_ann_miles_c(), 4, "WUC107-VDT-ANN-MILES-C"));
        raw.setVPri_Rated_Drv(text(source.getWuc107_pri_rate_drv()));
        raw.setVElim_Reason_Cd(text(source.getWuc107_veh_elim_reason_cd()));
        raw.setVAnnual_Mileage(Integer.valueOf(source.getWuc107_veh_annual_mileage()));
        raw.setVVndr_Milg_Src(text(source.getWuc107_veh_vndr_src_milg()));
        raw.setVStorage_Ind(text(source.getWuc107_veh_mvstorage()));
        return raw;
    }
    private static CoverageData map108(Wuc108_coverage_information source) {
        CoverageData raw = new CoverageData();
        raw.setVGeneration(text(source.getWuc108_cov_generation()));
        raw.setVAction(text(source.getWuc108_cov_action()));
        raw.setVVehicle_Number(digits(source.getWuc108_cov_vehicle_number(), 4, "WUC108-COV-VEHICLE-NUMBER"));
        raw.setVLine(text(source.getWuc108_cov_line()));
        raw.setVLimit(text(source.getWuc108_cov_limit()));
        return raw;
    }
    private static InspectionData map109(Wuc109_inspection_information source) {
        InspectionData raw = new InspectionData();
        raw.setVGeneration(text(source.getWuc109_ins_generation()));
        raw.setVAction(text(source.getWuc109_ins_action()));
        raw.setVVehicle_Number(digits(source.getWuc109_ins_vehicle_number(), 4, "WUC109-INS-VEHICLE-NUMBER"));
        raw.setVModified_Ind(text(source.getWuc109_ins_modified_ind()));
        raw.setVPhoto_Code(text(source.getWuc109_ins_photo_code()));
        return raw;
    }
    private static DriverOfVehicleData map110(Wuc110_driver_of_vehicle_data source) {
        DriverOfVehicleData raw = new DriverOfVehicleData();
        raw.setVGeneration(text(source.getWuc110_dov_generation()));
        raw.setVAction(text(source.getWuc110_dov_action()));
        raw.setVVehicle_Number(digits(source.getWuc110_dov_vehicle_number(), 4, "WUC110-DOV-VEHICLE-NUMBER"));
        raw.setVDriver_Number(digits(source.getWuc110_dov_driver_number(), 15, "WUC110-DOV-DRIVER-NUMBER"));
        raw.setVPrimaryDriverInd(text(source.getWuc110_dov_primary_drvr_ind()));
        return raw;
    }
    private static MVR1Data map111(Wuc111_mvr1_information source) {
        MVR1Data raw = new MVR1Data();
        raw.setVLicense_Number(text(source.getWuc111_mvr1_license_number()));
        raw.setVDriver_Code(text(source.getWuc111_mvr1_driver_code()));
        raw.setVReport_Date(date(source.getWuc111_mvr1_report_date(), "WUC111-MVR1-REPORT-DATE"));
        raw.setVClass(text(source.getWuc111_mvr1_class()));
        raw.setVStatus(text(source.getWuc111_mvr1_status()));
        raw.setVRestrictions(text(source.getWuc111_mvr1_restrictions()));
        raw.setVMVR_Record_Clear(text(source.getWuc111_mvr1_record_clear()));
        raw.setVMVR_Lic_Exp_Date(date(source.getWuc111_mvr1_lic_exp_date(), "WUC111-MVR1-LIC-EXP-DATE"));
        return raw;
    }
    private static MVR2Data map112(Wuc112_mvr2_information source) {
        MVR2Data raw = new MVR2Data();
        raw.setVLicense_Number(text(source.getWuc112_mvr2_license_number()));
        raw.setVSequence_Number(Integer.valueOf(source.getWuc112_mvr2_sequence_number()));
        raw.setVType(text(source.getWuc112_mvr2_type()));
        raw.setVViolation_Date(date(source.getWuc112_mvr2_violation_date(), "WUC112-MVR2-VIOLATION-DATE"));
        raw.setVConviction_Date(date(source.getWuc112_mvr2_conviction_date(), "WUC112-MVR2-CONVICTION-DATE"));
        raw.setVGood_Driver_Pts(SourceFacts.integer(text(source.getWuc112_mvr2_good_driver_pts())));
        raw.setVCategory(text(source.getWuc112_mvr2_category()));
        raw.setVSurcharge(text(source.getWuc112_mvr2_surcharge()));
        raw.setVDescription(text(source.getWuc112_mvr2_description()));
        return raw;
    }
    private static MVR3Data map113(Wuc113_mvr3_information source) {
        MVR3Data raw = new MVR3Data();
        raw.setVLicense_Number(text(source.getWuc113_mvr3_license_number()));
        raw.setVSequence_Number(Integer.valueOf(source.getWuc113_mvr3_sequence_number()));
        raw.setVGood_Driver_Pts(SourceFacts.integer(text(source.getWuc113_mvr3_good_driver_pts())));
        raw.setVCategory(text(source.getWuc113_mvr3_category()));
        raw.setVSurcharge(text(source.getWuc113_mvr3_surcharge()));
        raw.setVDescription(text(source.getWuc113_mvr3_description()));
        return raw;
    }
    private static MVR4Data map114(Wuc114_mvr4_information source) {
        MVR4Data raw = new MVR4Data();
        raw.setVLicense_Number(text(source.getWuc114_mvr4_license_number()));
        raw.setVSequence_Number(Integer.valueOf(source.getWuc114_mvr4_sequence_number()));
        raw.setVDescription(text(source.getWuc114_mvr4_description()));
        return raw;
    }
    private static MVR5Data map115(Wuc115_mvr5_information source) {
        MVR5Data raw = new MVR5Data();
        raw.setVLicense_Number(text(source.getWuc115_mvr5_license_number()));
        raw.setVSequence_Number(Integer.valueOf(source.getWuc115_mvr5_sequence_number()));
        raw.setVType(text(source.getWuc115_mvr5_type()));
        raw.setVAccident_Date(date(source.getWuc115_mvr5_accident_date(), "WUC115-MVR5-ACCIDENT-DATE"));
        raw.setVDescription(text(source.getWuc115_mvr5_description()));
        raw.setVLic_Rein_Date(date(source.getWuc115_mvr5_lic_rein_date(), "WUC115-MVR5-LIC-REIN-DATE"));
        return raw;
    }
    private static MVR6Data map116(Wuc116_mvr6_information source) {
        MVR6Data raw = new MVR6Data();
        raw.setVLicense_Number(text(source.getWuc116_mvr6_license_number()));
        raw.setVSequence_Number(Integer.valueOf(source.getWuc116_mvr6_sequence_number()));
        raw.setVDescription(text(source.getWuc116_mvr6_description()));
        return raw;
    }
    private static AccidentData map117(Wuc117_accident_information source) {
        AccidentData raw = new AccidentData();
        raw.setVGeneration(text(source.getWuc117_acc_generation()));
        raw.setVAction(text(source.getWuc117_acc_action()));
        raw.setVDriver_Number(digits(source.getWuc117_acc_driver_number(), 15, "WUC117-ACC-DRIVER-NUMBER"));
        raw.setVLoss_Type(text(source.getWuc117_acc_loss_type()));
        raw.setVAcc_Id(Integer.valueOf(source.getWuc117_acc_id()));
        raw.setVAcc_Date(date(source.getWuc117_acc_date(), "WUC117-ACC-DATE"));
        raw.setVAcc_ChrgInd(text(source.getWuc117_acc_chrgind()));
        return raw;
    }
    private static CitationData map118(Wuc118_citation_information source) {
        CitationData raw = new CitationData();
        raw.setVGeneration(text(source.getWuc118_cit_generation()));
        raw.setVAction(text(source.getWuc118_cit_action()));
        raw.setVDriver_Number(digits(source.getWuc118_cit_driver_number(), 15, "WUC118-CIT-DRIVER-NUMBER"));
        raw.setVCategory(Integer.valueOf(source.getWuc118_cit_category()));
        raw.setVCit_ID(Integer.valueOf(source.getWuc118_cit_id()));
        raw.setVCit_Date(date(source.getWuc118_cit_date(), "WUC118-CIT-DATE"));
        return raw;
    }
    private static SuspensionData map119(Wuc119_suspension_information source) {
        SuspensionData raw = new SuspensionData();
        raw.setVGeneration(text(source.getWuc119_susp_generation()));
        raw.setVAction(text(source.getWuc119_susp_action()));
        raw.setVDriver_number(digits(source.getWuc119_susp_driver_number(), 15, "WUC119-SUSP-DRIVER-NUMBER"));
        raw.setVSusp_id(Integer.valueOf(source.getWuc119_susp_id()));
        raw.setVSusp_Date(date(source.getWuc119_susp_date(), "WUC119-SUSP-DATE"));
        raw.setVRein_Date(date(source.getWuc119_rein_date(), "WUC119-REIN-DATE"));
        return raw;
    }
    private static PACEData map120(Wuc120_pace_information source) {
        PACEData raw = new PACEData();
        raw.setVDriverNumber(digits(source.getWuc120_pace_drvr_number(), 4, "WUC120-PACE-DRVR-NUMBER"));
        raw.setVLossDate(date(source.getWuc120_pace_date(), "WUC120-PACE-DATE"));
        raw.setVLossType(text(source.getWuc120_pace_type()));
        raw.setVLossStatus(text(source.getWuc120_pace_status()));
        raw.setVLossAmount(Integer.valueOf(source.getWuc120_pace_paid_amount()));
        return raw;
    }
}
