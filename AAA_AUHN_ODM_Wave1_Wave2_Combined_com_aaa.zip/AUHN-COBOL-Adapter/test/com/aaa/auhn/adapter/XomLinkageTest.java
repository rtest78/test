package com.aaa.auhn.adapter;

/** Run with the three packaged XOM JARs, without workspace bin folders. */
public final class XomLinkageTest {
    public static void main(String[] args) throws Exception {
        Class<?> mapper = Class.forName("com.aaa.auhn.adapter.AuDecisionAreaMapper");
        Class<?> area = Class.forName("com.aaa.auhn.cobol.Auodm_decision_area");
        Class<?> request = Class.forName("com.aaa.auhn.kb.AuhnRequest");
        Class<?> response = Class.forName("com.aaa.auhn.kb.AuhnResponse");
        if (mapper.getMethod("toRequest", area).getReturnType() != request)
            throw new AssertionError("toRequest return type differs from bridge BOM");
        if (mapper.getMethod("writeResponse", area, response).getReturnType() != Void.TYPE)
            throw new AssertionError("writeResponse return type differs from bridge BOM");
        area.getConstructor().newInstance();
        System.out.println("PASS: packaged XOM resolves the mapper, COBOL root, request, response and both bridge BOM method signatures.");
    }
}
