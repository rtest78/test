# AUHN Wave 1 — Development Package for Planned November 13, 2026 Delivery

STATUS: INTERNAL PREPARATION ONLY. ZERO ODM BUSINESS RULES FORMALLY PUBLISHED OR DELIVERED TO AAA.

This is a filtered copy of `AUHN (2)(1).zip` from the project archive. The original is not changed.

## Included
- 19 planned Wave 1 BAL business rules (REF-003/004, REF-014-017, REF-019/020, REF-103-106, REF-108, REF-112, REF-132-136).
- 5 support/inference/finalization BAL rules (BOBJ-001-003, REF-001, REF-139). These are not counted as business-rule deliverables.
- 9 Lifecycle rules; all 9 ruleflows, with filtered static selection lists and bypass of now-empty tasks.
- Original AUHN BOM/XOM projects, COBOL adapter/XOM, helpers, copybooks and IBM Rule Designer metadata.

## Excluded
- 112 BALRules `.brl` files outside planned Wave 1 scope. All files are preserved in the original master archive.
- Ruleflow static RuleList references to excluded rules have been removed. Rule tasks with no remaining rules were removed from their linear subflows and transitions were reconnected.

## Ruleflow changes
- BAL_AO_Post_Underwriting.rfl: 14 rule references removed; empty tasks removed: UmbrellaPolicyRules, NotepadAORules
- BAL_AO_Referrals.rfl: 37 rule references removed; empty tasks removed: DriverAORules, VehicleAORules
- BAL_AUHN_KB_Main.rfl: 0 rule references removed; empty tasks removed: none
- BAL_Finalize.rfl: 0 rule references removed; empty tasks removed: none
- BAL_MVR_Preparation.rfl: 0 rule references removed; empty tasks removed: none
- BAL_NB_Post_Underwriting.rfl: 2 rule references removed; empty tasks removed: NotepadNBRules
- BAL_NB_Referrals.rfl: 13 rule references removed; empty tasks removed: Referral346
- BAL_Referral_Decision.rfl: 0 rule references removed; empty tasks removed: none
- BAL_Shared_Referrals.rfl: 47 rule references removed; empty tasks removed: DriverRules, VehicleRules

## Decision Center metadata
Stale `.syncEntries` synchronization cache files were excluded from this copy, including a prior localhost Decision Center connection. This prevents carrying the source archive's old DC sync state into the release workspace. Configure Decision Center separately after AAA resolves the HTTPS certificate issue.

## Before treating this as deployable
1. Import each project to a **new Rule Designer workspace** (do not overwrite the master source).
2. Refresh and build `AUHN-Rules`, check BOM/XOM linkage and that every remaining rule and ruleflow compiles.
3. Open all nine ruleflows and verify their task nodes, connectors, branch conditions, and intended execution paths, especially empty AO post-underwriting flow.
4. Execute the targeted Wave 1 NB/AO tests. Confirm referral decisions and verify no later-release rules execute.
5. Verify Decision Center SSL/synchronization issues separately. The filtered source ZIP has not been published to Decision Center or deployed to RES.
6. Confirm AAA/BMC approves the rule scope; the 19-rule list is the **planned** Wave 1 inventory, not yet proof of functional completion.

## Limitations
This package was structurally validated (XML parsing and UUID/reference resolution), but **NOT compiled in IBM ODM 9.0 Rule Designer or executed in AAA RES**. Rule semantics and parity have not been independently validated. There may be additional dependencies in non-BAL assets or runtime configuration requiring testing.

See `WAVE1_RULE_MANIFEST.csv` for the complete rule-by-rule disposition and `WAVE1_RULEFLOW_CHANGES.csv` for ruleflow changes.
