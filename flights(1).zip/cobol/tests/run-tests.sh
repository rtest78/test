#!/usr/bin/env bash
set -euo pipefail
odm_test_dir="$(cd "$(dirname "$0")" && pwd)"
odm_kit="$(cd "$odm_test_dir/.." && pwd)"
odm_workspace="$(cd "$odm_kit/.." && pwd)"
odm_flights="${FLIGHTS_PROJECT_ROOT:-$odm_workspace}"
odm_build="${ODM_TEST_BUILD:-$odm_kit/.test-build}"
odm_cobc="${COBC_BIN:-cobc}"
mkdir -p "$odm_build/classes" "$odm_build/tmp"
export TMPDIR="$odm_build/tmp"
cd "$odm_build"
odm_flags=(-std=ibm -fixed -fbinary-size=2-4-8 -fbinary-byteorder=big-endian -I "$odm_kit/copybooks")
odm_fixture_flags=(-I "$odm_test_dir/fixtures")
"$odm_cobc" -x "${odm_flags[@]}" -o layout "$odm_test_dir/layout-roundtrip.cbl"
./layout write
python3 - "$odm_flights" sources.txt <<'PY'
import sys
from pathlib import Path
root=Path(sys.argv[1])
sources=[]
for project in ['Flights-XOM','Flights-COBOL-XOM','Flights-COBOL-Adapter']:
    sources.extend(str(p) for p in (root/project/'src').rglob('*.java'))
Path(sys.argv[2]).write_text('\n'.join(sources)+'\n')
PY
java com.sun.tools.javac.Main --release 8 -d classes @sources.txt "$odm_test_dir/FlightBridgeTest.java"
java -cp classes FlightBridgeTest flights-input.bin flights-output.bin
./layout read
odm_mocks=("$odm_test_dir/fixtures/HBRCONN.cbl" "$odm_test_dir/fixtures/HBRRULE.cbl" "$odm_test_dir/fixtures/HBRDISC.cbl")
"$odm_cobc" -x "${odm_flags[@]}" "${odm_fixture_flags[@]}" -o callers \
  "$odm_test_dir/test-callers.cbl" "$odm_kit/src/FLTCALL.cbl" "$odm_kit/src/AUHNCB.cbl" "${odm_mocks[@]}"
./callers
for odm_app in FLTBATCH AUHNBAT; do
  "$odm_cobc" -x "${odm_flags[@]}" "${odm_fixture_flags[@]}" -o "$odm_app" \
    "$odm_kit/src/$odm_app.cbl" "$odm_kit/src/FLTCALL.cbl" "$odm_kit/src/AUHNCB.cbl" "${odm_mocks[@]}"
  "./$odm_app"
done
# A missing API must return application status instead of a loader abort.
"$odm_cobc" -x "${odm_flags[@]}" "${odm_fixture_flags[@]}" -o missing-conn \
  "$odm_test_dir/test-missing.cbl" "$odm_kit/src/FLTCALL.cbl"
./missing-conn 1000-CONNECT
"$odm_cobc" -x "${odm_flags[@]}" "${odm_fixture_flags[@]}" -o missing-rule \
  "$odm_test_dir/test-missing.cbl" "$odm_kit/src/FLTCALL.cbl" \
  "$odm_test_dir/fixtures/HBRCONN.cbl" "$odm_test_dir/fixtures/HBRDISC.cbl"
./missing-rule 2000-CALL-ODM
"$odm_cobc" -x "${odm_flags[@]}" "${odm_fixture_flags[@]}" -o missing-disc \
  "$odm_test_dir/test-missing.cbl" "$odm_kit/src/FLTCALL.cbl" \
  "$odm_test_dir/fixtures/HBRCONN.cbl" "$odm_test_dir/fixtures/HBRRULE.cbl"
./missing-disc 3000-DISCONNECT
echo 'PASS: local source, layout, mapper and mock HBR tests. Live IBM execution remains unverified.'
