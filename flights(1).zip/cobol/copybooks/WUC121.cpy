000100******************************************************************00010000
000200* WUC121 - ROUTING INFORMATION COBOL II RECORD LAYOUT.           *00020000
000300******************************************************************00030000
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00040000
000500* ROUTING INFORMATION DATA TO BE PASSED FROM AION.               *00050000
000600*                                                                *00060000
000700******************************************************************00070000
000800*01 WUC121-ROUTING-DATA-REC.                                      00080000
000900   05 WUC121-ROUTING-DESTINATION           PIC  X(05).            00090000
001000   05 WUC121-ROUTING-REASONS OCCURS 60 TIMES                      00100000
001100             INDEXED BY RSN-IDX.                                  00110000
001200      10 WUC121-RSN-CODE                   PIC  X(03).            00120000
001300      10 WUC121-RSN-VEHICLE-NUMBER         PIC  9(04).            00130000
001400      10 WUC121-RSN-DRIVER-NUMBER          PIC  9(04).            00140000
