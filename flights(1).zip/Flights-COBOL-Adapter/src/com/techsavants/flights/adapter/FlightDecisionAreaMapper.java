package com.techsavants.flights.adapter;

import com.techsavants.*;
import com.techsavants.flights.cobol.*;
import java.util.ArrayList;
import java.util.List;

/** Bridge only: route selection remains in the supplied Flights rules. */
public final class FlightDecisionAreaMapper {
    public static final int MAX_FLIGHTS = 100;
    public static final int MAX_ROUTES = 100;
    public static final int MAX_CITIES = 50;
    public static final int CITY_LENGTH = 32;
    private FlightDecisionAreaMapper() {}

    public static FlightRequest toRequest(Flc_decision_area area) {
        require(area != null, "flightDecisionArea is required");
        FlightRequest request = new FlightRequest();
        request.setFromCity(city(area.getFlc_from_city(), "FLC-FROM-CITY"));
        request.setToCity(city(area.getFlc_to_city(), "FLC-TO-CITY"));
        String flag = area.getFlc_shortest();
        require("Y".equals(flag) || "N".equals(flag),
                "FLC-SHORTEST must be Y or N");
        request.setShortestRoute("Y".equals(flag));
        int count = area.getFlc_flight_count();
        require(count >= 0 && count <= MAX_FLIGHTS,
                "FLC-FLIGHT-COUNT must be 0..100");
        Flc_flight[] rows = area.getFlc_flight();
        require(count == 0 || rows != null && rows.length >= count,
                "FLC-FLIGHT array shorter than active count");
        List<Flight> flights = new ArrayList<Flight>(count);
        long sum = 0;
        for (int i = 0; i < count; i++) {
            Flc_flight row = rows[i];
            require(row != null, "Missing flight at index " + i);
            require(row.getFlc_miles() >= 0 && row.getFlc_miles() <= 999999999,
                    "FLC-MILES outside PIC 9(9) at index " + i);
            sum += row.getFlc_miles();
            flights.add(new Flight(city(row.getFlc_start_city(), "FLC-START-CITY"),
                    city(row.getFlc_stop_city(), "FLC-STOP-CITY"), row.getFlc_miles()));
        }
        // Existing Node/FlightUtils uses int. Nonnegative legs and the sum
        // bound protect every simple path from integer overflow.
        require(sum <= Integer.MAX_VALUE,
                "Sum of input miles exceeds existing Flights int capacity");
        request.setFlights(flights);
        return request;
    }

    /** Validate and stage all output before replacing the physical rows. */
    public static void writeResponse(Flc_decision_area area, FlightResponse response) {
        require(area != null, "flightDecisionArea is required");
        require(response != null && response.getRoutes() != null,
                "FlightResponse.routes is required");
        List<Node> routes = response.getRoutes();
        require(routes.size() <= MAX_ROUTES, "More than 100 returned routes");
        Flc_route[] staged = new Flc_route[MAX_ROUTES];
        for (int i = 0; i < MAX_ROUTES; i++) {
            staged[i] = new Flc_route();
            staged[i].setFlc_current_city("");
            Flc_route_city[] cities = new Flc_route_city[MAX_CITIES];
            for (int j = 0; j < MAX_CITIES; j++) {
                cities[j] = new Flc_route_city();
                cities[j].setFlc_visited_city("");
            }
            staged[i].setFlc_route_city(cities);
            if (i >= routes.size()) continue;
            Node node = routes.get(i);
            require(node != null, "Null route at index " + i);
            staged[i].setFlc_current_city(city(node.getCurrentCity(), "currentCity"));
            require(node.getTotalMiles() >= 0, "Negative/overflowed route mileage");
            staged[i].setFlc_total_miles(node.getTotalMiles());
            List<String> path = node.getVisitedCities();
            require(path != null && path.size() >= 1 && path.size() <= MAX_CITIES,
                    "Route must contain 1..50 visited cities");
            for (int j = 0; j < path.size(); j++)
                cities[j].setFlc_visited_city(city(path.get(j), "visitedCities"));
            staged[i].setFlc_city_count((short) path.size());
        }
        area.setFlc_route(staged);
        area.setFlc_route_count((short) routes.size());
    }

    private static String city(String raw, String field) {
        require(raw != null, field + " is null");
        // COBOL padding is spaces; preserve case and internal/leading spaces.
        int end = raw.length();
        while (end > 0 && raw.charAt(end - 1) == ' ') end--;
        String value = raw.substring(0, end);
        require(value.trim().length() > 0 && value.length() <= CITY_LENGTH,
                field + " must contain 1..32 characters");
        for (int i = 0; i < value.length(); i++)
            require(value.charAt(i) >= 32 && value.charAt(i) <= 126,
                    field + " must use the portable printable character set");
        return value;
    }
    private static void require(boolean ok, String message) {
        if (!ok) throw new IllegalArgumentException(message);
    }
}
