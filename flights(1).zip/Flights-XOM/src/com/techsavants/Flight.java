package com.techsavants;

public class Flight {

    private String startCity;
    private String stopCity;
    private int miles;

    public Flight() {
    }

    public Flight(String startCity, String stopCity, int miles) {
        this.startCity = startCity;
        this.stopCity = stopCity;
        this.miles = miles;
    }

    public String getStartCity() {
        return startCity;
    }

    public void setStartCity(String startCity) {
        this.startCity = startCity;
    }

    public String getStopCity() {
        return stopCity;
    }

    public void setStopCity(String stopCity) {
        this.stopCity = stopCity;
    }

    public int getMiles() {
        return miles;
    }

    public void setMiles(int miles) {
        this.miles = miles;
    }
}
