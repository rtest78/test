package com.techsavants.auhn.kb;

public class CitationData {
	private Integer vCategory;

	public Integer getVCategory() {
		return vCategory;
	}

	public void setVCategory(Integer value) {
		vCategory = value;
	}

	private java.util.Date vCit_Date;

	public java.util.Date getVCit_Date() {
		return vCit_Date;
	}

	public void setVCit_Date(java.util.Date value) {
		vCit_Date = value;
	}

	private String vDriver_Number;

	public String getVDriver_Number() {
		return vDriver_Number;
	}

	public void setVDriver_Number(String value) {
		vDriver_Number = value;
	}

	private Integer vCit_ID;

	public Integer getVCit_ID() {
		return vCit_ID;
	}

	public void setVCit_ID(Integer value) {
		vCit_ID = value;
	}

	private String vAction;

	public String getVAction() {
		return vAction;
	}

	public void setVAction(String value) {
		vAction = value;
	}

	private String vGeneration;

	public String getVGeneration() {
		return vGeneration;
	}

	public void setVGeneration(String value) {
		vGeneration = value;
	}
}
