      * INPUT: 100 LEGS. COUNT DEFINES ACTIVE ROWS; Y/N FLAG.
          05 FLC-FROM-CITY              PIC X(32).
          05 FLC-TO-CITY                PIC X(32).
          05 FLC-SHORTEST               PIC X.
             88 FLC-SHORTEST-ONLY       VALUE 'Y'.
             88 FLC-ALL-ROUTES          VALUE 'N'.
          05 FLC-FLIGHT-COUNT           PIC 9(3).
          05 FLC-FLIGHT OCCURS 100 TIMES.
             10 FLC-START-CITY          PIC X(32).
             10 FLC-STOP-CITY           PIC X(32).
             10 FLC-MILES               PIC 9(9).
