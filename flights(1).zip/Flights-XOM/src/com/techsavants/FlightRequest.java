package com.techsavants;


import java.util.ArrayList;
import java.util.List;

public class FlightRequest {

    private String fromCity;
    private String toCity;
    private boolean shortestRoute;
    private List<Flight> flights = new ArrayList<Flight>();

    public FlightRequest() {
    }

    public String getFromCity() {
        return fromCity;
    }

    public void setFromCity(String fromCity) {
        this.fromCity = fromCity;
    }

    public String getToCity() {
        return toCity;
    }

    public void setToCity(String toCity) {
        this.toCity = toCity;
    }

    public boolean isShortestRoute() {
        return shortestRoute;
    }

    public void setShortestRoute(boolean shortestRoute) {
        this.shortestRoute = shortestRoute;
    }

    public List<Flight> getFlights() {
        return flights;
    }

    public void setFlights(List<Flight> flights) {
        this.flights = flights;
    }
}