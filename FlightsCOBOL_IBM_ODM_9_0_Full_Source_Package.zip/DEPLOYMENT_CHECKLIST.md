# Flights-only deployment and validation checklist

## Source status
- [x] Existing Flights ruleflow, BOM, Java domain model, adapter preserved.
- [x] Master `FLIGHTOD.cpy` includes `FLTIN.cpy` + `FLTOUT.cpy`.
- [x] Batch smoke path corrected to `/FlightsDep/1.0/FlightsCOBOL/1.0`.
- [x] Batch test controls shortest flag separately (`Y`); no `SYSIN` ACCEPT.
- [x] COBOL parameter `flightDecisionArea` remains IN_OUT / one raw data area.
- [ ] Real generated IBM COBOL XOM Java classes in `Flights-COBOL-XOM`.
- [ ] Generated COBOL marshaller JAR (IBM Rule Designer output).
- [ ] Adapter compiles against IBM-generated XOM (type/accessor verification).
- [ ] BOM maps to generated COBOL XOM, not hand-written test stubs.
- [ ] RuleApp ruleset associated with generated COBOL XOM and marshaller.
- [ ] Deploy RuleApp and dependency Java XOM/adapter to D0R1 persistence.
- [ ] Compile and link corrected native FLTBATCH/FLTCALL on z/OS.
- [ ] Runtime check HBRCONN / HBRRULE / HBRDISC outcomes and response fields.

## IBM-specific caveats
1. The IBM wizard may use different generated class names and numeric Java
   types, depending on import preferences. Match *actual* generated APIs;
   do not ship the stubs under `test-support` to RES.
2. A deployed Java XOM for HTDS does not imply an attached native COBOL
   marshaller for zRule Execution Server.
3. Use identical copybook layouts in Rule Designer and the COBOL compile.
   Input is PIC 9 display numerics, not binary COMP storage.
4. IBM proprietary tools are not available in this package; output artifacts
   cannot be certified until generated at your installation.

## Post-deployment troubleshooting
- `8/5003` path parsing: inspect path for appended `Y` or wrong version.
- `8/5001` with missing Marshaller: missing/mismatched ruleset XOM association.
- Errors reading parameters: check parameter name `flightDecisionArea`,
  byte length 171771, XOM class signatures and character encoding.
- Valid response with blank visited city: inspect input/output mapper,
  array counts, generated accessor mapping and ruleflow output task.
