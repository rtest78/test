package com.aaa.auhn.kb;

import java.util.*;

public class AuhnResponse {
	private List<Referral> referrals = new ArrayList<Referral>();
	private String routingDestination;
	private List<MVRHierarchy> mvrHierarchy = new ArrayList<MVRHierarchy>();

	public List<Referral> getReferrals() {
		return referrals;
	}

	public void setReferrals(List<Referral> v) {
		referrals = v;
	}

	public String getRoutingDestination() {
		return routingDestination;
	}

	public void setRoutingDestination(String v) {
		routingDestination = v;
	}

	public List<MVRHierarchy> getMvrHierarchy() {
		return mvrHierarchy;
	}

	public void setMvrHierarchy(List<MVRHierarchy> v) {
		mvrHierarchy = v;
	}
}
