package com.aaa.auhn.kb;
public class EmploymentData {
    private String vOccup_Title;
    public String getVOccup_Title() { return vOccup_Title; }
    public void setVOccup_Title(String value) { vOccup_Title = value; }
    private String vDriver_Number;
    public String getVDriver_Number() { return vDriver_Number; }
    public void setVDriver_Number(String value) { vDriver_Number = value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction=value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
}
