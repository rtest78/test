       >>SOURCE FORMAT FREE
identification division.
program-id. TESTCALLER.
data division.
working-storage section.
01 expected-status binary-long signed.
01 expected-rule-count binary-long unsigned.
01 expected-disc-count binary-long unsigned.
01 actual-status binary-long signed.
01 assertions binary-long unsigned value 0.
       >>SOURCE FORMAT FIXED
           COPY TEST-CONTROL.
           COPY AUODM-WRAPPER.
       >>SOURCE FORMAT FREE
procedure division.
main.
    move 'SUCCESS' to test-case
    move 0 to expected-status
    move 1 to expected-rule-count expected-disc-count
    perform run-case
    move 'CONNECT-FAIL' to test-case
    move 12 to expected-status
    move 0 to expected-rule-count expected-disc-count
    perform run-case
    move 'RULE-FAIL' to test-case
    move 12 to expected-status
    move 1 to expected-rule-count expected-disc-count
    perform run-case
    move 'DISCONNECT-FAIL' to test-case
    move 8 to expected-status
    perform run-case
    move 'BOTH-FAIL' to test-case
    move 12 to expected-status
    perform run-case
    *> Repeated calls verify that the caller resets its saved status.
    move 'SUCCESS' to test-case
    move 0 to expected-status
    perform run-case
    display 'PASS: 6 caller scenarios, assertions=' assertions
    display 'TEST DOUBLES ONLY: IBM HBR APIs were not executed'
    move zero to return-code goback.
run-case.
    move zero to conn-count rule-count disc-count fixture-errors
    initialize AUODM-DECISION-AREA
    move 123456789 to WUC100-POLICY
    move 'NB' to WUC101-TRAN-TYPE
    move 'OLD' to WUC121-ROUTING-DESTINATION
    call 'AUHNCALL' using AUODM-DECISION-AREA
    move return-code to actual-status
    if actual-status not = expected-status or
        conn-count not = 1 or rule-count not = expected-rule-count or
        disc-count not = expected-disc-count or fixture-errors not = 0
        display 'FAIL: ' test-case ' status=' actual-status
            ' conn=' conn-count ' rule=' rule-count ' disc=' disc-count
            ' errors=' fixture-errors
        move 12 to return-code goback
    end-if
    add 5 to assertions
    if WUC100-POLICY not = 123456789
        display 'FAIL: input policy changed'
        move 12 to return-code goback
    end-if
    add 1 to assertions
    if test-case = 'SUCCESS' or 'DISCONNECT-FAIL'
        if WUC121-ROUTING-DESTINATION not = 'PDS' or
            WUC121-RSN-CODE(1) not = '010' or
            WUC121-RSN-VEHICLE-NUMBER(1) not = 7 or
            WUC121-RSN-DRIVER-NUMBER(1) not = 12 or
            WUC121-RSN-CODE(2) not = 'X'
            display 'FAIL: output not returned in supplied area'
            move 12 to return-code goback
        end-if
        add 5 to assertions
    else
        if WUC121-ROUTING-DESTINATION not = 'OLD'
            display 'FAIL: failed mock changed output'
            move 12 to return-code goback
        end-if
        add 1 to assertions
    end-if
    display 'PASS CASE: ' test-case.
