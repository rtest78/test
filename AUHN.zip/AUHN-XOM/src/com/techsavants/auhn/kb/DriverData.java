package com.techsavants.auhn.kb;
public class DriverData {
    private String vDriver_Code;
    public String getVDriver_Code() { return vDriver_Code; }
    public void setVDriver_Code(String value) { vDriver_Code = value; }
    private String vDriver_Number;
    public String getVDriver_Number() { return vDriver_Number; }
    public void setVDriver_Number(String value) { vDriver_Number = value; }
    private String vGood_Driver_Ind;
    public String getVGood_Driver_Ind() { return vGood_Driver_Ind; }
    public void setVGood_Driver_Ind(String value) { vGood_Driver_Ind = value; }
    private String vID_Number;
    public String getVID_Number() { return vID_Number; }
    public void setVID_Number(String value) { vID_Number = value; }
    private String vLicense_Number;
    public String getVLicense_Number() { return vLicense_Number; }
    public void setVLicense_Number(String value) { vLicense_Number = value; }
    private String vNamed_Insured_Ind;
    public String getVNamed_Insured_Ind() { return vNamed_Insured_Ind; }
    public void setVNamed_Insured_Ind(String value) { vNamed_Insured_Ind = value; }
    private String vOut_of_State_Lic;
    public String getVOut_of_State_Lic() { return vOut_of_State_Lic; }
    public void setVOut_of_State_Lic(String value) { vOut_of_State_Lic = value; }
    private String vOwn_Car_and_Ins;
    public String getVOwn_Car_and_Ins() { return vOwn_Car_and_Ins; }
    public void setVOwn_Car_and_Ins(String value) { vOwn_Car_and_Ins = value; }
    private String vRelation_to_Applicant;
    public String getVRelation_to_Applicant() { return vRelation_to_Applicant; }
    public void setVRelation_to_Applicant(String value) { vRelation_to_Applicant = value; }
    private Integer vTOT_Points;
    public Integer getVTOT_Points() { return vTOT_Points; }
    public void setVTOT_Points(Integer value) { vTOT_Points = value; }
    private Integer vYR_First_Licensed;
    public Integer getVYR_First_Licensed() { return vYR_First_Licensed; }
    public void setVYR_First_Licensed(Integer value) { vYR_First_Licensed = value; }
    private String vRemovalCode;
    public String getVRemovalCode() { return vRemovalCode; }
    public void setVRemovalCode(String value) { vRemovalCode = value; }
    private String vProofOfDependencyInd;
    public String getVProofOfDependencyInd() { return vProofOfDependencyInd; }
    public void setVProofOfDependencyInd(String value) { vProofOfDependencyInd = value; }
    private java.util.Date vBirthdate;
    public java.util.Date getVBirthdate() { return vBirthdate; }
    public void setVBirthdate(java.util.Date value) { vBirthdate = value; }
    private Integer vTot_Susp_Count;
    public Integer getVTot_Susp_Count() { return vTot_Susp_Count; }
    public void setVTot_Susp_Count(Integer value) { vTot_Susp_Count = value; }
    private Integer vCAYR_First_Licensed;
    public Integer getVCAYR_First_Licensed() { return vCAYR_First_Licensed; }
    public void setVCAYR_First_Licensed(Integer value) { vCAYR_First_Licensed = value; }
    private String vPrev_Lic_Out_of_State;
    public String getVPrev_Lic_Out_of_State() { return vPrev_Lic_Out_of_State; }
    public void setVPrev_Lic_Out_of_State(String value) { vPrev_Lic_Out_of_State = value; }
    private String vStudent_Away_Ind;
    public String getVStudent_Away_Ind() { return vStudent_Away_Ind; }
    public void setVStudent_Away_Ind(String value) { vStudent_Away_Ind = value; }
    private Integer vStudent_Away_Reapplied;
    public Integer getVStudent_Away_Reapplied() { return vStudent_Away_Reapplied; }
    public void setVStudent_Away_Reapplied(Integer value) { vStudent_Away_Reapplied = value; }
    private String vOther_Country_Lic;
    public String getVOther_Country_Lic() { return vOther_Country_Lic; }
    public void setVOther_Country_Lic(String value) { vOther_Country_Lic = value; }
    private String vCur_Other_Country_Lic;
    public String getVCur_Other_Country_Lic() { return vCur_Other_Country_Lic; }
    public void setVCur_Other_Country_Lic(String value) { vCur_Other_Country_Lic = value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction=value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
}
