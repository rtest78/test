000100******************************************************************00010000
000200* WUC117 - ACCIDENT COBOL II RECORD LAYOUT.                      *00020000
000300******************************************************************00030000
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00040000
000500* ADMITTED ACCIDENT DATA TO BE PASSED TO AION.                   *00050000
000600*                                                                *00060000
000700******************************************************************00070000
000800*01 WUC117-ACCIDENT-REC.                                          00080000
000900   05 WUC117-ACCIDENT-INFORMATION OCCURS 400 TIMES                00090000
001000             INDEXED BY ACC-IDX.                                  00100000
001100      10 WUC117-ACC-GENERATION             PIC  X(01).            00110000
001200         88 WUC117-UNKNOWN-GENERATION                VALUE 'X'.   00120000
001300         88 WUC117-EXISTING-GENERATION               VALUE 'E'.   00130000
001400         88 WUC117-CHANGE-GENERATION                 VALUE 'C'.   00140000
001500      10 WUC117-ACC-ACTION                 PIC  X(04).            00150000
001600      10 WUC117-ACC-DRIVER-NUMBER          PIC  9(15).            00160000
001700      10 WUC117-ACC-LOSS-TYPE              PIC  X(03).            00170000
001800      10 WUC117-ACC-ID                     PIC  9(04).            00180000
001900      10 WUC117-ACC-DATE                   PIC  X(10).            00190000
001900      10 WUC117-ACC-CHRGIND                PIC  X(01).            00190100
