000100******************************************************************00010000
000200* WUC106 - ENDORSEMENT COBOL II RECORD LAYOUT.                 *  00020000
000300******************************************************************00030000
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00040000
000500* ENDORSEMENT DATA TO BE PASSED TO AION.                         *00050000
000600*                                                                *00060000
000700******************************************************************00070000
000800*01 WUC106-ENDORSEMENT-REC.                                       00080000
000900   05 WUC106-ENDORSEMENT-INFORMATION OCCURS 40 TIMES              00090000
001000             INDEXED BY END-IDX.                                  00100000
001100      10 WUC106-END-GENERATION             PIC  X(01).            00110000
001200         88 WUC106-UNKNOWN-GENERATION                VALUE 'X'.   00120000
001300         88 WUC106-EXISTING-GENERATION               VALUE 'E'.   00130000
001400         88 WUC106-CHANGE-GENERATION                 VALUE 'C'.   00140000
001500      10 WUC106-END-ACTION                 PIC  X(04).            00150000
001600      10 WUC106-END-ENDORSEMENT-NAME       PIC  X(06).            00160000
001700      10 WUC106-END-OBJECT-ID              PIC  9(15).            00170000
