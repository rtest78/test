000100******************************************************************00010000
000200* WUC112 - MVR112 DATA COBOL II RECORD LAYOUT.                   *00020000
000300******************************************************************00030000
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00040000
000500* MVR112 DATA TO BE PASSED TO AION.                              *00050000
000600*                                                                *00060000
000700******************************************************************00070000
000800*01 WUC112-MVR2-REC.                                              00080000
000900   05 WUC112-MVR2-INFORMATION OCCURS 200 TIMES                    00090000
001000             INDEXED BY MVR2-IDX.                                 00100000
001100      10 WUC112-MVR2-LICENSE-NUMBER        PIC  X(10).            00110000
001200      10 WUC112-MVR2-SEQUENCE-NUMBER       PIC  9(03).            00120000
001300      10 WUC112-MVR2-TYPE                  PIC  X(04).            00130000
001400      10 WUC112-MVR2-VIOLATION-DATE        PIC  X(10).            00140000
001500      10 WUC112-MVR2-CONVICTION-DATE       PIC  X(10).            00150000
001600      10 WUC112-MVR2-GOOD-DRIVER-PTS       PIC  X(01).            00160000
001700      10 WUC112-MVR2-CATEGORY              PIC  X(01).            00170000
001800      10 WUC112-MVR2-SURCHARGE             PIC  X(01).            00180000
001900      10 WUC112-MVR2-DESCRIPTION           PIC  X(45).            00190000
