#!/usr/bin/env python3
"""Generate executable offset checks from the unchanged fixed-format copybooks."""
from pathlib import Path
import re,json
base=Path(__file__).resolve().parent
root=base.parents[1]
cbroot=root/'AUHN-Rules/Copybooks'
cursor=0; layout=[];checks=[]
for num in list(range(100,121))+[122,121]:
    fields=[];group=None;occurs=1;offset=0;prefix_size=0
    for original in (cbroot/f'WUC{num}.cpy').read_text().splitlines():
        line=original[6:72]
        if line.startswith('*'):continue
        g=re.search(r'\b05\s+(WUC\d+-[\w-]+)\s+OCCURS\s+(\d+)',line)
        if g:group=g[1];occurs=int(g[2]);prefix_size=offset;offset=0;continue
        m=re.search(r'\b(05|10)\s+(WUC\d+-[\w-]+)\s+PIC\s+(S?[X9])\((\d+)\)(.*)',line)
        if not m:continue
        level,name,kind,digits,tail=m.groups();digits=int(digits)
        size=(2 if digits<=4 else 4 if digits<=9 else 8) if 'COMP' in tail else digits
        fields.append(dict(name=name,offset=offset,size=size,picture=kind,digits=digits,comp='COMP' in tail, in_group=group is not None));offset+=size
    row=dict(copybook=f'WUC{num}',start=cursor,group=group,count=occurs,stride=offset,prefix_size=prefix_size,fields=fields);layout.append(row)
    for f in fields:
        for index in ([1,occurs] if f['in_group'] and occurs>1 else [1]):
            ref=f['name']+(f'({index})' if f['in_group'] else '')
            expected=cursor+(prefix_size if f['in_group'] else 0)+f['offset']+(index-1)*offset
            checks.extend([f'    set ws-address to address of {ref}',
                           '    compute ws-offset = ws-address-number - ws-base-number',
                           f'    if ws-offset not = {expected}',
                           f"        display 'FAIL: {ref} offset ' ws-offset",
                           '        move 12 to return-code goback',
                           '    end-if','    add 1 to ws-checks'])
    cursor+=prefix_size+offset*occurs
assert cursor==164063,cursor
p=base/'verify-layout.cbl';s=p.read_text();s=s.replace('    *> FIELD-OFFSET-CHECKS','    *> FIELD-OFFSET-CHECKS\n'+'\n'.join(checks)+'\n    *> END-FIELD-OFFSET-CHECKS')
# Regeneration replaces only the generated span.
if s.count('END-FIELD-OFFSET-CHECKS')>1:
    original=p.read_text();a=original.index('    *> FIELD-OFFSET-CHECKS');b=original.index('    *> END-FIELD-OFFSET-CHECKS')+len('    *> END-FIELD-OFFSET-CHECKS');s=original[:a]+'    *> FIELD-OFFSET-CHECKS\n'+'\n'.join(checks)+'\n    *> END-FIELD-OFFSET-CHECKS'+original[b:]
p.write_text(s)
(base/'layout.json').write_text(json.dumps(dict(total_size=cursor,sections=layout),indent=2)+'\n')
print('Generated',len(checks)//7,'field offset checks')
