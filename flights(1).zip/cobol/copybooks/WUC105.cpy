000100******************************************************************00010000
000200* WUC105 - INDIVIDUAL EMPLOYMENT COBOL II RECORD LAYOUT.       *  00020000
000300******************************************************************00030000
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00040000
000500* INDIVIDUAL EMPLOYMENT DATA TO BE PASSED TO AION.               *00050000
000600*                                                                *00060000
000700******************************************************************00070000
000800*01 WUC105-EMPLOYMENT-REC.                                        00080000
000900   05 WUC105-EMPLOYMENT-INFORMATION OCCURS 100 TIMES              00090000
001000             INDEXED BY EMP-IDX.                                  00100000
001100      10 WUC105-EMP-GENERATION             PIC  X(01).            00110000
001200         88 WUC105-UKNOWN-GENERATION                 VALUE 'X'.   00120000
001300         88 WUC105-EXISTING-GENERATION               VALUE 'E'.   00130000
001400         88 WUC105-CHANGE-GENERATION                 VALUE 'C'.   00140000
001500      10 WUC105-EMP-ACTION                 PIC  X(04).            00150000
001600      10 WUC105-EMP-DRIVER-NUMBER          PIC  9(15).            00160000
001700      10 WUC105-EMP-OCCUP-TITLE            PIC  X(20).            00170000
