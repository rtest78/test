package com.aaa.auhn.kb;
public class MVR1Data {
    private String vClass;
    public String getVClass() { return vClass; }
    public void setVClass(String value) { vClass = value; }
    private String vDriver_Code;
    public String getVDriver_Code() { return vDriver_Code; }
    public void setVDriver_Code(String value) { vDriver_Code = value; }
    private String vLicense_Number;
    public String getVLicense_Number() { return vLicense_Number; }
    public void setVLicense_Number(String value) { vLicense_Number = value; }
    private java.util.Date vMVR_Lic_Exp_Date;
    public java.util.Date getVMVR_Lic_Exp_Date() { return vMVR_Lic_Exp_Date; }
    public void setVMVR_Lic_Exp_Date(java.util.Date value) { vMVR_Lic_Exp_Date = value; }
    private String vMVR_Record_Clear;
    public String getVMVR_Record_Clear() { return vMVR_Record_Clear; }
    public void setVMVR_Record_Clear(String value) { vMVR_Record_Clear = value; }
    private java.util.Date vReport_Date;
    public java.util.Date getVReport_Date() { return vReport_Date; }
    public void setVReport_Date(java.util.Date value) { vReport_Date = value; }
    private String vRestrictions;
    public String getVRestrictions() { return vRestrictions; }
    public void setVRestrictions(String value) { vRestrictions = value; }
    private String vStatus;
    public String getVStatus() { return vStatus; }
    public void setVStatus(String value) { vStatus = value; }
}
