package com.aaa.auhn.kb;
public class DriversMVRInfo {
    private String vMVRLicenseClass;
    public String getVMVRLicenseClass() { return vMVRLicenseClass; }
    public void setVMVRLicenseClass(String value) { vMVRLicenseClass = value; }
    private Boolean vSuspendedCancelledRevokedFlag;
    public Boolean getVSuspendedCancelledRevokedFlag() { return vSuspendedCancelledRevokedFlag; }
    public void setVSuspendedCancelledRevokedFlag(Boolean value) { vSuspendedCancelledRevokedFlag = value; }
    private Integer vMVRAccidentCount;
    public Integer getVMVRAccidentCount() { return vMVRAccidentCount; }
    public void setVMVRAccidentCount(Integer value) { vMVRAccidentCount = value; }
    private Integer vMVRCitationCount;
    public Integer getVMVRCitationCount() { return vMVRCitationCount; }
    public void setVMVRCitationCount(Integer value) { vMVRCitationCount = value; }
    private Integer vMVRSuspensionCount;
    public Integer getVMVRSuspensionCount() { return vMVRSuspensionCount; }
    public void setVMVRSuspensionCount(Integer value) { vMVRSuspensionCount = value; }
    private String vMVRStatus;
    public String getVMVRStatus() { return vMVRStatus; }
    public void setVMVRStatus(String value) { vMVRStatus = value; }
    private Boolean vPendingFlag;
    public Boolean getVPendingFlag() { return vPendingFlag; }
    public void setVPendingFlag(Boolean value) { vPendingFlag = value; }
    private Boolean vLicenseExpiredFlag;
    public Boolean getVLicenseExpiredFlag() { return vLicenseExpiredFlag; }
    public void setVLicenseExpiredFlag(Boolean value) { vLicenseExpiredFlag = value; }
    private Boolean vLicExpired60DaysFlag;
    public Boolean getVLicExpired60DaysFlag() { return vLicExpired60DaysFlag; }
    public void setVLicExpired60DaysFlag(Boolean value) { vLicExpired60DaysFlag = value; }
    private Integer vNumberOfFTAsAndDismissals;
    public Integer getVNumberOfFTAsAndDismissals() { return vNumberOfFTAsAndDismissals; }
    public void setVNumberOfFTAsAndDismissals(Integer value) { vNumberOfFTAsAndDismissals = value; }
    private Boolean vMVRClearFlag;
    public Boolean getVMVRClearFlag() { return vMVRClearFlag; }
    public void setVMVRClearFlag(Boolean value) { vMVRClearFlag = value; }
    private java.util.Date vMVRLicenseExpireDate;
    public java.util.Date getVMVRLicenseExpireDate() { return vMVRLicenseExpireDate; }
    public void setVMVRLicenseExpireDate(java.util.Date value) { vMVRLicenseExpireDate=value; }
    private String vDriverNumber;
    public String getVDriverNumber() { return vDriverNumber; }
    public void setVDriverNumber(String value) { vDriverNumber=value; }
    private Integer vDismissedCount;
    public Integer getVDismissedCount() { return vDismissedCount; }
    public void setVDismissedCount(Integer value) { vDismissedCount=value; }
    private Boolean vHasValidLicense;
    public Boolean getVHasValidLicense() { return vHasValidLicense; }
    public void setVHasValidLicense(Boolean value) { vHasValidLicense=value; }
    private String vLicenseNumber;
    public String getVLicenseNumber() { return vLicenseNumber; }
    public void setVLicenseNumber(String value) { vLicenseNumber=value; }
    private Boolean vIsCurrentInfo;
    public Boolean getVIsCurrentInfo() { return vIsCurrentInfo; }
    public void setVIsCurrentInfo(Boolean value) { vIsCurrentInfo=value; }
    private Boolean vIsAddedOrNew;
    public Boolean getVIsAddedOrNew() { return vIsAddedOrNew; }
    public void setVIsAddedOrNew(Boolean value) { vIsAddedOrNew=value; }
    private Boolean vIsNewInfo;
    public Boolean getVIsNewInfo() { return vIsNewInfo; }
    public void setVIsNewInfo(Boolean value) { vIsNewInfo=value; }
    private Boolean vIsExistingInfo;
    public Boolean getVIsExistingInfo() { return vIsExistingInfo; }
    public void setVIsExistingInfo(Boolean value) { vIsExistingInfo=value; }
}
