package com.aaa.auhn.kb;
public class SuspensionData {
    private Integer vSusp_id;
    public Integer getVSusp_id() { return vSusp_id; }
    public void setVSusp_id(Integer value) { vSusp_id = value; }
    private String vDriver_number;
    public String getVDriver_number() { return vDriver_number; }
    public void setVDriver_number(String value) { vDriver_number = value; }
    private java.util.Date vSusp_Date;
    public java.util.Date getVSusp_Date() { return vSusp_Date; }
    public void setVSusp_Date(java.util.Date value) { vSusp_Date = value; }
    private java.util.Date vRein_Date;
    public java.util.Date getVRein_Date() { return vRein_Date; }
    public void setVRein_Date(java.util.Date value) { vRein_Date = value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction=value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
}
