000100******************************************************************00010000
000200* WUC111 - MVR111 DATA COBOL II RECORD LAYOUT.                   *00020000
000300******************************************************************00030000
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00040000
000500* MVR111 DATA TO BE PASSED TO AION.                              *00050000
000600*                                                                *00060000
000700******************************************************************00070000
000800*01 WUC111-MVR1-REC.                                              00080000
000900   05 WUC111-MVR1-INFORMATION OCCURS 50 TIMES                     00090000
001000             INDEXED BY MVR1-IDX.                                 00100000
001100      10 WUC111-MVR1-LICENSE-NUMBER        PIC  X(10).            00110000
001200      10 WUC111-MVR1-DRIVER-CODE           PIC  X(01).            00120000
001300      10 WUC111-MVR1-REPORT-DATE           PIC  X(10).            00130000
001400      10 WUC111-MVR1-CLASS                 PIC  X(01).            00140000
001500      10 WUC111-MVR1-STATUS                PIC  X(08).            00150000
001600      10 WUC111-MVR1-RESTRICTIONS          PIC  X(17).            00160000
001700      10 WUC111-MVR1-RECORD-CLEAR          PIC  X(01).            00170000
001800      10 WUC111-MVR1-LIC-EXP-DATE          PIC  X(10).            00180000
