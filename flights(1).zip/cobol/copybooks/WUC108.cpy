000100******************************************************************00010000
000200* WUC108 - VEHICLE COVERAGE COBOL II RECORD LAYOUT.            *  00020000
000300******************************************************************00030000
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00040000
000500* VEHICLE COVERAGE DATA TO BE PASSED TO AION.                    *00050000
000600*                                                                *00060000
000700******************************************************************00070000
000800*01 WUC108-COVERAGE-REC.                                          00080000
000900   05 WUC108-COVERAGE-INFORMATION OCCURS 400 TIMES                00090000
001000             INDEXED BY COV-IDX.                                  00100000
001100      10 WUC108-COV-GENERATION             PIC  X(01).            00110000
001200         88 WUC108-UNKNOWN-GENERATION                VALUE 'X'.   00120000
001300         88 WUC108-EXISTING-GENERATION               VALUE 'E'.   00130000
001400         88 WUC108-CHANGE-GENERATION                 VALUE 'C'.   00140000
001500      10 WUC108-COV-ACTION                 PIC  X(04).            00150000
001600      10 WUC108-COV-VEHICLE-NUMBER         PIC  9(04).            00160000
001700      10 WUC108-COV-LINE                   PIC  X(06).            00170000
001800      10 WUC108-COV-LIMIT                  PIC  X(10).            00180000
