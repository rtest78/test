# Input field mapping

Mappings follow the exact field boundaries used by the supplied AionRecordAdapter. Numeric-to-text values regain PIC width, including leading zeros. Text is trimmed as in the loaders.

| Copybook field | Raw fact property | Conversion |
|---|---|---|
| WUC101-TRAN-TYPE | TransData.TransType | text |
| WUC101-TRAN-CLUB-CODE | TransData.ClubCode | text |
| WUC101-TRAN-PRODUCT | TransData.Product | text |
| WUC102-POL-GENERATION | PolicyData.Generation | text |
| WUC102-POL-NEW-RENEW-CODE | PolicyData.New_Renew_Code | text |
| WUC102-POL-NAMED-INSURD-STATUS | PolicyData.Named_Insured_Status | text |
| WUC102-POL-EXCESS-POL-IND | PolicyData.Excess_Pol_Ind | text |
| WUC102-POL-COMMENTS-IND | PolicyData.Comments_Ind | text |
| WUC102-POL-GEN-EFF-DATE | PolicyData.Gen_Eff_Date | date |
| WUC102-POL-TRANS-DATE | PolicyData.Trans_Date | date |
| WUC102-POL-LONGEVITY-DATE | PolicyData.Longevity_Date | date |
| WUC102-POL-EXCESS-NB-POL-IND | PolicyData.Excess_Nb_POL_Ind | text |
| WUC102-POL-MGR-APPROVAL | PolicyData.Mgr_Approval | text |
| WUC102-POL-NAMED-INSRD-CHANGE | PolicyData.Named_Insured_Changed | text |
| WUC102-POL-JWL-HUON-PRM-DISCR | PolicyData.Jewel_HUON_Prem_Discrepancy | text |
| WUC102-POL-NB-REGD-OWNER-OTHER | PolicyData.NB_Regd_Owner_Other | text |
| WUC102-POL-BUSINESS-CLASS | PolicyData.Business_Class | text |
| WUC102-POL-EXCHLONGV-CHANGE | PolicyData.Inception_Change | text |
| WUC102-POL-AGENT-CHANGE | PolicyData.Agent_Change | text |
| WUC102-POL-CLUE-STATUS | PolicyData.Clue_Received | text |
| WUC102-POL-VADINS | PolicyData.VADINS | text |
| WUC102-POL-SD-LNH | PolicyData.SD_LNH | text |
| WUC102-POL-SD-LSH | PolicyData.SD_LSH | text |
| WUC102-POL-SD-LSHM | PolicyData.SD_LSHM | text |
| WUC102-POL-CLUE-NOT-RECD-DUMMY | PolicyData.CLUE_Not_Received | text |
| WUC102-EAD-MGR-APPROVAL | PolicyData.Mgr_EAD_Approval | text |
| WUC102-POL-CAC-LOSS-IND | PolicyData.CAC_Loss_Exists | text |
| WUC102-POL-CAC-DRV-ERR-IND | PolicyData.CAC_DrvCd_Error_Exists | text |
| WUC102-POL-ANN-MILE-OVR-IND | PolicyData.Ann_Mile_Override_Exists | text |
| WUC102-POL-REF-FOR-BRANCH-IND | PolicyData.Refer_Branch_Exists | text |
| WUC102-POL-REF-FOR-AGENT-IND | PolicyData.Refer_Agent_Exists | text |
| WUC102-POL-LIAB-ONLY-COVG-IND | PolicyData.Liab_Only_Covg_Exists | text |
| WUC102-POL-TRANS-TYPE | PolicyData.Trans_Type | text |
| WUC102-POL-BUS-CLASS-SCR | PolicyData.BusinessClass_Score | text |
| WUC102-POL-PRD-EFF-DATE | PolicyData.Pol_Prd_Eff_Dte | text (zero padded) |
| WUC102-PRD-RLS-EFF-DATE | PolicyData.Prod_Rlse_Eff_Dte | text |
| WUC102-RE-WRITTEN-POLICY-IND | PolicyData.Rewritten_Policy | text |
| WUC102-SPIN-OFF-POLICY-IND | PolicyData.SpinOff_Policy | text |
| WUC102-NNO-POLICY-IND | PolicyData.NNO_Policy | text |
| WUC102-BACKDATED-EFF-DATE-IND | PolicyData.Backdated_Eff_Dt | text |
| WUC103-POC-GENERATION | PolicyCodeData.Generation | text |
| WUC103-POC-ACTION | PolicyCodeData.Action | text |
| WUC103-POC-NAME | PolicyCodeData.Name | text |
| WUC103-POC-CODE | PolicyCodeData.Code | text |
| WUC104-DRV-GENERATION | DriverData.Generation | text |
| WUC104-DRV-DOP-ACTION | DriverData.Action | text |
| WUC104-DRV-DRIVER-NUMBER | DriverData.Driver_Number | text (zero padded) |
| WUC104-DRV-LICENSE-NUMBER | DriverData.License_Number | text |
| WUC104-DRV-DRIVER-CODE | DriverData.Driver_Code | text |
| WUC104-DRV-YR-FIRST-LICENSED | DriverData.YR_First_Licensed | int |
| WUC104-DRV-GOOD-DRIVER-IND | DriverData.Good_Driver_Ind | text |
| WUC104-DRV-RELATION-TO-APPLCNT | DriverData.Relation_to_Applicant | text |
| WUC104-DRV-NAMED-INSURED-IND | DriverData.Named_Insured_Ind | text |
| WUC104-DRV-ID-NUMBER | DriverData.ID_Number | text (zero padded) |
| WUC104-DRV-OUT-OF-STAT-LIC-IND | DriverData.Out_of_State_Lic | text |
| WUC104-DRV-OWN-CAR-AND-INS-IND | DriverData.Own_Car_and_Ins | text |
| WUC104-DRV-RSN-DRVR-ELIMD-C | DriverData.RemovalCode | text |
| WUC104-DRV-PROOF-OF-DEPEND-IND | DriverData.ProofOfDependencyInd | text |
| WUC104-DRV-BIRTHDATE | DriverData.Birthdate | date |
| WUC104-DRV-TOTAL-POINTS | DriverData.TOT_Points | int |
| WUC104-DRV-TOTAL-SUSP-COUNT | DriverData.Tot_Susp_Count | int |
| WUC104-DRV-CA-LIC-ISSUE-YEAR | DriverData.CAYR_First_Licensed | int |
| WUC104-DRV-PREV-LIC-OUT-OF-ST | DriverData.Prev_Lic_Out_of_State | text |
| WUC104-DRV-STUDENT-AWAY-IND | DriverData.Student_Away_Ind | text |
| WUC104-DRV-STUDENT-AWAY-REAPPL | DriverData.Student_Away_Reapplied | int |
| WUC104-DRV-OTH-COUNTRY-LIC-IND | DriverData.Other_Country_Lic | text |
| WUC104-DRV-CUR-OTH-CNTRY-LIC-I | DriverData.Cur_Other_Country_Lic | text |
| WUC105-EMP-GENERATION | EmploymentData.Generation | text |
| WUC105-EMP-ACTION | EmploymentData.Action | text |
| WUC105-EMP-DRIVER-NUMBER | EmploymentData.Driver_Number | text (zero padded) |
| WUC105-EMP-OCCUP-TITLE | EmploymentData.Occup_Title | text |
| WUC106-END-GENERATION | EndorsementData.Generation | text |
| WUC106-END-ACTION | EndorsementData.Action | text |
| WUC106-END-ENDORSEMENT-NAME | EndorsementData.Endorsement_Name | text |
| WUC106-END-OBJECT-ID | EndorsementData.Object_Id | text (zero padded) |
| WUC107-VEH-GENERATION | VehicleData.Generation | text |
| WUC107-VEH-DTL-ACTION | VehicleData.Action | text |
| WUC107-VEH-VEHICLE-NUMBER | VehicleData.Vehicle_Number | text (zero padded) |
| WUC107-VEH-VINN | VehicleData.VINN | text |
| WUC107-VEH-CAR-GROUP | VehicleData.Car_Group | text |
| WUC107-VEH-USE | VehicleData.Use | text |
| WUC107-VEH-YEAR | VehicleData.Year | int |
| WUC107-VEH-TRADE-NAME | VehicleData.Trade_Name | text |
| WUC107-VEH-SYMBOL | VehicleData.Symbol | text |
| WUC107-VEH-PURCHASE-PRICE | VehicleData.Purchase_Price | int |
| WUC107-VEH-LOAD-CAPACITY | VehicleData.Load_Capacity | text |
| WUC107-VEH-LIMIT-OF-LIABILITY | VehicleData.Limit_of_Liability | int |
| WUC107-VEH-CYCLE-LICENSE-IND | VehicleData.Cycle_License_Ind | text |
| WUC107-VEH-SEQUENCE-NUMBER | VehicleData.Sequence_Number | text (zero padded) |
| WUC107-VEH-REG-OWN-RELATIONSHP | VehicleData.Reg_Own_Relationship | text |
| WUC107-VEH-REG-OWN-DOB | VehicleData.Reg_Own_DOB | date |
| WUC107-VEH-PARKED-LOCATION | VehicleData.ParkedLocation | text |
| WUC107-VEH-ANTI-THEFT-CODE | VehicleData.AntiTheftCode | text |
| WUC107-VEH-PURCHASE-DATE | VehicleData.PurchaseDate | date |
| WUC107-VEH-EVR-C | VehicleData.EVRCode | text |
| WUC107-VDT-BODY-TYPE-X | VehicleData.Body_Type | text |
| WUC107-VDT-MILES-CALC-MTH | VehicleData.Miles_Calc_Mth | text |
| WUC107-VDT-ANN-MILES-C | VehicleData.Annual_Miles_Code | text (zero padded) |
| WUC107-PRI-RATE-DRV | VehicleData.Pri_Rated_Drv | text |
| WUC107-VEH-ELIM-REASON-CD | VehicleData.Elim_Reason_Cd | text |
| WUC107-VEH-ANNUAL-MILEAGE | VehicleData.Annual_Mileage | int |
| WUC107-VEH-VNDR-SRC-MILG | VehicleData.Vndr_Milg_Src | text |
| WUC107-VEH-MVSTORAGE | VehicleData.Storage_Ind | text |
| WUC108-COV-GENERATION | CoverageData.Generation | text |
| WUC108-COV-ACTION | CoverageData.Action | text |
| WUC108-COV-VEHICLE-NUMBER | CoverageData.Vehicle_Number | text (zero padded) |
| WUC108-COV-LINE | CoverageData.Line | text |
| WUC108-COV-LIMIT | CoverageData.Limit | text |
| WUC109-INS-GENERATION | InspectionData.Generation | text |
| WUC109-INS-ACTION | InspectionData.Action | text |
| WUC109-INS-VEHICLE-NUMBER | InspectionData.Vehicle_Number | text (zero padded) |
| WUC109-INS-MODIFIED-IND | InspectionData.Modified_Ind | text |
| WUC109-INS-PHOTO-CODE | InspectionData.Photo_Code | text |
| WUC110-DOV-GENERATION | DriverOfVehicleData.Generation | text |
| WUC110-DOV-ACTION | DriverOfVehicleData.Action | text |
| WUC110-DOV-VEHICLE-NUMBER | DriverOfVehicleData.Vehicle_Number | text (zero padded) |
| WUC110-DOV-DRIVER-NUMBER | DriverOfVehicleData.Driver_Number | text (zero padded) |
| WUC110-DOV-PRIMARY-DRVR-IND | DriverOfVehicleData.PrimaryDriverInd | text |
| WUC111-MVR1-LICENSE-NUMBER | MVR1Data.License_Number | text |
| WUC111-MVR1-DRIVER-CODE | MVR1Data.Driver_Code | text |
| WUC111-MVR1-REPORT-DATE | MVR1Data.Report_Date | date |
| WUC111-MVR1-CLASS | MVR1Data.Class | text |
| WUC111-MVR1-STATUS | MVR1Data.Status | text |
| WUC111-MVR1-RESTRICTIONS | MVR1Data.Restrictions | text |
| WUC111-MVR1-RECORD-CLEAR | MVR1Data.MVR_Record_Clear | text |
| WUC111-MVR1-LIC-EXP-DATE | MVR1Data.MVR_Lic_Exp_Date | date |
| WUC112-MVR2-LICENSE-NUMBER | MVR2Data.License_Number | text |
| WUC112-MVR2-SEQUENCE-NUMBER | MVR2Data.Sequence_Number | int |
| WUC112-MVR2-TYPE | MVR2Data.Type | text |
| WUC112-MVR2-VIOLATION-DATE | MVR2Data.Violation_Date | date |
| WUC112-MVR2-CONVICTION-DATE | MVR2Data.Conviction_Date | date |
| WUC112-MVR2-GOOD-DRIVER-PTS | MVR2Data.Good_Driver_Pts | int |
| WUC112-MVR2-CATEGORY | MVR2Data.Category | text |
| WUC112-MVR2-SURCHARGE | MVR2Data.Surcharge | text |
| WUC112-MVR2-DESCRIPTION | MVR2Data.Description | text |
| WUC113-MVR3-LICENSE-NUMBER | MVR3Data.License_Number | text |
| WUC113-MVR3-SEQUENCE-NUMBER | MVR3Data.Sequence_Number | int |
| WUC113-MVR3-GOOD-DRIVER-PTS | MVR3Data.Good_Driver_Pts | int |
| WUC113-MVR3-CATEGORY | MVR3Data.Category | text |
| WUC113-MVR3-SURCHARGE | MVR3Data.Surcharge | text |
| WUC113-MVR3-DESCRIPTION | MVR3Data.Description | text |
| WUC114-MVR4-LICENSE-NUMBER | MVR4Data.License_Number | text |
| WUC114-MVR4-SEQUENCE-NUMBER | MVR4Data.Sequence_Number | int |
| WUC114-MVR4-DESCRIPTION | MVR4Data.Description | text |
| WUC115-MVR5-LICENSE-NUMBER | MVR5Data.License_Number | text |
| WUC115-MVR5-SEQUENCE-NUMBER | MVR5Data.Sequence_Number | int |
| WUC115-MVR5-TYPE | MVR5Data.Type | text |
| WUC115-MVR5-ACCIDENT-DATE | MVR5Data.Accident_Date | date |
| WUC115-MVR5-DESCRIPTION | MVR5Data.Description | text |
| WUC115-MVR5-LIC-REIN-DATE | MVR5Data.Lic_Rein_Date | date |
| WUC116-MVR6-LICENSE-NUMBER | MVR6Data.License_Number | text |
| WUC116-MVR6-SEQUENCE-NUMBER | MVR6Data.Sequence_Number | int |
| WUC116-MVR6-DESCRIPTION | MVR6Data.Description | text |
| WUC117-ACC-GENERATION | AccidentData.Generation | text |
| WUC117-ACC-ACTION | AccidentData.Action | text |
| WUC117-ACC-DRIVER-NUMBER | AccidentData.Driver_Number | text (zero padded) |
| WUC117-ACC-LOSS-TYPE | AccidentData.Loss_Type | text |
| WUC117-ACC-ID | AccidentData.Acc_Id | int |
| WUC117-ACC-DATE | AccidentData.Acc_Date | date |
| WUC117-ACC-CHRGIND | AccidentData.Acc_ChrgInd | text |
| WUC118-CIT-GENERATION | CitationData.Generation | text |
| WUC118-CIT-ACTION | CitationData.Action | text |
| WUC118-CIT-DRIVER-NUMBER | CitationData.Driver_Number | text (zero padded) |
| WUC118-CIT-CATEGORY | CitationData.Category | int |
| WUC118-CIT-ID | CitationData.Cit_ID | int |
| WUC118-CIT-DATE | CitationData.Cit_Date | date |
| WUC119-SUSP-GENERATION | SuspensionData.Generation | text |
| WUC119-SUSP-ACTION | SuspensionData.Action | text |
| WUC119-SUSP-DRIVER-NUMBER | SuspensionData.Driver_number | text (zero padded) |
| WUC119-SUSP-ID | SuspensionData.Susp_id | int |
| WUC119-SUSP-DATE | SuspensionData.Susp_Date | date |
| WUC119-REIN-DATE | SuspensionData.Rein_Date | date |
| WUC120-PACE-DRVR-NUMBER | PACEData.DriverNumber | text (zero padded) |
| WUC120-PACE-DATE | PACEData.LossDate | date |
| WUC120-PACE-TYPE | PACEData.LossType | text |
| WUC120-PACE-STATUS | PACEData.LossStatus | text |
| WUC120-PACE-PAID-AMOUNT | PACEData.LossAmount | int |

Not consumed by existing loaders: WUC100, WUC122, WUC104 trailing fields and WUC109 trailing filler. All remain untouched in the IN_OUT object.
