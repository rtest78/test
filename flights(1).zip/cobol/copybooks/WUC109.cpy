000100******************************************************************00010000
000200* WUC109 - VEHICLE INSPECTION COBOL II RECORD LAYOUT.          *  00020000
000300******************************************************************00030000
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00040000
000500* VEHICLE INSPECTION DATA TO BE PASSED TO AION.                  *00050000
000600*                                                                *00060000
000700******************************************************************00070000
000800*01 WUC109-INSPECTION-REC.                                        00080000
000900   05 WUC109-INSPECTION-INFORMATION OCCURS 50 TIMES               00090000
001000             INDEXED BY INS-IDX.                                  00100000
001100      10 WUC109-INS-GENERATION             PIC  X(01).            00110000
001200         88 WUC109-UNKNOWN-GENERATION                VALUE 'X'.   00120000
001300         88 WUC109-EXISTING-GENERATION               VALUE 'E'.   00130000
001400         88 WUC109-CHANGE-GENERATION                 VALUE 'C'.   00140000
001500      10 WUC109-INS-ACTION                 PIC  X(04).            00150000
001600      10 WUC109-INS-VEHICLE-NUMBER         PIC  9(04).            00160000
001700      10 WUC109-INS-MODIFIED-IND           PIC  X(01).            00170000
001800      10 WUC109-INS-PHOTO-CODE             PIC  X(01).            00180000
001900      10 WUC109-FILLER                     PIC  X(07).            00190000
