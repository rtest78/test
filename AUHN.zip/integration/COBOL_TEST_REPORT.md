# AUHN local COBOL verification report

Date: October 12, 2026 (America/New_York).

**Result: all executed local tests passed. A working GnuCOBOL environment was created and the actual supplied copybooks were compiled and executed. IBM ODM/z/OS execution remains pending.**

| Check | Result | Evidence and scope |
|---|---|---|
| Native compiler | PASS | GnuCOBOL 3.1.2, GCC 13.2, Ubuntu 24.04; IBM dialect, 2/4/8-byte binary sizes, big-endian COMP |
| Original wrapper and WUC copybooks | PASS | All compile as supplied; no copybook edits |
| Decision-area length | PASS | 164,063 bytes, exactly matching the original generated IBM marshaller |
| Native field addresses | PASS | 385 field-offset checks; first/last occurrences checked for every table |
| Static IBM marshaller layout | PASS | 205 field offsets, 20 table start offsets/strides, total length; generated reader uses IBM-037 |
| Native COBOL → actual Java input mapper | PASS | NB/FULL; one policy, driver and vehicle; UTC date and zero-padded identifiers retained |
| Actual Java output mapper → native COBOL | PASS | Synthetic PAO route, two referral reasons, numeric identifiers, X marker and cleared unused slots; 16 expected return fields |
| Input bytes across the test round trip | PASS | All 163,398 bytes preceding WUC121 retained |
| Caller parameter contract | PASS WITH TEST DOUBLES | Single `auDecisionArea` parameter, correct name/address/length, other parameter entries cleared |
| Caller success and failure control flow | PASS WITH TEST DOUBLES | Six scenarios, 54 assertions; a rule failure is preserved across disconnect and subsequent success resets prior status |
| Java mapper regression | PASS | 205 assertions including parity for 177 mapped properties |
| IBM BOM/BAL compilation | NOT RUN | Requires Rule Designer/IBM rule compiler |
| Real IBM marshaller execution | NOT RUN | Generated JAR present, required IBM raw-data runtime classes absent |
| Actual business-rule evaluation | NOT RUN | No IBM execution engine installed |
| Enterprise COBOL / z/OS compilation | NOT RUN | GnuCOBOL syntax/behavior is not an IBM compiler gate |
| Real HBRRULE invocation and deployment | NOT RUN | No real HBRWS, HBR API libraries, z/OS connection or deployment target supplied |

The buffer bridge is an independent test-only ASCII codec. The HBR routines and HBRWS used in caller tests are labeled test fixtures. Neither test substitutes for IBM marshalling, IBM rules or a real deployed z/OS invocation.

No production code changes were necessary in this test run. Only test sources, a runner, and documentation were added. Copybooks, generated XOMs, original marshaller JARs and all 143 pre-existing business rules remain unchanged.

Reproduce with `bash integration/cobol-tests/run-tests.sh` after installing GnuCOBOL and a JDK 9+. Setup details and exact limitations are in `integration/cobol-tests/README.md`.
