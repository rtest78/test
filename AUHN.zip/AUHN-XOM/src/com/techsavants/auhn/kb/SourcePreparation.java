package com.techsavants.auhn.kb;

import java.util.*;
import static com.techsavants.auhn.kb.SourceFacts.*;

/** Port of AUHNBOBJ.PopulateBusinessObjects and its preparation dependencies.
 *  Decision conditions, referral codes and routes are in the ODM BAL project.
 *  Collections retain source order. See review/source_comparison.md for limits.
 */
final class SourcePreparation {
    private final RuleContext c;
    private final Date effective;
    private final boolean nb;
    SourcePreparation(RuleContext context) {
        c=context;
        if(c.getTransDataFacts().isEmpty())throw new IllegalArgumentException("FULL input requires TransData");
        if(c.getPolicyDataFacts().isEmpty())throw new IllegalArgumentException("FULL input requires PolicyData");
        c.setTransactionType(text(c.getTransDataFacts().get(0),"TransType"));
        effective=date(c.getPolicyDataFacts().get(0),"Gen_Eff_Date");
        if(effective==null)throw new IllegalArgumentException("PolicyData.Gen_Eff_Date is required");
        c.setEffectiveDate(effective);c.validatePrepared();nb="NB".equals(c.getTransactionType());
    }
    private static <T> T create(Class<T> type) {
        try {return type.getDeclaredConstructor().newInstance();}catch(Exception e){throw new IllegalStateException(e);}
    }
    private void application(Object target,Object raw) {
        set(target,"Action",get(raw,"Action"));set(target,"Generation",get(raw,"Generation"));
    }
    private void flags(List<?> list,String... changedKeys) {
        for(Object f:list) {
            boolean current="C".equals(text(f,"Generation")),existing="E".equals(text(f,"Generation"));
            boolean changed=false;
            if(!current && changedKeys.length>0) for(Object p:list) if("C".equals(text(p,"Generation"))) {
                boolean same=true;
                for(String key:changedKeys)if(!eq(get(f,key),get(p,key))){same=false;break;}
                if(same){changed=true;break;}
            }
            boolean currentInfo=nb || (current?!"ELIM".equals(text(f,"Action")):!changed);
            if(f instanceof Policies)currentInfo=nb || current;
            set(f,"IsCurrentInfo",currentInfo);
            set(f,"IsNewInfo",nb || current);set(f,"IsExistingInfo",nb || existing);
            set(f,"IsAddedOrNew",nb || f instanceof Policies && current || current && ("ADD".equals(text(f,"Action")) || f instanceof Vehicles && "REPL".equals(text(f,"Action"))));
        }
    }
    private <T> void map(List<?> raw,List<T> target,Class<T> type,String... keys) {
        target.clear();
        for(Object r:raw) {T t=create(type);application(t,r);SourceMappings.copy(t,r);target.add(t);}
        flags(target,keys);
    }
    private void activity(Object f,Date date,int period) {
        set(f,"ActivityDate",date);set(f,"ExperiencePeriod",period);
        boolean count=within(date,effective,period);
        set(f,"IsWithinExperiencePeriod",count);set(f,"IsCountable",count);
    }
    private DriverData driverBy(String property,String value) {
        for(DriverData d:c.getDriverDataFacts())if(eq(get(d,property),value))return d;
        return null;
    }
    private MVRHierarchy hierarchy(Object raw) {
        for(MVRHierarchy h:c.getMVRHierarchyFacts())if(eq(h.getVLicenseNumber(),get(raw,"License_Number")) && eq(h.getVSequenceNumber(),get(raw,"Sequence_Number")))return h;
        return null;
    }
    private void fromMvr(Object f,Object raw,String dateProperty,int period) {
        set(f,"Action","");set(f,"Generation","C");
        DriverData driver=driverBy("License_Number",text(raw,"License_Number"));
        set(f,"DriverNumber",get(driver,"Driver_Number"));
        set(f,"RecordType",get(raw,"Type"));
        activity(f,date(raw,dateProperty),period);
        set(f,"IsCurrentInfo",true);set(f,"IsNewInfo",true);set(f,"IsExistingInfo",true);set(f,"IsAddedOrNew",true);
    }
    void populate() {
        map(c.getPolicyDataFacts(),c.getPoliciesFacts(),Policies.class);
        for(int i=0;i<c.getPoliciesFacts().size();i++) {
            Object raw=c.getPolicyDataFacts().get(i),p=c.getPoliciesFacts().get(i);
            set(p,"VehicleSpecialEquipmentFlag",yn(get(raw,"SD_LNH")) || yn(get(raw,"SD_LSH")) || yn(get(raw,"SD_LSHM")));
        }
        map(c.getCoverageDataFacts(),c.getCoveragesFacts(),Coverages.class,"VehicleNumber","CoverageLimitText","CoverageType");
        for(Coverages v:c.getCoveragesFacts()) {
            String limit=text(v,"CoverageLimitText");
            int slash=limit==null?-1:limit.indexOf('/');
            if("BI".equals(text(v,"CoverageType"))) {
                set(v,"CoverageLimit",slash<0?null:integer(limit.substring(0,slash)));
                set(v,"BILimit2",slash<0?null:integer(limit.substring(slash+1)));
            } else set(v,"CoverageLimit",integer(limit));
        }
        map(c.getInspectionDataFacts(),c.getInspectionsFacts(),Inspections.class,"VehicleNumber");
        map(c.getAccidentDataFacts(),c.getAccidentsAdmittedFacts(),AccidentsAdmitted.class,"DriverNumber","AccidentID");
        for(AccidentsAdmitted a:c.getAccidentsAdmittedFacts())activity(a,date(a,"ActivityDate"),36);
        pace();
        c.getAccidentsMVRFacts().clear();
        for(MVR5Data raw:c.getMVR5DataFacts())if("ACC".equals(text(raw,"Type"))) {
            AccidentsMVR a=new AccidentsMVR();fromMvr(a,raw,"Accident_Date",36);set(a,"LossType",get(raw,"Type"));c.getAccidentsMVRFacts().add(a);
        }
        citations();
        suspensions();
        c.getFailuresToAppearFacts().clear();
        for(MVR5Data raw:c.getMVR5DataFacts())if("FTA".equals(text(raw,"Type"))) {
            FailuresToAppear a=new FailuresToAppear();fromMvr(a,raw,"Accident_Date",36);c.getFailuresToAppearFacts().add(a);
        }
        c.getLicenseActionsFacts().clear();
        licenseActions(c.getMVR2DataFacts(),"Conviction_Date");licenseActions(c.getMVR5DataFacts(),"Lic_Rein_Date");
        map(c.getEmploymentDataFacts(),c.getOccupationsFacts(),Occupations.class,"DriverNumber");
        drivers();
        map(c.getDriverOfVehicleDataFacts(),c.getDriversOfVehiclesFacts(),DriversOfVehicles.class,"DriverNumber","VehicleNumber");
        vehicles();
        map(c.getEndorsementDataFacts(),c.getEndorsementsFacts(),Endorsements.class,"EndorsementNumber","ObjectID");
        map(c.getPolicyCodeDataFacts(),c.getPolicyCodesFacts(),PolicyCodes.class,"Code","Name");
    }
    private void pace() {
        c.getAccidentsPACEFacts().clear();
        for(PACEData raw:c.getPACEDataFacts()) {
            AccidentsPACE a=new AccidentsPACE();set(a,"Action","");set(a,"Generation","C");SourceMappings.copy(a,raw);
            DriverData driver=driverBy("ID_Number",text(raw,"DriverNumber"));set(a,"DriverNumber",get(driver,"Driver_Number"));
            String type=text(a,"LossType"),status=text(a,"LossStatus");Integer amount=number(a,"LossAmount");
            Date date=date(a,"ActivityDate");activity(a,date,"CP".equals(type)?12:36);
            boolean duplicate=false;
            for(AccidentsPACE p:c.getAccidentsPACEFacts())if(eq(get(a,"DriverNumber"),get(p,"DriverNumber")) && eq(date,date(p,"ActivityDate")) && flag(p,"IsCountable")){duplicate=true;break;}
            boolean count=flag(a,"IsWithinExperiencePeriod") && !duplicate && SourceTables.aboveLossThreshold(type,amount,status) && !"CP".equals(type);
            if(count && "C".equals(status) && date!=null && amount!=null) {
                int comparison=day(date).compareTo(java.time.LocalDate.of(2011,12,11));
                if(Arrays.asList("UMPD","CO","UC").contains(type) && comparison>=0 && amount<1000)count=false;
                if("MP".equals(type) && comparison<0 && amount<750)count=false;
            }
            set(a,"IsCountable",count);c.getAccidentsPACEFacts().add(a);
        }
        flags(c.getAccidentsPACEFacts());
        for(AccidentsPACE a:c.getAccidentsPACEFacts()) {
            set(a,"IsCurrentInfo",true);set(a,"IsNewInfo",true);set(a,"IsExistingInfo",true);set(a,"IsAddedOrNew",true);
        }
    }
    private void citations() {
        map(c.getCitationDataFacts(),c.getCitationsAdmittedFacts(),CitationsAdmitted.class,"DriverNumber","CitationID");
        for(CitationsAdmitted a:c.getCitationsAdmittedFacts())activity(a,date(a,"ActivityDate"),eq(2,get(a,"Category"))?120:36);
        c.getCitationsMVRFacts().clear();
        for(MVR2Data raw:c.getMVR2DataFacts())if("ABST".equals(text(raw,"Type"))) {
            CitationsMVR a=new CitationsMVR();Integer category=integer(text(raw,"Category"));if(category==null)category=0;
            set(a,"Category",category);fromMvr(a,raw,"Violation_Date",category==2?120:36);
            MVRHierarchy h=hierarchy(raw);boolean dismissed=false;
            if(h!=null)for(Object detail:h.getAttached()) {
                if(detail instanceof MVR3Data) {
                    Integer other=integer(text(detail,"Category"));
                    if(other!=null && other>=1 && other<=6 && (category==0 || other<category))category=other;
                }
                String description=text(detail,"Description");
                if(contains(description,"ABOVE ABSTRACT DISMISSED") && (contains(description,"1803.5") || contains(description,"1808.7")))dismissed=true;
            }
            // Source Merge changes Category without recomputing experience/countability.
            set(a,"Category",category);set(a,"DismissedFlag",dismissed);c.getCitationsMVRFacts().add(a);
        }
        c.getCitationsFacts().clear();c.getCitationsFacts().addAll(c.getCitationsAdmittedFacts());c.getCitationsFacts().addAll(c.getCitationsMVRFacts());
    }
    private void suspensions() {
        map(c.getSuspensionDataFacts(),c.getSuspensionsAdmittedFacts(),SuspensionsAdmitted.class,"DriverNumber","SuspensionID");
        for(int i=0;i<c.getSuspensionsAdmittedFacts().size();i++) {
            SuspensionsAdmitted a=c.getSuspensionsAdmittedFacts().get(i);SuspensionData raw=c.getSuspensionDataFacts().get(i);
            Date original=date(a,"ActivityDate");activity(a,original,36);
            if(!flag(a,"IsWithinExperiencePeriod")) {
                Date reinstated=date(raw,"Rein_Date");
                if(reinstated!=null) {
                    int compare=day(reinstated).compareTo(java.time.LocalDate.of(1,1,1));
                    if(compare>=0)activity(a,compare==0?effective:reinstated,36);
                }
            }
            set(a,"ActivityDate",original);
        }
        c.getSuspensionsMVRFacts().clear();
        for(MVR5Data raw:c.getMVR5DataFacts())if("SUSP".equals(text(raw,"Type"))) {
            SuspensionsMVR a=new SuspensionsMVR();fromMvr(a,raw,"Accident_Date",36);c.getSuspensionsMVRFacts().add(a);
        }
    }
    private void licenseActions(List<?> raws,String dateField) {
        for(Object raw:raws) {
            String type=text(raw,"Type"),desc=text(raw,"Description");
            if("SUSP".equals(type) || "REIN".equals(type) || "DEPT".equals(type) && (contains(desc,"CANCELLED") || contains(desc,"REVOKED"))) {
                LicenseActions a=new LicenseActions();fromMvr(a,raw,dateField,36);set(a,"IsWithinExperiencePeriod",true);
                Date actionDate=date(a,"ActivityDate");set(a,"IsCountable",!"REIN".equals(type) || actionDate!=null && day(actionDate).isAfter(day(effective)));
                c.getLicenseActionsFacts().add(a);
            }
        }
    }
    private void drivers() {
        map(c.getDriverDataFacts(),c.getDriversFacts(),Drivers.class,"DriverNumber");c.getDriversMVRInfoFacts().clear();
        int net=0;
        for(Drivers d:c.getDriversFacts()) {
            String driver=text(d,"DriverNumber");
            set(d,"YearsExperience",yearSpan(number(d,"YrFirstLicensed"),effective));
            set(d,"CAYearsExperience","".equals(text(d,"LicenseNumber"))?Integer.valueOf(0):yearSpan(number(d,"CAYearFirstLicensed"),effective));
            set(d,"Age",years(date(d,"Birthdate"),effective));
            set(d,"AdmittedCitationCount",countActivities(c.getCitationsAdmittedFacts(),driver,false,false));
            set(d,"AdmittedAccidentCount",countActivities(c.getAccidentsAdmittedFacts(),driver,false,false));
            if(!nb) {
                int points=0;List<Object> acts=new ArrayList<Object>();acts.addAll(c.getAccidentsAdmittedFacts());acts.addAll(c.getCitationsAdmittedFacts());
                for(Object a:acts)if(flag(a,"IsCurrentInfo") && eq(get(a,"DriverNumber"),driver))points+=points(a);
                set(d,"TotalGoodDriverPoints",points);
            }
            mvrInfo(d);
            if(Arrays.asList("D","T","I").contains(text(d,"DriverCode"))) {
                if(flag(d,"IsNewInfo") && !"ELIM".equals(text(d,"Action")))net++;
                if(flag(d,"IsExistingInfo"))net--;
            }
        }
        for(Drivers d:c.getDriversFacts())set(d,"NetDriverCount",net);
    }
    private void mvrInfo(Drivers driver) {
        String license=text(driver,"LicenseNumber"),number=text(driver,"DriverNumber");
        driver.setVMVRInfo(null);driver.setVMVRSearchStatus(-1);
        if(license==null || license.isEmpty())return;
        boolean pending=false;
        for(MVR6Data d:c.getMVR6DataFacts())if(eq(license,text(d,"License_Number"))) {
            String desc=text(d,"Description");int status=0;
            if(contains(desc,"MVR RECORD NOT FOUND") || contains(desc,"MVR NOT FOUND"))status=2;
            else if(contains(desc,"ABNORMAL PROCESSING OF MVR"))status=3;
            else if(contains(desc,"INVALID LICENSE KEYED BY USER"))status=4;
            else if(contains(desc,"MVR NOT ORDERED"))status=5;
            else if(contains(desc,"MVR NOT RECEIVED"))status=6;
            if(status!=0){driver.setVMVRSearchStatus(status);return;}
            if(contains(desc,"PENDING"))pending=true;
        }
        MVR1Data raw=null;
        for(MVR1Data d:c.getMVR1DataFacts())if(eq(license,text(d,"License_Number"))){raw=d;break;}
        if(raw==null)return;
        DriversMVRInfo m=new DriversMVRInfo();SourceMappings.copy(m,raw);set(m,"DriverNumber",number);set(m,"LicenseNumber",license);set(m,"PendingFlag",pending);
        Long days=days(date(m,"MVRLicenseExpireDate"),effective);
        boolean expired=days!=null && days>0,suspended=countActivities(c.getLicenseActionsFacts(),number,false,true)>0;
        set(m,"LicenseExpiredFlag",expired);set(m,"LicExpired60DaysFlag",days!=null && days>60);set(m,"SuspendedCancelledRevokedFlag",suspended);
        set(m,"HasValidLicense",!expired && !suspended && !Arrays.asList("X","0").contains(text(m,"MVRLicenseClass")) && !Arrays.asList("1","2","3","4").contains(text(m,"MVRStatus")));
        set(m,"MVRAccidentCount",countActivities(c.getAccidentsMVRFacts(),number,false,true));
        set(m,"MVRCitationCount",countActivities(c.getCitationsMVRFacts(),number,false,true));
        set(m,"MVRSuspensionCount",countActivities(c.getSuspensionsMVRFacts(),number,false,true));
        int dismissed=0;
        for(CitationsMVR a:c.getCitationsMVRFacts())if(eq(number,get(a,"DriverNumber")) && flag(a,"DismissedFlag") && flag(a,"IsCountable"))dismissed++;
        set(m,"DismissedCount",dismissed);set(m,"NumberOfFTAsAndDismissals",dismissed+countActivities(c.getFailuresToAppearFacts(),number,false,true));
        driver.setVMVRSearchStatus(0);driver.setVMVRInfo(m);c.getDriversMVRInfoFacts().add(m);
    }
    private void vehicles() {
        map(c.getVehicleDataFacts(),c.getVehiclesFacts(),Vehicles.class,"VehicleNumber");
        int net=0,mileage=0;
        for(int i=0;i<c.getVehiclesFacts().size();i++) {
            Vehicles v=c.getVehiclesFacts().get(i);VehicleData raw=c.getVehicleDataFacts().get(i);
            set(v,"Age",yearSpan(number(v,"Year"),effective));
            Date purchase=date(v,"PurchaseDate");
            set(v,"MonthsOfOwnership",purchase!=null && day(purchase).equals(java.time.LocalDate.of(1,1,1))?null:months(purchase,effective,false));
            String parked=text(raw,"ParkedLocation");set(v,"GaragedFlag",parked!=null && parked.startsWith("4"));set(v,"HasNonGoodDriver",false);
            if(Arrays.asList("REGL","REGU","NISO").contains(text(v,"CarGroup"))) {
                if(flag(v,"IsCurrentInfo") && !"ELIM".equals(text(v,"Action")))net++;
                if(flag(v,"IsExistingInfo"))net--;
                Integer miles=number(v,"AnnualMileage");
                if(miles!=null){if(flag(v,"IsCurrentInfo"))mileage+=miles;if(flag(v,"IsExistingInfo"))mileage-=miles;}
            }
        }
        for(Vehicles v:c.getVehiclesFacts()){set(v,"NetVehicleCount",net);set(v,"HHAnuMilgChange",mileage);}
    }
}
