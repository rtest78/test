**October 25 update:** Read ../START-HERE-RULEAPP-FIX.md first for the current XOM references, rebuild instructions and validation limits.

# AUHN COBOL integration

**Current batch caller:** use `../cobol/src/AUHNCB.cbl` with AUODM-DECISION-AREA, ODM-RULESET-PATH and ODM-CALL-STATUS. See `../cobol/README.md` for the new fixed-format batch code, PDS-safe AUODM copybook alias, warning handling and JCL. The older one-argument AUHNCALL example below is retained for existing consumers.

## Status

Source implementation is complete for the mapper, single IN_OUT parameter, input initialization, and WUC121 output mapping. Existing business rules remain byte-for-byte unchanged. The ruleflow now brackets them with two mapping tasks.

Local Java verification: compiled to Java 8 bytecode; 205 assertions passed, including parity for all 177 properties read by the existing AION loaders. The test uses the original generated COBOL class files, not substitute classes.

Additional local COBOL verification now passed: native GnuCOBOL compilation/execution, 385 field offsets, static IBM marshaller layout, a test-codec buffer round trip through the real mapper, and six caller scenarios using test doubles. See `COBOL_TEST_REPORT.md` and `cobol-tests/README.md`.

Not performed: IBM Rule Designer build, BAL/BOM compilation, execution of existing rules, IBM Enterprise COBOL compilation, real IBM marshalling round trip, RuleApp deployment, or real HBRRULE execution. No IBM engine, server endpoint, credentials, or z/OS connection was supplied. This archive is a source workspace, not a deployable RuleApp archive.

## 1. Import and build in Rule Designer

1. Import the five projects from this archive using File > Import > General > Existing Projects into Workspace. Use a separate workspace for this interface change, or back up the existing projects first.
2. Projects: AUHN-XOM, AUHN-COBOL-XOM, **AUHN-COBOL-Adapter** (new), AUHN-BOM, AUHN-Rules.
3. The adapter depends on both Java XOM projects. Its implementation is `AUHN-COBOL-Adapter/src/com/aaa/auhn/adapter/AuDecisionAreaMapper.java`.
4. AUHN-Rules now references the adapter on its XOM path and `bom/AUHN-COBOL-Bridge.bom` on its BOM path. The bridge exposes only the root COBOL type and two mapper methods; existing BOM vocabulary is unchanged. The supplied COBOL XOM and marshaller still define the physical layout. Do not generate a new physical copybook from this minimal bridge BOM.
5. Run Project > Clean, then build all projects. Review the Problems view before deployment. The bridge BOM/BAL assets have been structurally checked but require this IBM compiler gate.
6. If your ODM release requires regenerating the bridge BOM, create its entry from the existing `Auodm_decision_area` XOM type and `AuDecisionAreaMapper` methods, preserve the two phrases from `AUHN-COBOL-Bridge_en_US.voc`, and avoid defining the same type in two BOM entries. Do not regenerate or change the COBOL data layout.

## 2. Verify variables and operation

`rules/AUHN_Parameters.var` now contains:

| Variable | Type | Operation direction |
|---|---|---|
| auDecisionArea | com.aaa.auhn.cobol.Auodm_decision_area | IN_OUT |
| request | com.aaa.auhn.kb.AuhnRequest | Internal only |
| response | com.aaa.auhn.kb.AuhnResponse | Internal only |
| context | com.aaa.auhn.kb.RuleContext | Internal only |

Open `deployment/AUHN_KB_Rules.dop`: there must be exactly one exposed parameter, named **auDecisionArea**, direction **IN_OUT**, with `BAL_AUHN_KB_Main` as the ruleflow.

This replaces the old request-IN/response-OUT interface. Existing JSON/Java callers using those parameters will need their old deployed ruleset version or an independent operation. Use a new ruleset version for this contract change; record the exact path after deployment.

## 3. Verify the flow

Start → Map COBOL Input → existing initialization and MVR/referral processing → Populate AUHN Response → Map COBOL Output → Stop.

The input task creates an AuhnRequest, sets FULL execution, and resets internal context/response. WUC101-TRAN-TYPE is the authoritative NB/AO transaction type. The existing rules construct RuleContext, prepare business objects, evaluate decisions, and create AuhnResponse. The output task writes into the same auDecisionArea instance.

The existing .brl files were not modified. Two new lifecycle rules were added in explicit Sequential tasks; existing business rules keep their original execution modes and order. No rule-engine execution has been claimed by the mapper tests.

## 4. Mapping contract and limitations

- Input: WUC101 and WUC102–WUC120 map to the existing raw fact classes. `FIELD_MAPPING.md` lists every field/property mapping, grounded in matching copybook boundaries and AionRecordAdapter offsets.
- WUC100 and WUC122 remain present and unchanged, but do not populate new facts. The supplied AION loaders do not consume them. WUC104 trailing fields and WUC109 filler are likewise not consumed. This preserves the supplied loader scope; it does not establish equivalence to unseen AION source.
- Numeric identifiers regain their original PIC width when the business XOM expects text. This preserves leading zeros and associations.
- Arrays retain source order. X generation markers, blank generation/action pairs, XXXXXXXXXX MVR license markers, and zero PACE driver numbers end the corresponding table. Null arrays are treated as absent; a null element ends that table. A blank policy generation also ends the policy table (explicit bridge behavior for unused initialized rows).
- WUC102 must contain at least one policy and the first policy must have Gen_Eff_Date. Dates use UTC, matching AuhnValues. MM/dd/yyyy and yyyyMMdd are accepted. Empty/zero dates become null; other malformed dates are rejected rather than silently becoming null. This is stricter than the old loader and needs agreement for production input data.
- WUC121: a route of 1–5 characters; at most 60 referrals; exactly 3-character reason codes; vehicle and driver identifiers must be numeric and fit 0000–9999. A long zero-padded identifier is accepted if its numeric value fits. Values greater than 9999 are rejected, not truncated. Existing rules use 9999 for unspecified driver/vehicle.
- The next unused reason has `X` as its code, consistent with the legacy marker. Remaining codes are spaces and unused numeric values are zero (valid PIC 9). All 60 slots may hold reasons, in which case there is no X slot. Confirm the caller stops at X **or** the 60-slot boundary. The legacy `results()` text formatter uses a 664-character buffer, whereas this copybook has 665 bytes (5 + 60×11); the new typed mapper follows WUC121 and does not use that formatter.
- WUC121 is fully validated before mutation, and all unused output slots are rebuilt to avoid stale values. On any mapping or execution error, the caller must reject the call and not interpret old WUC121 data as a new decision.
- Changes to the copybook, generated XOM or marshaller must be coordinated; none was changed here. The XML still contains its original Windows importer settings, which may need local adjustment if reimporting.

## 5. Deploy RuleApp and runtime dependencies

1. Complete the Rule Designer build without errors.
2. Run representative NB and AO cases through the operation in your ODM test environment. Compare route and all reasons against the original request/response operation and approved AION expected outputs.
3. Open `deployment/AUHN_KB_RuleApp.dep`. It already has managed XOM enabled. Inspect the deployment's XOM selection and include the current AUHN-XOM, AUHN-COBOL-XOM, AUHN-COBOL-Adapter, and AUHN-COBOL-XOM-xmarshaller.jar. The new adapter JAR is also under `integration/lib` for explicit runtime packaging when needed.
4. Deploy to your configured zRule Execution Server/RES target with a new ruleset version. Do not overwrite an old contract version still used by request/response clients.
5. In RES, verify the deployed parameter name/type/direction and that the execution classloader resolves both XOMs, the adapter and the marshaller. Verify the generated COBOL marshalling resources are linked to the ruleset; a Java-only invocation passing does not prove this.
6. Record the exact deployed RuleApp/ruleset version path for the COBOL caller. The sample path is a placeholder and must match the deployed version.

IBM documentation confirms that COBOL execution requires deploying the COBOL XOM, marshaller and RuleApp: https://www.ibm.com/docs/en/odm/9.0.0?topic=models-overview-bom-execution-object-model-xom

## 6. Call from COBOL

`AUHN-HBRRULE.cbl` is a subprogram example taking AUODM-DECISION-AREA by reference. It registers **one parameter**, with its name, address and `LENGTH OF` the complete wrapper, then calls HBRCONN → HBRRULE → HBRDISC. It checks each completion code and preserves a rule failure across disconnect.

1. Compile with your installed HBRWS and the exact supplied copybooks. The source switches to fixed format for the wrapper/copybooks, which contain sequence columns. Adjust compiler source-format options for your site.
2. Link using the installed ODM batch/CICS/IMS sample appropriate to your environment. Use that sample's load libraries, HBRENVPR configuration, subsystem and security settings. No fabricated JCL dataset names are supplied.
3. The calling program must initialize the entire wrapper with valid numeric values, then populate its policy/transaction and active table rows. Existing separate record buffers must be moved into the combined wrapper before the call. Do not pass only WUC100, only WUC121, or a concatenation with a different layout.
4. For a batch/LE caller: `CALL 'AUHNCALL' USING AUODM-DECISION-AREA`. Check RETURN-CODE. Adapt return handling to your CICS/IMS convention if necessary.
5. On success, read WUC121-ROUTING-DESTINATION and scan WUC121-ROUTING-REASONS up to the X marker or 60 entries. On failure, log the HBR completion/reason/message and do not consume the output.
6. Verify your site's CCSID, binary field/compiler conventions and buffer size using an actual COBOL round-trip test. The sample retains the installed HBRWS default CCSID; do not assume that default matches your data.

API reference: https://www.ibm.com/docs/en/odm/8.12.0?topic=reference-apis
Caller workflow: https://www.ibm.com/docs/en/drfz/9.5.0?topic=applications-adding-api-calls-zos-client-application

## 7. Local Java tests

Test sources and loader fixtures are in `AUHN-COBOL-Adapter/test`. From the extracted archive root, run `bash integration/test-mapper.sh` with a JDK 9+ (the script compiles for Java 8). Or run MapperTest as a Java application in Eclipse with both XOMs and the adapter on its classpath; pass `AUHN-COBOL-Adapter/test/loader-parity.tsv` as the program argument and use the extracted root as working directory.

The tests validate field values, UTC dates, sentinel handling, invalid transaction/date rejection, capacities, atomic output failure and retained input fields. They do not execute IBM rules or marshal COBOL bytes.
