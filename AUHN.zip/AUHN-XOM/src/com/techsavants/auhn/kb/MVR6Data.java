package com.techsavants.auhn.kb;
public class MVR6Data {
    private String vDescription;
    public String getVDescription() { return vDescription; }
    public void setVDescription(String value) { vDescription = value; }
    private String vLicense_Number;
    public String getVLicense_Number() { return vLicense_Number; }
    public void setVLicense_Number(String value) { vLicense_Number = value; }
    private Integer vSequence_Number;
    public Integer getVSequence_Number() { return vSequence_Number; }
    public void setVSequence_Number(Integer value) { vSequence_Number = value; }
}
