package com.aaa.auhn.kb;
public class DriverOfVehicleData {
    private String vDriver_Number;
    public String getVDriver_Number() { return vDriver_Number; }
    public void setVDriver_Number(String value) { vDriver_Number = value; }
    private String vVehicle_Number;
    public String getVVehicle_Number() { return vVehicle_Number; }
    public void setVVehicle_Number(String value) { vVehicle_Number = value; }
    private String vPrimaryDriverInd;
    public String getVPrimaryDriverInd() { return vPrimaryDriverInd; }
    public void setVPrimaryDriverInd(String value) { vPrimaryDriverInd = value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction=value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
}
