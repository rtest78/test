       >>SOURCE FORMAT FREE
*> TEST DOUBLE ONLY. NO IBM RUNTIME OR BUSINESS RULE EXECUTION.
identification division.
program-id. HBRDISC.
data division.
working-storage section.
       >>SOURCE FORMAT FIXED
           COPY CONTROL.
       >>SOURCE FORMAT FREE
linkage section.
       >>SOURCE FORMAT FIXED
           COPY HBRWS.
       >>SOURCE FORMAT FREE
procedure division using HBRA-CONN-AREA.
    add 1 to disc-count
    if TEST-HBR-HEADER not = 'FIXTURE!'
        add 1 to fixture-errors
    end-if
    move zero to HBRA-CONN-COMPLETION-CODE HBRA-CONN-REASON-CODE
    move spaces to HBRA-RESPONSE-MESSAGE
    if test-case = 'DISC-WARN'
        move 4 to HBRA-CONN-COMPLETION-CODE
        move 3011 to HBRA-CONN-REASON-CODE
        move 'TEST DISC WARNING'to HBRA-RESPONSE-MESSAGE
    end-if
    if test-case = 'DISC-FAIL' or test-case = 'BOTH-FAIL'
        move 8 to HBRA-CONN-COMPLETION-CODE
        move 3001 to HBRA-CONN-REASON-CODE
        move 'TEST DISC FAILURE' to HBRA-RESPONSE-MESSAGE
    end-if
    goback.
end program HBRDISC.
