package com.techsavants.auhn.kb;
public class EndorsementData {
    private String vEndorsement_Name;
    public String getVEndorsement_Name() { return vEndorsement_Name; }
    public void setVEndorsement_Name(String value) { vEndorsement_Name = value; }
    private String vObject_Id;
    public String getVObject_Id() { return vObject_Id; }
    public void setVObject_Id(String value) { vObject_Id = value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction=value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
}
