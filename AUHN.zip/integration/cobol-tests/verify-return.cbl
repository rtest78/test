       >>SOURCE FORMAT FREE
identification division.
program-id. VERIFYRETURN.
environment division.
input-output section.
file-control.
    select area-file assign to 'decision-area-returned.bin'
        organization sequential access mode sequential
        file status ws-file-status.
data division.
file section.
fd area-file.
01 area-record pic x(164063).
working-storage section.
01 ws-file-status pic xx.
       >>SOURCE FORMAT FIXED
           COPY AUODM-WRAPPER.
       >>SOURCE FORMAT FREE
procedure division.
    open input area-file
    if ws-file-status not = '00'
        display 'FAIL: open ' ws-file-status
        move 12 to return-code goback
    end-if
    read area-file
    if ws-file-status not = '00'
        display 'FAIL: read ' ws-file-status
        move 12 to return-code goback
    end-if
    move area-record to AUODM-DECISION-AREA
    close area-file
    if WUC100-TRANCNT not = 1234 or
        WUC100-EFFECTDTE not = 20261012 or
        WUC101-TRAN-TYPE not = 'NB' or
        WUC104-DRV-DRIVER-NUMBER(1) not = 12 or
        WUC107-VEH-VEHICLE-NUMBER(1) not = 7 or
        WUC121-ROUTING-DESTINATION not = 'PAO' or
        WUC121-RSN-CODE(1) not = '011' or
        WUC121-RSN-VEHICLE-NUMBER(1) not = 7 or
        WUC121-RSN-DRIVER-NUMBER(1) not = 12 or
        WUC121-RSN-CODE(2) not = '012' or
        WUC121-RSN-VEHICLE-NUMBER(2) not = 9999 or
        WUC121-RSN-DRIVER-NUMBER(2) not = 9999 or
        WUC121-RSN-CODE(3) not = 'X' or
        WUC121-RSN-CODE(60) not = spaces or
        WUC121-RSN-VEHICLE-NUMBER(60) not = 0 or
        WUC121-RSN-DRIVER-NUMBER(60) not = 0
        display 'FAIL: cross-language returned values'
        move 12 to return-code goback
    end-if
    display 'PASS: native COBOL reads 16 expected return fields'
    move zero to return-code goback.
