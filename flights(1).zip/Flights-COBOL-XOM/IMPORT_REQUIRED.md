# IBM importer generation required

The Java files in this project are hand-written contract models used to compile
the mapper and run local tests. They contain no IBM COBOL annotations or IBM
marshalling implementation. They must be replaced with IBM importer output
before running FlightsCOBOL through HBRRULE.

Import Flights/Copybooks/FLIGHTOD.cpy with FLTIN.cpy and FLTOUT.cpy on the copy
search path, using this project and package com.techsavants.flights.cobol.
Compare generated property names/types and adapt the mapper to the actual
generated API. Generate the marshaller and configuration, rebuild the BOM,
then compile and deploy using your installed ODM release.

See ../cobol/README.md for the complete handoff and acceptance steps.
