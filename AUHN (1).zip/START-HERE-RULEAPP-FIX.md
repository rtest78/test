# AUHN complete source workspace — RuleApp XOM linkage update

Updated October 25, 2026. Baseline: uploaded AUHN.zip, version 3.

## Scope and validation status

This archive contains all five projects, 145 BRL rules, ruleflows, separate BOM,
business XOM, generated COBOL XOM, adapter, copybooks, marshaller, caller/JCL assets,
and tests from the baseline. It is a source workspace, not an exported RuleApp.
The changes address execution-class visibility for AuDecisionAreaMapper.
The baseline already referenced the adapter in AUHN-Rules, so the stack trace
alone does not prove the precise cause in the failing workspace.

## Changes

- Both AUHN-BOM and AUHN-Rules now explicitly reference and export all three
  Java XOM projects: AUHN-XOM, AUHN-COBOL-XOM and AUHN-COBOL-Adapter.
- Explicit Eclipse project dependencies establish build ordering; the duplicate
  COBOL XOM dependency in AUHN-Rules was removed.
- Adapter Java dependencies on both XOM projects are exported.
- Recompiled every Java source into its project's bin folder using Java 8 targets.
- Refreshed all three execution archives in resources/xom-libraries and supplied
  all three matching JARs in integration/lib. The marshaller is retained.
- Added a reproducible full XOM build and a packaged-class linkage test.
- Rule bodies, BOM definitions, vocabulary, flows, generated Java source,
  copybooks and COBOL callers were retained. No business-logic equivalence claim
  follows from this packaging correction.

## Import and build

1. Extract this archive into a new folder. Use a fresh Rule Designer workspace
   to avoid combining old and new project configurations.
2. File > Import > General > Existing Projects into Workspace. Select all five
   projects: AUHN-XOM, AUHN-COBOL-XOM, AUHN-COBOL-Adapter, AUHN-BOM, AUHN-Rules.
3. Use your installed ODM 9.0 COBOL support. Preserve the generated COBOL XOM
   classpath container; it supplies IBM annotations and COBOL metadata support.
4. Project > Clean, then build all projects. Resolve any Problems-view errors
   in the Java projects before attempting RuleApp creation.
5. In the BOM and rules projects' Java XOM configuration, confirm all three
   project references are visible and exported. Do not add stale alternate JARs
   with the same classes. The project-reference configuration is the default.
6. Confirm AUHN_KB_Rules exposes exactly auDecisionArea as IN_OUT, typed as
   com.techsavants.auhn.cobol.Auodm_decision_area. The mapper is not a parameter.
7. Open deployment/AUHN_KB_RuleApp.dep and create the RuleApp. Managed XOM is
   enabled. Verify the deployed dependencies include all three XOMs and the
   supplied COBOL marshaller. Follow integration/README.md for the caller setup.
8. Execute representative NB/AO requests through the actual deployed operation
   and COBOL caller before promoting the change.

If GBREX0001E persists after a clean import, capture the Java Problems entries,
Java XOM reference screen and RuleApp export log. Do not delete the bridge BOM
or mark the concrete mapper as a virtual class to hide the missing dependency.

## Rebuild outside Eclipse

With Python 3 and JDK 9+ installed, from this archive root:

    python integration/build-xom.py --odm-classpath "<path-to-IBM-ODM-jars>/*"

Use the IBM classpath containing ilog.rules.bom.annotations.CustomProperties.
For multiple paths use your operating system's classpath separator. No IBM
runtime libraries are redistributed by this update. The build emits Java 8
bytecode and refreshes the distributable XOM archives. The pre-existing quick
mapper script is still available, but the new script recompiles all three XOMs.

## Verification performed for this update

- All 75 Java source files compiled: 53 business XOM, 21 COBOL XOM, 1 adapter.
- Existing mapper test: 205 assertions passed, including 177 loader properties.
- Packaged-JAR linkage: the concrete mapper, decision-area, request, response,
  root constructor and both methods declared in the bridge BOM resolved.
- XML configuration: both rule projects export all three Java XOMs; the sole
  operation parameter remains auDecisionArea IN_OUT.
- 234 existing rule/BOM/vocabulary/COBOL assets compared byte-for-byte unchanged.

Not verified here: Rule Designer's actual RuleApp archive export, RES deployment,
IBM marshalling execution, HBRRULE on z/OS, or full AION/ODM result parity. These
require the installed IBM environment and approved expected results. Historical
reports included in the original archive retain their original scope and date.
