000100******************************************************************00000100
000200* WUC104 - DRIVER COBOL II RECORD LAYOUT.                      *  00000200
000300******************************************************************00000300
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00000400
000500* DRIVER DATA TO BE PASSED TO AION.                              *00000500
000600*                                                                *00000600
000601* MM/DD/CCYY    PAR NO  USERID BRIEF DESCRIPTION                 *00000601
000602*================================================================*00000602
000603* 05/09/2013 PAC-12-04H CS0373 ADD WUC104-DRV-STUDENT-AWAY-IND  * 00000603
000610*                                  WUC104-DRV-STUDENT-AWAY-REAPPL*00000610
000603* 05/09/2018 CR17413    CS0096 ADD WUC104-DRV-OTH-COUNTRY-LIC-IND*00000620
000603* 08/21/2024 IUA-651112 CS0324 ADD WUC104-FIRST-NAME LAST-NAME   *00000620
000700******************************************************************00000700
000800*01 WUC104-DRIVER-REC.                                            00000800
000900   05 WUC104-DRIVER-INFORMATION OCCURS 50 TIMES                   00000900
001000             INDEXED BY DRV-IDX.                                  00001000
001100      10 WUC104-DRV-GENERATION             PIC  X(01).            00001100
001200         88 WUC104-UNKNOWN-GENERATION                VALUE 'X'.   00001200
001300         88 WUC104-EXISTING-GENERATION               VALUE 'E'.   00001300
001400         88 WUC104-CHANGE-GENERATION                 VALUE 'C'.   00001400
001500      10 WUC104-DRV-DOP-ACTION             PIC  X(04).            00001500
001600      10 WUC104-DRV-DRIVER-NUMBER          PIC  9(15).            00001600
001700      10 WUC104-DRV-LICENSE-NUMBER         PIC  X(10).            00001700
001800      10 WUC104-DRV-DRIVER-CODE            PIC  X(01).            00001800
001900      10 WUC104-DRV-YR-FIRST-LICENSED      PIC  9(04).            00001900
002000      10 WUC104-DRV-GOOD-DRIVER-IND        PIC  X(01).            00002000
002100      10 WUC104-DRV-RELATION-TO-APPLCNT    PIC  X(02).            00002100
002200      10 WUC104-DRV-NAMED-INSURED-IND      PIC  X(01).            00002200
002300      10 WUC104-DRV-ID-NUMBER              PIC  9(04).            00002300
002400      10 WUC104-DRV-OUT-OF-STAT-LIC-IND    PIC  X(01).            00002400
002500      10 WUC104-DRV-OWN-CAR-AND-INS-IND    PIC  X(01).            00002500
002600      10 WUC104-DRV-RSN-DRVR-ELIMD-C       PIC  X(02).            00002600
002700      10 WUC104-DRV-PROOF-OF-DEPEND-IND    PIC  X(01).            00002700
002800      10 WUC104-DRV-BIRTHDATE              PIC  X(10).            00002800
002900      10 WUC104-DRV-TOTAL-POINTS           PIC  9(04).            00002900
003000      10 WUC104-DRV-TOTAL-SUSP-COUNT       PIC  9(04).            00003000
320100      10 WUC104-DRV-CA-LIC-ISSUE-YEAR      PIC  9(04).            00320100
320200      10 WUC104-DRV-PREV-LIC-OUT-OF-ST     PIC  X(01).            00320200
320300      10 WUC104-DRV-STUDENT-AWAY-IND       PIC  X(01).            00320300
320400      10 WUC104-DRV-STUDENT-AWAY-REAPPL    PIC  9(04).            00320400
002400      10 WUC104-DRV-OTH-COUNTRY-LIC-IND    PIC  X(01).            00320500
002400      10 WUC104-DRV-CUR-OTH-CNTRY-LIC-I    PIC  X(01).            00320600
      * IUA-65112 08/21/2024 CS0324 - START                                     
            10 WUC104-DRV-FIRST-NAME             PIC  X(15).                    
            10 WUC104-DRV-LAST-NAME              PIC  X(30).                    
      * IUA-65112 08/21/2024 CS0324 - END                                       
