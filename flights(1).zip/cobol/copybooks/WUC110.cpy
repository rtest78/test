000100******************************************************************00010000
000200* WUC110 - DRIVER OF VEHICLE COBOL II RECORD LAYOUT.             *00020000
000300******************************************************************00030000
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00040000
000500* DRIVER OF VEHICLE DATA TO BE PASSED TO AION.                   *00050000
000600*                                                                *00060000
000700******************************************************************00070000
000800*01 WUC110-DRIVER-OF-VEHICLE-REC.                                 00080000
000900   05 WUC110-DRIVER-OF-VEHICLE-DATA OCCURS 500 TIMES              00090000
001000             INDEXED BY DOV-IDX.                                  00100000
001100      10 WUC110-DOV-GENERATION             PIC  X(01).            00110000
001200         88 WUC110-UNKNOWN-GENERATION                VALUE 'X'.   00120000
001300         88 WUC110-EXISTING-GENERATION               VALUE 'E'.   00130000
001400         88 WUC110-CHANGE-GENERATION                 VALUE 'C'.   00140000
001500      10 WUC110-DOV-ACTION                 PIC  X(04).            00150000
001600      10 WUC110-DOV-VEHICLE-NUMBER         PIC  9(04).            00160000
001700      10 WUC110-DOV-DRIVER-NUMBER          PIC  9(15).            00170000
001800      10 WUC110-DOV-PRIMARY-DRVR-IND       PIC  X(01).            00180000
