package com.techsavants;

import java.util.ArrayList;
import java.util.List;

public class TravelContext {

    private String targetCity;
    private boolean findShortestOnly;

    private List<Node> nodes = new ArrayList<Node>();
    private List<Node> candidateNodes = new ArrayList<Node>();
    private List<Node> goodNodes = new ArrayList<Node>();

    public TravelContext() {
    }

    public String getTargetCity() {
        return targetCity;
    }

    public void setTargetCity(String targetCity) {
        this.targetCity = targetCity;
    }

    public boolean isFindShortestOnly() {
        return findShortestOnly;
    }

    public void setFindShortestOnly(
            boolean findShortestOnly) {

        this.findShortestOnly = findShortestOnly;
    }

    public List<Node> getNodes() {
        return nodes;
    }

    public void setNodes(List<Node> nodes) {

        if (nodes == null) {
            this.nodes = new ArrayList<Node>();
        } else {
            this.nodes = nodes;
        }
    }

    public List<Node> getCandidateNodes() {
        return candidateNodes;
    }

    public void setCandidateNodes(
            List<Node> candidateNodes) {

        if (candidateNodes == null) {
            this.candidateNodes =
                new ArrayList<Node>();
        } else {
            this.candidateNodes =
                candidateNodes;
        }
    }

    public List<Node> getGoodNodes() {
        return goodNodes;
    }

    public void setGoodNodes(
            List<Node> goodNodes) {

        if (goodNodes == null) {
            this.goodNodes =
                new ArrayList<Node>();
        } else {
            this.goodNodes =
                goodNodes;
        }
    }

    public boolean hasNoNodes() {

        return nodes == null ||
               nodes.isEmpty();
    }

    public boolean hasNodeForCity(
            String city) {

        if (city == null ||
            nodes == null) {

            return false;
        }

        for (Node node : nodes) {

            if (node != null &&
                city.equals(
                    node.getCurrentCity())) {

                return true;
            }
        }

        return false;
    }

    public void addNode(Node node) {

        if (node == null) {
            return;
        }

        if (nodes == null) {
            nodes = new ArrayList<Node>();
        }

        nodes.add(node);
    }

    public boolean hasCandidateNodes() {

        return candidateNodes != null &&
               !candidateNodes.isEmpty();
    }

    public boolean hasNoCandidateNodes() {

        return candidateNodes == null ||
               candidateNodes.isEmpty();
    }

    public void addCandidateNode(
            Node node) {

        if (node == null) {
            return;
        }

        if (candidateNodes == null) {
            candidateNodes =
                new ArrayList<Node>();
        }

        candidateNodes.add(node);
    }

    public Node removeLowestMileageCandidate() {

        if (candidateNodes == null ||
            candidateNodes.isEmpty()) {

            return null;
        }

        int lowestIndex = 0;

        for (int index = 1;
             index < candidateNodes.size();
             index++) {

            Node currentNode =
                candidateNodes.get(index);

            Node lowestNode =
                candidateNodes.get(lowestIndex);

            if (currentNode != null &&
                (lowestNode == null ||
                 currentNode.getTotalMiles() <
                 lowestNode.getTotalMiles())) {

                lowestIndex = index;
            }
        }

        return candidateNodes.remove(
            lowestIndex);
    }

    public void addGoodNode(Node node) {

        if (node == null) {
            return;
        }

        if (goodNodes == null) {
            goodNodes =
                new ArrayList<Node>();
        }

        goodNodes.add(node);
    }
    
    public static TravelContext createTravelContext(
            FlightRequest request) {

        TravelContext context =
            new TravelContext();

        context.setTargetCity(
            request.getToCity());

        context.setFindShortestOnly(
            request.isShortestRoute());

        context.setNodes(
            new ArrayList<Node>());

        context.setCandidateNodes(
            new ArrayList<Node>());

        context.setGoodNodes(
            new ArrayList<Node>());

        return context;
    }
}