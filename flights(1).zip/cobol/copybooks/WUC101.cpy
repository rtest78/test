000100******************************************************************00010000
000200* WUC101 - TRANSACTION DATA COBOL II RECORD LAYOUT.            *  00020000
000300******************************************************************00030000
000400* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00040000
000500* TRANSACTION DATA TO BE PASSED TO AION.                         *00050000
000600*                                                                *00060000
000700******************************************************************00070000
000800*01 WUC101-TRAN-REC.                                              00080000
000900   05 WUC101-TRAN-TYPE                     PIC  X(02).            00090000
001000   05 WUC101-TRAN-CLUB-CODE                PIC  X(04).            00100000
001100   05 WUC101-TRAN-PRODUCT                  PIC  X(05).            00110000
