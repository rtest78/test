package com.aaa.auhn.kb;

import java.lang.reflect.Method;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Shared property, collection and date operations; referral policy remains in BAL. */
public final class SourceFacts {
    private SourceFacts() {}
    private static final Map<Class<?>,Map<String,Method>> READ = new ConcurrentHashMap<Class<?>,Map<String,Method>>();
    private static final Map<Class<?>,Map<String,Method>> WRITE = new ConcurrentHashMap<Class<?>,Map<String,Method>>();
    private static String key(String s) { return s.replace("_", "").toLowerCase(Locale.ROOT); }
    private static Map<String,Method> methods(Class<?> type,boolean read) {
        Map<Class<?>,Map<String,Method>> cache=read?READ:WRITE;
        Map<String,Method> result=cache.get(type);
        if(result==null) {
            result=new HashMap<String,Method>();
            for(Method m:type.getMethods()) if(m.getName().startsWith(read?"getV":"setV") && m.getParameterTypes().length==(read?0:1)) result.put(key(m.getName().substring(4)),m);
            cache.put(type,result);
        }
        return result;
    }
    public static Object get(Object fact,String property) {
        if(fact==null) return null;
        Method m=methods(fact.getClass(),true).get(key(property));
        if(m==null)throw new IllegalArgumentException("Missing source property "+fact.getClass().getSimpleName()+"."+property);
        try { return m.invoke(fact); } catch(Exception e) { throw new IllegalStateException(e); }
    }
    public static void set(Object fact,String property,Object value) {
        Method m=methods(fact.getClass(),false).get(key(property));
        if(m==null)throw new IllegalArgumentException("Missing source property "+fact.getClass().getSimpleName()+"."+property);
        try { m.invoke(fact,value); } catch(Exception e) { throw new IllegalStateException(fact.getClass().getSimpleName()+"."+property,e); }
    }
    public static String text(Object f,String p) { return (String)get(f,p); }
    public static Integer number(Object f,String p) { return (Integer)get(f,p); }
    public static Date date(Object f,String p) { return (Date)get(f,p); }
    public static boolean flag(Object f,String p) { return Boolean.TRUE.equals(get(f,p)); }
    public static boolean eq(Object a,Object b) { return Objects.equals(a,b); }
    public static boolean yn(Object value) { return value instanceof String && ((String)value).startsWith("Y"); }
    public static boolean contains(String text,String part) { return text!=null && text.contains(part); }
    public static Integer integer(String value) { try { return value==null?null:Integer.valueOf(value.trim()); } catch(NumberFormatException e) { return null; } }
    public static LocalDate day(Date value) { return value==null?null:java.time.Instant.ofEpochMilli(value.getTime()).atZone(ZoneOffset.UTC).toLocalDate(); }
    public static Integer years(Date first,Date last) {
        if(first==null || last==null)return null;
        LocalDate a=day(first),b=day(last);
        return b.getYear()-a.getYear()-(b.getMonthValue()<a.getMonthValue() || b.getMonthValue()==a.getMonthValue() && b.getDayOfMonth()<a.getDayOfMonth()?1:0);
    }
    public static Integer yearSpan(Integer first,Date last) { return first==null || last==null?null:day(last).getYear()-first; }
    public static Integer months(Date first,Date last,boolean roundUp) {
        if(first==null || last==null)return null;
        LocalDate a=day(first),b=day(last);
        int result=(b.getYear()-a.getYear())*12+b.getMonthValue()-a.getMonthValue();
        if(roundUp && a.getDayOfMonth()<b.getDayOfMonth())result++;
        if(!roundUp && a.getDayOfMonth()>b.getDayOfMonth())result--;
        return result;
    }
    public static Long days(Date first,Date last) { return first==null || last==null?null:ChronoUnit.DAYS.between(day(first),day(last)); }
    public static boolean within(Date activity,Date effective,int months) {
        Integer span=months(activity,effective,true);
        return activity!=null && day(activity).getYear()>=1996 && span!=null && span<=months;
    }
    public static int countActivities(List<?> facts,String driver,boolean policy,boolean countable) {
        int n=0;
        for(Object p:facts) if(flag(p,"IsCurrentInfo") && (policy || eq(get(p,"DriverNumber"),driver)) && (!countable || flag(p,"IsCountable")))n++;
        return n;
    }
    // AUHNBOBJ Activities.IsMatchingActivity dispatches ActivitiesMatch on the
    // incoming activity. PACE exact dates match even when driver numbers differ.
    private static boolean matches(Object incoming,Object candidate,boolean exact) {
        Date a=date(incoming,"ActivityDate"),b=date(candidate,"ActivityDate");
        boolean sameDriver=eq(get(incoming,"DriverNumber"),get(candidate,"DriverNumber"));
        if(exact)return sameDriver && eq(a,b);
        boolean pace=incoming instanceof AccidentsPACE;
        if(pace && eq(a,b))return true;
        Long diff=days(a,b);
        return sameDriver && (!pace || get(incoming,"DriverNumber")!=null) && diff!=null && Math.abs(diff)<=30;
    }
    public static boolean allActivitiesMatch(List<?> incoming,List<?> other,String driver) {
        for(Object p:incoming) if(flag(p,"IsCurrentInfo") && flag(p,"IsCountable") && eq(driver,get(p,"DriverNumber"))) {
            boolean found=false;
            for(Object q:other)if(flag(q,"IsCurrentInfo") && matches(p,q,false)) {found=true;break;}
            if(!found)return false;
        }
        return true;
    }
    public static boolean noExactActivityMatch(List<?> incoming,List<?> other,String driver) {
        for(Object p:incoming) if(flag(p,"IsCurrentInfo") && flag(p,"IsCountable") && eq(driver,get(p,"DriverNumber")))
            for(Object q:other)if(flag(q,"IsCurrentInfo") && matches(p,q,true))return false;
        return true;
    }
    public static boolean matchCategories(List<?> incoming,List<?> other,String driver) {
        // Source omits IsCurrentInfo on the other side and ignores categories 0/2.
        for(int category:new int[]{1,3,4,5,6}) {
            int a=0,b=0;
            for(Object p:incoming)if(flag(p,"IsCurrentInfo") && flag(p,"IsCountable") && eq(driver,get(p,"DriverNumber")) && eq(category,get(p,"Category")))a++;
            for(Object p:other)if(flag(p,"IsCountable") && eq(driver,get(p,"DriverNumber")) && eq(category,get(p,"Category")))b++;
            if(b>a)return false;
        }
        return true;
    }
    public static int points(Object activity) {
        if(!flag(activity,"IsCountable"))return 0;
        if(activity instanceof Citations) {
            Integer c=number(activity,"Category");
            return c==null?0:c>=1 && c<=3?2:c>=4 && c<=6?1:0;
        }
        String loss=text(activity,"LossType");
        return "BI".equals(loss)?2:"PD".equals(loss)?1:0;
    }
}
