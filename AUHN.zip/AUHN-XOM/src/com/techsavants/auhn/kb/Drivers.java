package com.techsavants.auhn.kb;
public class Drivers {
    private Boolean vIsCurrentInfo;
    public Boolean getVIsCurrentInfo() { return vIsCurrentInfo; }
    public void setVIsCurrentInfo(Boolean value) { vIsCurrentInfo = value; }
    private Boolean vGoodDriverFlag;
    public Boolean getVGoodDriverFlag() { return vGoodDriverFlag; }
    public void setVGoodDriverFlag(Boolean value) { vGoodDriverFlag = value; }
    private String vDriverNumber;
    public String getVDriverNumber() { return vDriverNumber; }
    public void setVDriverNumber(String value) { vDriverNumber = value; }
    private DriversMVRInfo vMVRInfo;
    public DriversMVRInfo getVMVRInfo() { return vMVRInfo; }
    public void setVMVRInfo(DriversMVRInfo value) { vMVRInfo = value; }
    private String vDriverCode;
    public String getVDriverCode() { return vDriverCode; }
    public void setVDriverCode(String value) { vDriverCode = value; }
    private Integer vAge;
    public Integer getVAge() { return vAge; }
    public void setVAge(Integer value) { vAge = value; }
    private String vRelationshipCode;
    public String getVRelationshipCode() { return vRelationshipCode; }
    public void setVRelationshipCode(String value) { vRelationshipCode = value; }
    private Boolean vOutOfStateLicenseFlag;
    public Boolean getVOutOfStateLicenseFlag() { return vOutOfStateLicenseFlag; }
    public void setVOutOfStateLicenseFlag(Boolean value) { vOutOfStateLicenseFlag = value; }
    private String vIDNumber;
    public String getVIDNumber() { return vIDNumber; }
    public void setVIDNumber(String value) { vIDNumber = value; }
    private Boolean vIsAddedOrNew;
    public Boolean getVIsAddedOrNew() { return vIsAddedOrNew; }
    public void setVIsAddedOrNew(Boolean value) { vIsAddedOrNew = value; }
    private Boolean vCurOtherCountryLicenseFlag;
    public Boolean getVCurOtherCountryLicenseFlag() { return vCurOtherCountryLicenseFlag; }
    public void setVCurOtherCountryLicenseFlag(Boolean value) { vCurOtherCountryLicenseFlag = value; }
    private Integer vTotalGoodDriverPoints;
    public Integer getVTotalGoodDriverPoints() { return vTotalGoodDriverPoints; }
    public void setVTotalGoodDriverPoints(Integer value) { vTotalGoodDriverPoints = value; }
    private Integer vMVRSearchStatus;
    public Integer getVMVRSearchStatus() { return vMVRSearchStatus; }
    public void setVMVRSearchStatus(Integer value) { vMVRSearchStatus = value; }
    private Integer vYearsExperience;
    public Integer getVYearsExperience() { return vYearsExperience; }
    public void setVYearsExperience(Integer value) { vYearsExperience = value; }
    private Boolean vOtherCountryLicenseFlag;
    public Boolean getVOtherCountryLicenseFlag() { return vOtherCountryLicenseFlag; }
    public void setVOtherCountryLicenseFlag(Boolean value) { vOtherCountryLicenseFlag = value; }
    private Boolean vIsNewInfo;
    public Boolean getVIsNewInfo() { return vIsNewInfo; }
    public void setVIsNewInfo(Boolean value) { vIsNewInfo = value; }
    private Boolean vIsExistingInfo;
    public Boolean getVIsExistingInfo() { return vIsExistingInfo; }
    public void setVIsExistingInfo(Boolean value) { vIsExistingInfo = value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction = value; }
    private Boolean vStudentAwayInd;
    public Boolean getVStudentAwayInd() { return vStudentAwayInd; }
    public void setVStudentAwayInd(Boolean value) { vStudentAwayInd = value; }
    private Integer vStudentAwayReapplied;
    public Integer getVStudentAwayReapplied() { return vStudentAwayReapplied; }
    public void setVStudentAwayReapplied(Integer value) { vStudentAwayReapplied = value; }
    private Integer vAdmittedCitationCount;
    public Integer getVAdmittedCitationCount() { return vAdmittedCitationCount; }
    public void setVAdmittedCitationCount(Integer value) { vAdmittedCitationCount = value; }
    private Integer vAdmittedAccidentCount;
    public Integer getVAdmittedAccidentCount() { return vAdmittedAccidentCount; }
    public void setVAdmittedAccidentCount(Integer value) { vAdmittedAccidentCount = value; }
    private Boolean vProofOfDependencyFlag;
    public Boolean getVProofOfDependencyFlag() { return vProofOfDependencyFlag; }
    public void setVProofOfDependencyFlag(Boolean value) { vProofOfDependencyFlag = value; }
    private Integer vNetDriverCount;
    public Integer getVNetDriverCount() { return vNetDriverCount; }
    public void setVNetDriverCount(Integer value) { vNetDriverCount = value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
    private String vACTION_ADDED;
    public String getVACTION_ADDED() { return vACTION_ADDED; }
    public void setVACTION_ADDED(String value) { vACTION_ADDED=value; }
    private String vACTION_CHANGED;
    public String getVACTION_CHANGED() { return vACTION_CHANGED; }
    public void setVACTION_CHANGED(String value) { vACTION_CHANGED=value; }
    private String vACTION_ELIMINATED;
    public String getVACTION_ELIMINATED() { return vACTION_ELIMINATED; }
    public void setVACTION_ELIMINATED(String value) { vACTION_ELIMINATED=value; }
    private Integer vYrFirstLicensed;
    public Integer getVYrFirstLicensed() { return vYrFirstLicensed; }
    public void setVYrFirstLicensed(Integer value) { vYrFirstLicensed=value; }
    private java.util.Date vBirthDate;
    public java.util.Date getVBirthDate() { return vBirthDate; }
    public void setVBirthDate(java.util.Date value) { vBirthDate=value; }
    private String vLicenseNumber;
    public String getVLicenseNumber() { return vLicenseNumber; }
    public void setVLicenseNumber(String value) { vLicenseNumber=value; }
    private Integer vOandPDriverCount;
    public Integer getVOandPDriverCount() { return vOandPDriverCount; }
    public void setVOandPDriverCount(Integer value) { vOandPDriverCount=value; }
    private Integer vActionADDDriverCount;
    public Integer getVActionADDDriverCount() { return vActionADDDriverCount; }
    public void setVActionADDDriverCount(Integer value) { vActionADDDriverCount=value; }
    private Integer vValidDriverCount;
    public Integer getVValidDriverCount() { return vValidDriverCount; }
    public void setVValidDriverCount(Integer value) { vValidDriverCount=value; }
    private Boolean vAllNamedInsuredNonGood;
    public Boolean getVAllNamedInsuredNonGood() { return vAllNamedInsuredNonGood; }
    public void setVAllNamedInsuredNonGood(Boolean value) { vAllNamedInsuredNonGood=value; }
    private String vEliminationReasonCode;
    public String getVEliminationReasonCode() { return vEliminationReasonCode; }
    public void setVEliminationReasonCode(String value) { vEliminationReasonCode=value; }
    private Integer vCAYearsExperience;
    public Integer getVCAYearsExperience() { return vCAYearsExperience; }
    public void setVCAYearsExperience(Integer value) { vCAYearsExperience=value; }
    private Integer vCAYearFirstLicensed;
    public Integer getVCAYearFirstLicensed() { return vCAYearFirstLicensed; }
    public void setVCAYearFirstLicensed(Integer value) { vCAYearFirstLicensed=value; }
    private Integer vMVR_SEARCH_INVALID;
    public Integer getVMVR_SEARCH_INVALID() { return vMVR_SEARCH_INVALID; }
    public void setVMVR_SEARCH_INVALID(Integer value) { vMVR_SEARCH_INVALID=value; }
    private Integer vMVR_SEARCH_VALID;
    public Integer getVMVR_SEARCH_VALID() { return vMVR_SEARCH_VALID; }
    public void setVMVR_SEARCH_VALID(Integer value) { vMVR_SEARCH_VALID=value; }
    private Integer vMVR_NOT_FOUND;
    public Integer getVMVR_NOT_FOUND() { return vMVR_NOT_FOUND; }
    public void setVMVR_NOT_FOUND(Integer value) { vMVR_NOT_FOUND=value; }
    private Integer vMVR_ABNORMAL_PROCESSING;
    public Integer getVMVR_ABNORMAL_PROCESSING() { return vMVR_ABNORMAL_PROCESSING; }
    public void setVMVR_ABNORMAL_PROCESSING(Integer value) { vMVR_ABNORMAL_PROCESSING=value; }
    private Integer vAdmittedSuspensionCount;
    public Integer getVAdmittedSuspensionCount() { return vAdmittedSuspensionCount; }
    public void setVAdmittedSuspensionCount(Integer value) { vAdmittedSuspensionCount=value; }
    private Integer vNON_MVR_INVALID_LICENSE;
    public Integer getVNON_MVR_INVALID_LICENSE() { return vNON_MVR_INVALID_LICENSE; }
    public void setVNON_MVR_INVALID_LICENSE(Integer value) { vNON_MVR_INVALID_LICENSE=value; }
    private Integer vOandXDriverCount;
    public Integer getVOandXDriverCount() { return vOandXDriverCount; }
    public void setVOandXDriverCount(Integer value) { vOandXDriverCount=value; }
    private Integer vEYPDriverCount;
    public Integer getVEYPDriverCount() { return vEYPDriverCount; }
    public void setVEYPDriverCount(Integer value) { vEYPDriverCount=value; }
    private Integer vODriverCount;
    public Integer getVODriverCount() { return vODriverCount; }
    public void setVODriverCount(Integer value) { vODriverCount=value; }
    private Boolean vNamedInsuredFlag;
    public Boolean getVNamedInsuredFlag() { return vNamedInsuredFlag; }
    public void setVNamedInsuredFlag(Boolean value) { vNamedInsuredFlag=value; }
    private Integer vEYTDriverCount;
    public Integer getVEYTDriverCount() { return vEYTDriverCount; }
    public void setVEYTDriverCount(Integer value) { vEYTDriverCount=value; }
    private Integer vDandTDriverCount;
    public Integer getVDandTDriverCount() { return vDandTDriverCount; }
    public void setVDandTDriverCount(Integer value) { vDandTDriverCount=value; }
    private Integer vDandIDriverCount;
    public Integer getVDandIDriverCount() { return vDandIDriverCount; }
    public void setVDandIDriverCount(Integer value) { vDandIDriverCount=value; }
    private Integer vDDriverCount;
    public Integer getVDDriverCount() { return vDDriverCount; }
    public void setVDDriverCount(Integer value) { vDDriverCount=value; }
    private Integer vMVR_NOT_ORDERED;
    public Integer getVMVR_NOT_ORDERED() { return vMVR_NOT_ORDERED; }
    public void setVMVR_NOT_ORDERED(Integer value) { vMVR_NOT_ORDERED=value; }
    private Integer vMVR_NOT_RECEIVED;
    public Integer getVMVR_NOT_RECEIVED() { return vMVR_NOT_RECEIVED; }
    public void setVMVR_NOT_RECEIVED(Integer value) { vMVR_NOT_RECEIVED=value; }
    private Boolean vPrevLicenseOutOfStateFlag;
    public Boolean getVPrevLicenseOutOfStateFlag() { return vPrevLicenseOutOfStateFlag; }
    public void setVPrevLicenseOutOfStateFlag(Boolean value) { vPrevLicenseOutOfStateFlag=value; }
    private Integer vLossTypeCount;
    public Integer getVLossTypeCount() { return vLossTypeCount; }
    public void setVLossTypeCount(Integer value) { vLossTypeCount=value; }
}
