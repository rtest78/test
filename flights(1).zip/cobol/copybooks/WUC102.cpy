000100******************************************************************00000100
000201* WUC102 - POLICY COBOL II RECORD LAYOUT.                        *00000201
000301******************************************************************00000301
000401* THIS RECORD DESCRIPTION DEFINES THE WORKING STORAGE FOR        *00000401
000501* POLICY DATA TO BE PASSED TO AION.                              *00000501
000601* ************************************************************** *00000601
000701* MODIFICATION LOG                                               *00000701
000801*                                                                *00000801
000802* MM/DD/CCYY    PAR NO  USERID  BRIEF DESCRIPTION                *00000802
000803*================================================================*00000803
000817* 05/09/2013 SR1011530  CS0373  ADD WUC102-RE-WRITTEN-POLICY-IND *00000817
000818* 05/09/2013 SR1011713  CS0373  ADD WUC102-SPIN-OFF-POLICY-IND   *00000818
000819* 05/09/2013 SR1011714  CS0373  ADD WUC102-NNO-POLICY-IND        *00000819
000820*                                                                *00000820
002701******************************************************************00002701
002801*01 WUC102-POLICY-REC.                                            00002801
002901   05 WUC102-POLICY-INFORMATION OCCURS 2 TIMES                    00002901
003001             INDEXED BY POL-IDX.                                  00003001
003101      10 WUC102-POL-GENERATION             PIC  X(01).            00003101
003201         88 WUC102-UNKNOWN-GENERATION                VALUE 'X'.   00003201
003301         88 WUC102-EXISTING-GENERATION               VALUE 'E'.   00003301
003401         88 WUC102-CHANGE-GENERATION                 VALUE 'C'.   00003401
003501      10 WUC102-POL-NEW-RENEW-CODE         PIC  X(03).            00003501
003601      10 WUC102-POL-NAMED-INSURD-STATUS    PIC  X(01).            00003601
003701      10 WUC102-POL-EXCESS-POL-IND         PIC  X(01).            00003701
003801      10 WUC102-POL-COMMENTS-IND           PIC  X(01).            00003801
003901      10 WUC102-POL-GEN-EFF-DATE           PIC  X(10).            00003901
004001      10 WUC102-POL-TRANS-DATE             PIC  X(10).            00004001
004101      10 WUC102-POL-LONGEVITY-DATE         PIC  X(10).            00004101
004201      10 WUC102-POL-EXCESS-NB-POL-IND      PIC  X(01).            00004201
004301      10 WUC102-POL-MGR-APPROVAL           PIC  X(01).            00004301
004401      10 WUC102-POL-NAMED-INSRD-CHANGE     PIC  X(01).            00004401
004501      10 WUC102-POL-JWL-HUON-PRM-DISCR     PIC  X(01).            00004501
004601      10 WUC102-POL-NB-REGD-OWNER-OTHER    PIC  X(01).            00004601
004701      10 WUC102-POL-BUSINESS-CLASS         PIC  X(01).            00004701
004801      10 WUC102-POL-EXCHLONGV-CHANGE       PIC  X(01).            00004801
004901      10 WUC102-POL-AGENT-CHANGE           PIC  X(01).            00004901
005001      10 WUC102-POL-CLUE-STATUS            PIC  X(01).            00005001
005101      10 WUC102-POL-VADINS                 PIC  X(01).            00005101
005201      10 WUC102-POL-SD-LNH                 PIC  X(01).            00005201
005301      10 WUC102-POL-SD-LSH                 PIC  X(01).            00005301
005401      10 WUC102-POL-SD-LSHM                PIC  X(01).            00005401
005501      10 WUC102-POL-CLUE-NOT-RECD-DUMMY    PIC  X(01).            00005501
005601      10 WUC102-EAD-MGR-APPROVAL           PIC  X(01).            00005601
005701      10 WUC102-POL-CAC-LOSS-IND           PIC  X(01).            00005701
005801      10 WUC102-POL-CAC-DRV-ERR-IND        PIC  X(01).            00005801
005901      10 WUC102-POL-ANN-MILE-OVR-IND       PIC  X(01).            00005901
005902      10 WUC102-POL-REF-FOR-BRANCH-IND     PIC  X(01).            00005902
005903      10 WUC102-POL-REF-FOR-AGENT-IND      PIC  X(01).            00005903
005904      10 WUC102-POL-LIAB-ONLY-COVG-IND     PIC  X(01).            00005904
006002      10 WUC102-POL-TRANS-TYPE             PIC  X(02).            00006002
006101      10 WUC102-POL-BUS-CLASS-SCR          PIC  X(03).            00006101
006201      10 WUC102-POL-PRD-EFF-DATE           PIC  9(08).            00006201
006301      10 WUC102-PRD-RLS-EFF-DATE           PIC  X(08).            00006301
006302      10 WUC102-RE-WRITTEN-POLICY-IND      PIC  X(01).            00006302
006303      10 WUC102-SPIN-OFF-POLICY-IND        PIC  X(01).            00006303
006304      10 WUC102-NNO-POLICY-IND             PIC  X(01).            00006304
006305      10 WUC102-BACKDATED-EFF-DATE-IND     PIC  X(01).            00006305
