package com.aaa.auhn.kb;
public class MVR5Data {
    private java.util.Date vAccident_Date;
    public java.util.Date getVAccident_Date() { return vAccident_Date; }
    public void setVAccident_Date(java.util.Date value) { vAccident_Date = value; }
    private String vDescription;
    public String getVDescription() { return vDescription; }
    public void setVDescription(String value) { vDescription = value; }
    private String vLicense_Number;
    public String getVLicense_Number() { return vLicense_Number; }
    public void setVLicense_Number(String value) { vLicense_Number = value; }
    private java.util.Date vLic_Rein_Date;
    public java.util.Date getVLic_Rein_Date() { return vLic_Rein_Date; }
    public void setVLic_Rein_Date(java.util.Date value) { vLic_Rein_Date = value; }
    private Integer vSequence_Number;
    public Integer getVSequence_Number() { return vSequence_Number; }
    public void setVSequence_Number(Integer value) { vSequence_Number = value; }
    private String vType;
    public String getVType() { return vType; }
    public void setVType(String value) { vType = value; }
}
