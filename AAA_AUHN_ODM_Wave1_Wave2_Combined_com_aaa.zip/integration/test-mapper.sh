#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p .mapper-test/classes .mapper-test/tests
find AUHN-XOM/src AUHN-COBOL-Adapter/src -name '*.java' > .mapper-test/sources.txt
java com.sun.tools.javac.Main --release 8 -cp AUHN-COBOL-XOM/bin -d .mapper-test/classes @.mapper-test/sources.txt
java com.sun.tools.javac.Main --release 8 -cp .mapper-test/classes:AUHN-COBOL-XOM/bin -d .mapper-test/tests AUHN-COBOL-Adapter/test/com/aaa/auhn/adapter/MapperTest.java
java -cp .mapper-test/tests:.mapper-test/classes:AUHN-COBOL-XOM/bin com.aaa.auhn.adapter.MapperTest AUHN-COBOL-Adapter/test/loader-parity.tsv
