package com.aaa.auhn.kb;

/**
 * Direct assignments traced to AUHNBOBJ._ComputeData; generated from source.
 */
final class SourceMappings {

	static void copy(Object target, Object raw) {
		String type = target.getClass().getSimpleName();

		if (type.equals("Policies")) { // AUHNBOBJ.txt:7615
			SourceFacts.set(target, "EffectiveDate", SourceFacts.get(raw, "Gen_Eff_Date"));
			SourceFacts.set(target, "CommentFlag", SourceFacts.yn(SourceFacts.get(raw, "Comments_Ind")));
			SourceFacts.set(target, "UmbrellaPolicyFlag", SourceFacts.yn(SourceFacts.get(raw, "Excess_Pol_Ind")));
			SourceFacts.set(target, "NamedInsuredChanged", SourceFacts.get(raw, "Named_Insured_Changed"));
			SourceFacts.set(target, "CLUENotReceived", SourceFacts.get(raw, "CLUE_Not_Received"));
			SourceFacts.set(target, "JewelHUONPremDiscrepancy", SourceFacts.get(raw, "Jewel_HUON_Prem_Discrepancy"));
			SourceFacts.set(target, "InceptionChangeFlag", SourceFacts.yn(SourceFacts.get(raw, "Inception_Change")));
			SourceFacts.set(target, "AgentChangeFlag", SourceFacts.yn(SourceFacts.get(raw, "Agent_Change")));
			SourceFacts.set(target, "ClueReceivedFlag", SourceFacts.yn(SourceFacts.get(raw, "Clue_Received")));
			SourceFacts.set(target, "VehicleAdditionalInsuredsFlag", SourceFacts.yn(SourceFacts.get(raw, "VADINS")));
			SourceFacts.set(target, "MgrApprovalFlag", SourceFacts.yn(SourceFacts.get(raw, "Mgr_Approval")));
			SourceFacts.set(target, "MgrEADApprovalFlag", SourceFacts.yn(SourceFacts.get(raw, "Mgr_EAD_Approval")));
			SourceFacts.set(target, "ReferBranchExistsFlag",
					SourceFacts.yn(SourceFacts.get(raw, "Refer_Branch_Exists")));
			SourceFacts.set(target, "ReferAgentExistsFlag", SourceFacts.yn(SourceFacts.get(raw, "Refer_Agent_Exists")));
			SourceFacts.set(target, "LiabOnlyCovgExistsFlag",
					SourceFacts.yn(SourceFacts.get(raw, "Liab_Only_Covg_Exists")));
			SourceFacts.set(target, "CACDrvCdErrorExistsFlag",
					SourceFacts.yn(SourceFacts.get(raw, "CAC_DrvCd_Error_Exists")));
			SourceFacts.set(target, "CACLossExistsFlag", SourceFacts.yn(SourceFacts.get(raw, "CAC_Loss_Exists")));
			SourceFacts.set(target, "AnnMileOverrideExists",
					SourceFacts.yn(SourceFacts.get(raw, "Ann_Mile_Override_Exists")));
			SourceFacts.set(target, "RewrittenPolicy", SourceFacts.yn(SourceFacts.get(raw, "Rewritten_Policy")));
			SourceFacts.set(target, "SpinOffPolicy", SourceFacts.get(raw, "SpinOff_Policy"));
			SourceFacts.set(target, "NNOPolicy", SourceFacts.get(raw, "NNO_Policy"));
			SourceFacts.set(target, "BackdatedEffDt", SourceFacts.get(raw, "Backdated_Eff_Dt"));
			SourceFacts.set(target, "TransType", SourceFacts.get(raw, "Trans_Type"));
			SourceFacts.set(target, "BusinessClass", SourceFacts.get(raw, "Business_Class"));
			SourceFacts.set(target, "BusinessClassScore", SourceFacts.get(raw, "BusinessClass_Score"));
			SourceFacts.set(target, "PolPrdEffDte", SourceFacts.get(raw, "Pol_Prd_Eff_Dte"));
			SourceFacts.set(target, "ProdRlseEffDte", SourceFacts.get(raw, "Prod_Rlse_Eff_Dte"));
			return;
		}

		if (type.equals("Coverages")) { // AUHNBOBJ.txt:4585
			SourceFacts.set(target, "VehicleNumber", SourceFacts.get(raw, "Vehicle_Number"));
			SourceFacts.set(target, "_CoverageLimitText", SourceFacts.get(raw, "Limit"));
			SourceFacts.set(target, "CoverageType", SourceFacts.get(raw, "Line"));
			return;
		}

		if (type.equals("Inspections")) { // AUHNBOBJ.txt:7042
			SourceFacts.set(target, "VehicleNumber", SourceFacts.get(raw, "Vehicle_Number"));
			SourceFacts.set(target, "PhotoCode", SourceFacts.get(raw, "Photo_Code"));
			SourceFacts.set(target, "ModifiedFlag", SourceFacts.yn(SourceFacts.get(raw, "Modified_Ind")));
			return;
		}

		if (type.equals("AccidentsAdmitted")) { // AUHNBOBJ.txt:1658
			SourceFacts.set(target, "ActivityDate", SourceFacts.get(raw, "Acc_Date"));
			SourceFacts.set(target, "_AccidentID", SourceFacts.get(raw, "Acc_Id"));
			SourceFacts.set(target, "DriverNumber", SourceFacts.get(raw, "Driver_Number"));
			SourceFacts.set(target, "LossType", SourceFacts.get(raw, "Loss_Type"));
			SourceFacts.set(target, "AccidentChargeableIndicator", SourceFacts.yn(SourceFacts.get(raw, "Acc_ChrgInd")));
			return;
		}

		if (type.equals("AccidentsPACE")) { // AUHNBOBJ.txt:2090
			SourceFacts.set(target, "ActivityDate", SourceFacts.get(raw, "LossDate"));
			SourceFacts.set(target, "LossType", SourceFacts.get(raw, "LossType"));
			SourceFacts.set(target, "LossAmount", SourceFacts.get(raw, "LossAmount"));
			SourceFacts.set(target, "LossStatus", SourceFacts.get(raw, "LossStatus"));
			return;
		}

		if (type.equals("CitationsAdmitted")) { // AUHNBOBJ.txt:2692
			SourceFacts.set(target, "ActivityDate", SourceFacts.get(raw, "Cit_Date"));
			SourceFacts.set(target, "_CitationID", SourceFacts.get(raw, "Cit_ID"));
			SourceFacts.set(target, "Category", SourceFacts.get(raw, "Category"));
			SourceFacts.set(target, "DriverNumber", SourceFacts.get(raw, "Driver_Number"));
			return;
		}

		if (type.equals("SuspensionsAdmitted")) { // AUHNBOBJ.txt:4077
			SourceFacts.set(target, "ActivityDate", SourceFacts.get(raw, "Susp_Date"));
			SourceFacts.set(target, "_SuspensionID", SourceFacts.get(raw, "Susp_id"));
			SourceFacts.set(target, "ActivityDate", SourceFacts.get(raw, "Rein_Date"));
			SourceFacts.set(target, "_SuspensionID", SourceFacts.get(raw, "Susp_id"));
			SourceFacts.set(target, "ActivityDate", SourceFacts.get(raw, "Susp_Date"));
			SourceFacts.set(target, "DriverNumber", SourceFacts.get(raw, "Driver_number"));
			SourceFacts.set(target, "SuspID", SourceFacts.get(raw, "Susp_id"));
			return;
		}

		if (type.equals("Drivers")) { // AUHNBOBJ.txt:5421
			SourceFacts.set(target, "DriverCode", SourceFacts.get(raw, "Driver_Code"));
			SourceFacts.set(target, "DriverNumber", SourceFacts.get(raw, "Driver_Number"));
			SourceFacts.set(target, "TotalGoodDriverPoints", SourceFacts.get(raw, "TOT_Points"));
			SourceFacts.set(target, "_YrFirstLicensed", SourceFacts.get(raw, "YR_First_Licensed"));
			SourceFacts.set(target, "_CAYearFirstLicensed", SourceFacts.get(raw, "CAYR_First_Licensed"));
			SourceFacts.set(target, "LicenseNumber", SourceFacts.get(raw, "License_Number"));
			SourceFacts.set(target, "IDNumber", SourceFacts.get(raw, "ID_Number"));
			SourceFacts.set(target, "_Birthdate", SourceFacts.get(raw, "Birthdate"));
			SourceFacts.set(target, "EliminationReasonCode", SourceFacts.get(raw, "RemovalCode"));
			SourceFacts.set(target, "RelationshipCode", SourceFacts.get(raw, "Relation_to_Applicant"));
			SourceFacts.set(target, "GoodDriverFlag", SourceFacts.yn(SourceFacts.get(raw, "Good_Driver_Ind")));
			SourceFacts.set(target, "ProofOfDependencyFlag",
					SourceFacts.yn(SourceFacts.get(raw, "ProofOfDependencyInd")));
			SourceFacts.set(target, "NamedInsuredFlag", SourceFacts.yn(SourceFacts.get(raw, "Named_Insured_Ind")));
			SourceFacts.set(target, "OutOfStateLicenseFlag", SourceFacts.yn(SourceFacts.get(raw, "Out_of_State_Lic")));
			SourceFacts.set(target, "OtherCountryLicenseFlag",
					SourceFacts.yn(SourceFacts.get(raw, "Other_Country_Lic")));
			SourceFacts.set(target, "CurOtherCountryLicenseFlag",
					SourceFacts.yn(SourceFacts.get(raw, "Cur_Other_Country_Lic")));
			SourceFacts.set(target, "PrevLicenseOutOfStateFlag",
					SourceFacts.yn(SourceFacts.get(raw, "Prev_Lic_Out_of_State")));
			SourceFacts.set(target, "StudentAwayInd", SourceFacts.yn(SourceFacts.get(raw, "Student_Away_Ind")));
			SourceFacts.set(target, "StudentAwayReapplied", SourceFacts.get(raw, "Student_Away_Reapplied"));
			return;
		}

		if (type.equals("DriversOfVehicles")) { // AUHNBOBJ.txt:6471
			SourceFacts.set(target, "DriverNumber", SourceFacts.get(raw, "Driver_Number"));
			SourceFacts.set(target, "VehicleNumber", SourceFacts.get(raw, "Vehicle_Number"));

			// AION _ComputeData mapping:
			// current.PrimaryDriverFlag = GetBooleanFromYN(iData.GetPrimaryDriverInd())
			SourceFacts.set(target, "PrimaryDriverFlag", SourceFacts.yn(SourceFacts.get(raw, "PrimaryDriverInd")));

			return;
		}

		if (type.equals("Vehicles")) { // AUHNBOBJ.txt:8977
			SourceFacts.set(target, "CarGroup", SourceFacts.get(raw, "Car_Group"));
			SourceFacts.set(target, "Use", SourceFacts.get(raw, "Use"));
			SourceFacts.set(target, "VehicleNumber", SourceFacts.get(raw, "Vehicle_Number"));
			SourceFacts.set(target, "SequenceNumber", SourceFacts.get(raw, "Sequence_Number"));
			SourceFacts.set(target, "RegOwnRelationship", SourceFacts.get(raw, "Reg_Own_Relationship"));
			SourceFacts.set(target, "LimitOfLiability", SourceFacts.get(raw, "Limit_of_Liability"));
			SourceFacts.set(target, "LoadCapacity", SourceFacts.get(raw, "Load_Capacity"));
			SourceFacts.set(target, "Symbol", SourceFacts.get(raw, "Symbol"));
			SourceFacts.set(target, "_PurchaseDate", SourceFacts.get(raw, "PurchaseDate"));
			SourceFacts.set(target, "PurchasePrice", SourceFacts.get(raw, "Purchase_Price"));
			SourceFacts.set(target, "AntiTheftCode", SourceFacts.get(raw, "AntiTheftCode"));
			SourceFacts.set(target, "EVRCode", SourceFacts.get(raw, "EVRCode"));
			SourceFacts.set(target, "BodyType", SourceFacts.get(raw, "Body_Type"));
			SourceFacts.set(target, "MilesCalcMth", SourceFacts.get(raw, "Miles_Calc_Mth"));
			SourceFacts.set(target, "AnnualMilesCode", SourceFacts.get(raw, "Annual_Miles_Code"));
			SourceFacts.set(target, "AnnualMileage", SourceFacts.get(raw, "Annual_Mileage"));
			SourceFacts.set(target, "VndrMilgSrc", SourceFacts.get(raw, "Vndr_Milg_Src"));
			SourceFacts.set(target, "PriRatedDrv", SourceFacts.get(raw, "Pri_Rated_Drv"));
			SourceFacts.set(target, "StorageInd", SourceFacts.get(raw, "Storage_Ind"));
			SourceFacts.set(target, "_Year", SourceFacts.get(raw, "Year"));
			return;
		}

		if (type.equals("Endorsements")) { // AUHNBOBJ.txt:6702
			SourceFacts.set(target, "EndorsementNumber", SourceFacts.get(raw, "Endorsement_Name"));
			SourceFacts.set(target, "ObjectId", SourceFacts.get(raw, "Object_Id"));
			return;
		}

		if (type.equals("PolicyCodes")) { // AUHNBOBJ.txt:8323
			SourceFacts.set(target, "Name", SourceFacts.get(raw, "Name"));
			SourceFacts.set(target, "Code", SourceFacts.get(raw, "Code"));
			return;
		}

		if (type.equals("Occupations")) { // AUHNBOBJ.txt:7177
			SourceFacts.set(target, "DriverNumber", SourceFacts.get(raw, "Driver_Number"));
			SourceFacts.set(target, "JobTitle", SourceFacts.get(raw, "Occup_Title"));
			return;
		}

		if (type.equals("DriversMVRInfo")) { // AUHNBOBJ.txt:12303
			SourceFacts.set(target, "MVRLicenseClass", SourceFacts.get(raw, "Class"));
			SourceFacts.set(target, "MVRStatus", SourceFacts.get(raw, "Status"));
			SourceFacts.set(target, "_MVRLicenseExpireDate", SourceFacts.get(raw, "MVR_Lic_Exp_Date"));
			SourceFacts.set(target, "MVRClearFlag", SourceFacts.yn(SourceFacts.get(raw, "MVR_Record_Clear")));
			return;
		}

		throw new IllegalArgumentException("No source mapping for " + type);
	}
}
