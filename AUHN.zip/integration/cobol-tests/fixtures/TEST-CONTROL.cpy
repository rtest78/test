       01 test-case pic x(24) external.
       01 conn-count binary-long unsigned external.
       01 rule-count binary-long unsigned external.
       01 disc-count binary-long unsigned external.
       01 fixture-errors binary-long unsigned external.
