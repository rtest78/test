package com.aaa.auhn.adapter;
import com.aaa.auhn.cobol.*;
import com.aaa.auhn.kb.*;
import java.util.*;
import java.lang.reflect.*;
import java.nio.file.*;
/** Runs without an ODM engine. Fixture parity covers every existing loader property. */
public class MapperTest {
    static int checks;
    static void eq(Object expected, Object actual) {
        checks++;
        if (!Objects.equals(expected, actual)) throw new AssertionError("Expected " + expected + ", got " + actual);
    }
    interface Work { void run(); }
    static void rejects(Work work) {
        checks++;
        try { work.run(); } catch (IllegalArgumentException expected) { return; }
        throw new AssertionError("Expected rejection");
    }
    static Auodm_decision_area minimal() {
        Auodm_decision_area a = new Auodm_decision_area();
        a.setWuc101_tran_type("NB");
        Wuc102_policy_information p = new Wuc102_policy_information();
        p.setWuc102_pol_generation("C"); p.setWuc102_pol_gen_eff_date("10/12/2026");
        a.setWuc102_policy_information(new Wuc102_policy_information[]{p});
        return a;
    }
    static AuhnResponse response(int size) {
        AuhnResponse r = new AuhnResponse(); r.setRoutingDestination("PDS");
        for (int i=0; i<size; i++) r.getReferrals().add(new Referral("010", "000000000000012", "0007"));
        return r;
    }
    static void set(Object bean,String field,String value) throws Exception {
        String name="set"+Character.toUpperCase(field.charAt(0))+field.substring(1);
        for(Method m:bean.getClass().getMethods()) if(m.getName().equals(name)) {
            Class<?> t=m.getParameterTypes()[0]; Object v=value;
            if(t==short.class) v=Short.valueOf(value.trim());
            if(t==int.class) v=Integer.valueOf(value.trim());
            if(t==long.class) v=Long.valueOf(value.trim());
            m.invoke(bean,v); return;
        }
        throw new AssertionError("Missing setter "+name);
    }
    public static void main(String[] args) throws Exception {
        Auodm_decision_area area = minimal();
        AuhnRequest legacy=new AuhnRequest();
        List<String[]> properties=new ArrayList<String[]>();
        // TSV fixture format produced once from copybooks and reviewed loader offsets.
        for(String line:Files.readAllLines(Paths.get(args[0]))) {
            String[] f=line.split("\\t",-1);
            if(f[0].equals("R")) {
                String cls=f[1]; Object bean=cls.equals("Auodm_decision_area")?area:Class.forName("com.aaa.auhn.cobol."+cls).newInstance();
                String[] names=f[4].split(","), values=f[5].split("\\|",-1);
                for(int i=0;i<names.length;i++) set(bean,names[i],values[i]);
                if(bean!=area) {Object array=Array.newInstance(bean.getClass(),1);Array.set(array,0,bean);area.getClass().getMethod("set"+cls,array.getClass()).invoke(area,array);}
                AionRecordAdapter.load(legacy,f[2],f[6]);
            } else properties.add(f);
        }
        AuhnRequest mapped=AuDecisionAreaMapper.toRequest(area);
        for(String[] f:properties) {
            Method list=AuhnRequest.class.getMethod("get"+f[1]+"Facts");
            Object old=((List<?>)list.invoke(legacy)).get(0), now=((List<?>)list.invoke(mapped)).get(0);
            Method getter=old.getClass().getMethod("getV"+f[2]); eq(getter.invoke(old),getter.invoke(now));
        }
        eq("FULL",mapped.getExecutionPhase());eq("NB",mapped.getTransactionType());
        rejects(()->AuDecisionAreaMapper.toRequest(null));
        Auodm_decision_area invalid=minimal(); invalid.setWuc101_tran_type("XX");rejects(()->AuDecisionAreaMapper.toRequest(invalid));
        invalid.setWuc101_tran_type("AO");eq("AO",AuDecisionAreaMapper.toRequest(invalid).getTransactionType());
        invalid.getWuc102_policy_information()[0].setWuc102_pol_gen_eff_date("02/30/2026"); rejects(()->AuDecisionAreaMapper.toRequest(invalid));
        Auodm_decision_area sent=minimal();
        Wuc104_driver_information end=new Wuc104_driver_information();end.setWuc104_drv_generation("X");
        Wuc104_driver_information tail=new Wuc104_driver_information();tail.setWuc104_drv_generation("C");
        sent.setWuc104_driver_information(new Wuc104_driver_information[]{end,tail});eq(0,AuDecisionAreaMapper.toRequest(sent).getDriverDataFacts().size());
        sent.setWuc104_driver_information(new Wuc104_driver_information[]{new Wuc104_driver_information(),tail});eq(0,AuDecisionAreaMapper.toRequest(sent).getDriverDataFacts().size());
        Wuc111_mvr1_information mvr=new Wuc111_mvr1_information();mvr.setWuc111_mvr1_license_number("XXXXXXXXXX");
        sent.setWuc111_mvr1_information(new Wuc111_mvr1_information[]{mvr});eq(0,AuDecisionAreaMapper.toRequest(sent).getMVR1DataFacts().size());
        sent.setWuc120_pace_information(new Wuc120_pace_information[]{new Wuc120_pace_information()});eq(0,AuDecisionAreaMapper.toRequest(sent).getPACEDataFacts().size());
        sent.setWuc104_driver_information(new Wuc104_driver_information[51]);rejects(()->AuDecisionAreaMapper.toRequest(sent));
        area.setWuc100_policy(123456789);area.setWuc122_pol_cac_exists("Y");Object policies=area.getWuc102_policy_information();
        AuDecisionAreaMapper.writeResponse(area,response(2));eq("PDS  ",area.getWuc121_routing_destination());eq(60,area.getWuc121_routing_reasons().length);
        eq((short)12,area.getWuc121_routing_reasons()[0].getWuc121_rsn_driver_number());eq((short)7,area.getWuc121_routing_reasons()[0].getWuc121_rsn_vehicle_number());eq("X  ",area.getWuc121_routing_reasons()[2].getWuc121_rsn_code());
        eq(123456789,area.getWuc100_policy());eq("Y",area.getWuc122_pol_cac_exists());eq(policies,area.getWuc102_policy_information());
        AuDecisionAreaMapper.writeResponse(area,response(60));eq("010",area.getWuc121_routing_reasons()[59].getWuc121_rsn_code());
        Object before=area.getWuc121_routing_reasons(); rejects(()->AuDecisionAreaMapper.writeResponse(area,response(61)));eq(before,area.getWuc121_routing_reasons());
        AuhnResponse bad=response(0);bad.getReferrals().add(new Referral("010","10000","0001"));rejects(()->AuDecisionAreaMapper.writeResponse(area,bad));eq(before,area.getWuc121_routing_reasons());
        bad.getReferrals().set(0,new Referral("010","ABCD","0001"));rejects(()->AuDecisionAreaMapper.writeResponse(area,bad));
        AuDecisionAreaMapper.writeResponse(area,response(0));eq("X  ",area.getWuc121_routing_reasons()[0].getWuc121_rsn_code());eq("   ",area.getWuc121_routing_reasons()[59].getWuc121_rsn_code());eq((short)0,area.getWuc121_routing_reasons()[59].getWuc121_rsn_driver_number());
        System.out.println("PASS: "+checks+" assertions; 177 mapped properties match existing loaders. No ODM engine or COBOL marshalling was executed.");
    }
}
