#!/usr/bin/env python3
"""Static bytecode consistency check; does not execute the IBM marshaller."""
import json,re,subprocess
from pathlib import Path
base=Path(__file__).resolve().parent;root=base.parents[1]
layout=json.loads((base/'layout.json').read_text())
jar=root/'AUHN-Rules/resources/cobol/marshallers/AUHN-COBOL-XOM-xmarshaller.jar'
prefix='com.aaa.auhn.cobol.marshaller.'
def javap(cls):return subprocess.check_output(['java','com.sun.tools.javap.Main','-c','-classpath',str(jar),prefix+cls],text=True)
def const(line):
    m=re.search(r'iconst_([0-5])',line)
    if m:return int(m[1])
    m=re.search(r'(?:bipush|sipush)\s+(-?\d+)',line)
    if m:return int(m[1])
    m=re.search(r'// int (-?\d+)',line)
    if m:return int(m[1])
    raise AssertionError('Not a constant: '+line)
def read_offsets(text):
    found={}
    lines=text.splitlines()
    for i,line in enumerate(lines):
        m=re.search(r'\.set(Wuc\w+):',line)
        if not m:continue
        if '[L' in line:continue
        prior=[j for j in range(i) if re.search(r'\biload_2\b',lines[j])]
        assert prior,(line,)
        found[m[1].lower()]=const(lines[prior[-1]+1])
    return found
root_reader=javap('Auodm_decision_areaReader');root_offsets=read_offsets(root_reader)
field_checks=0;group_checks=0
for s in layout['sections']:
    grouped=[f for f in s['fields'] if f['in_group']]
    if s['group']:
        cls='Wuc'+s['group'][3:].lower().replace('-','_')
        lines=root_reader.splitlines()
        for i,line in enumerate(lines):
            if cls+'Reader.read:' in line:
                k=max(j for j in range(i) if re.search(r'\biload_2\b',lines[j]))
                assert const(lines[k+1])==s['start']+s['prefix_size'],s
                assert const(lines[k+3])==s['stride'],s
                group_checks+=1;break
        else:raise AssertionError('No group reader '+cls)
        local_offsets=read_offsets(javap(cls+'Reader'))
    for f in s['fields']:
        key=f['name'].lower().replace('-','_')
        expected=f['offset'] if f['in_group'] else s['start']+f['offset']
        actual=(local_offsets if f['in_group'] else root_offsets)[key]
        assert actual==expected,(f['name'],actual,expected)
        field_checks+=1
root_code=javap('RawDataRootImpl')
assert '// int '+str(layout['total_size']) in root_code
assert 'String IBM-037' in root_reader
print(f'PASS: IBM marshaller bytecode layout: {field_checks} field offsets, {group_checks} array starts/strides, total {layout["total_size"]} bytes, IBM-037 text. Static check only.')
# TSV consumed by the separate test codec; full arrays retain physical lengths.
rows=[]
for s in layout['sections']:
    for f in s['fields']:
        cls=('Wuc'+s['group'][3:].lower().replace('-','_')) if f['in_group'] else 'Auodm_decision_area'
        offset=s['start']+(s['prefix_size'] if f['in_group'] else 0)+f['offset']
        rows.append('\t'.join(map(str,[cls,f['name'].lower().replace('-','_'),offset,f['size'],s['count'] if f['in_group'] else 1,s['stride'] if f['in_group'] else 0,'binary' if f['comp'] else 'text'])))
(base/'layout.tsv').write_text('\n'.join(rows)+'\n')
