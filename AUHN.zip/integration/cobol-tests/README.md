# Reproducible local COBOL verification

Tested with GnuCOBOL 3.1.2 on Ubuntu 24.04, GCC 13.2 and Java 17. These are local native COBOL tests, not an IBM Enterprise COBOL or z/OS environment.

## Setup and run

On Ubuntu, including Ubuntu in Windows WSL:

```sh
sudo apt-get update
sudo apt-get install -y gnucobol default-jdk python3 build-essential
bash integration/cobol-tests/run-tests.sh
```

Run the final command from the extracted AUHN archive root. The script requires a JDK 9+ with its compiler module. It compiles the Java sources to Java 8 bytecode. `COBC_BIN` can point to a separately installed GnuCOBOL compiler. Generated executables and buffers go in `.cobol-test`; they are temporary outputs and are not deployed.

## What the tests execute

1. `verify-layout.cbl` compiles the supplied AUODM-WRAPPER and all 23 WUC copybooks without changing their content. It checks the 164,063-byte size and 385 elementary-field offsets, including first and last array occurrences, then writes a native buffer. GnuCOBOL is configured with IBM-style binary sizes and big-endian COMP fields. Text remains native ASCII.
2. `check_marshaller_layout.py` disassembles the original generated IBM marshaller class files with the JDK tool. It compares 205 field offsets, 20 table starts/strides and total buffer size with the copybooks, and confirms IBM-037 text in the generated reader. This is a static check, not execution of that marshaller.
3. `BufferBridgeTest.java` uses a separate, explicitly test-only ASCII codec to read the native COBOL buffer into the actual generated COBOL XOM. It calls the actual AuDecisionAreaMapper for request and response mapping. The response is synthetic, with two reasons; no business rules are evaluated. It writes the returned native buffer and checks that all 163,398 input bytes preceding WUC121 are retained.
4. `verify-return.cbl` reads the returned buffer using the actual copybooks and verifies 16 expected input/output values: binary numbers, identifiers, route, reasons, X marker and cleared unused slots.
5. `test-caller.cbl` compiles and calls the actual `integration/AUHN-HBRRULE.cbl`, linked with test doubles named HBRCONN/HBRRULE/HBRDISC. Six scenarios exercise call sequencing, the single parameter's name/address/length, output returned through that address, error codes, disconnect after rule failure, and success after a previous failure.
6. The existing Java mapper parity suite runs again: 205 assertions, including all 177 raw properties consumed by the supplied AION loaders.

`fixtures/HBRWS.cpy` is **not IBM HBRWS**. It contains only the names/types needed by the test; it omits IBM headers and does not reproduce the production ABI. The fixture directory must never be used to compile or link a production caller. The mock HBR modules must never be installed as IBM runtime replacements.

The native ASCII buffers cannot be submitted directly to the supplied IBM-037 marshaller. Use the real IBM marshaller and correctly encoded COBOL buffers for the deployment round trip.

## Remaining IBM environment checks

The generated reader/writer depend on missing `ilog.rules.res.session.rawdata` IBM runtime classes. No IBM rule compiler, rule execution engine, real HBRWS, HBR API libraries, z/OS server or endpoint is installed here.

Production validation still requires:

- Build the BOM/BAL and ruleset in Rule Designer.
- Compile/link the caller using the real HBRWS and the installed ODM z/OS libraries.
- Run the real generated IBM marshaller against IBM-037 input/output bytes, including all arrays and binary values.
- Compare NB and AO rule results with approved AION cases, deploy a new ruleset version, and call it through the real HBRRULE API.
- Match the runtime and API CCSIDs to the data. The generated COBOL marshaller uses IBM-037; the HBR API control-area string CCSID is a separate setting and may have a different default.

IBM API reference: https://www.ibm.com/docs/en/odm/8.12.0?topic=reference-apis
