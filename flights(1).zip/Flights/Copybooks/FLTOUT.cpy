      * OUTPUT: 100 ROUTES; 50 CITIES PER ROUTE; COUNTS ARE USED.
          05 FLC-ROUTE-COUNT            PIC 9(3).
          05 FLC-ROUTE OCCURS 100 TIMES.
             10 FLC-CURRENT-CITY        PIC X(32).
             10 FLC-TOTAL-MILES         PIC 9(10).
             10 FLC-CITY-COUNT          PIC 9(2).
             10 FLC-ROUTE-CITY OCCURS 50 TIMES.
                15 FLC-VISITED-CITY     PIC X(32).
