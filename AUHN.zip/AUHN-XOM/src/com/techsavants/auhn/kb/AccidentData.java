package com.techsavants.auhn.kb;
public class AccidentData {
    private java.util.Date vAcc_Date;
    public java.util.Date getVAcc_Date() { return vAcc_Date; }
    public void setVAcc_Date(java.util.Date value) { vAcc_Date = value; }
    private String vDriver_Number;
    public String getVDriver_Number() { return vDriver_Number; }
    public void setVDriver_Number(String value) { vDriver_Number = value; }
    private String vLoss_Type;
    public String getVLoss_Type() { return vLoss_Type; }
    public void setVLoss_Type(String value) { vLoss_Type = value; }
    private Integer vAcc_Id;
    public Integer getVAcc_Id() { return vAcc_Id; }
    public void setVAcc_Id(Integer value) { vAcc_Id = value; }
    private String vAcc_ChrgInd;
    public String getVAcc_ChrgInd() { return vAcc_ChrgInd; }
    public void setVAcc_ChrgInd(String value) { vAcc_ChrgInd = value; }
    private String vAction;
    public String getVAction() { return vAction; }
    public void setVAction(String value) { vAction=value; }
    private String vGeneration;
    public String getVGeneration() { return vGeneration; }
    public void setVGeneration(String value) { vGeneration=value; }
}
