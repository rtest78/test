/* Hand-written contract model for local verification.
 * NOT an IBM-generated COBOL XOM and NOT a marshaller.
 * Replace these classes using the IBM COBOL importer before deployment.
 */
package com.techsavants.flights.cobol;

public class Flc_flight {
    private String flc_start_city = "";
    private String flc_stop_city = "";
    private int flc_miles = 0;
    public Flc_flight() {}
    public String getFlc_start_city() { return flc_start_city; }
    public void setFlc_start_city(String value) { flc_start_city = value; }
    public String getFlc_stop_city() { return flc_stop_city; }
    public void setFlc_stop_city(String value) { flc_stop_city = value; }
    public int getFlc_miles() { return flc_miles; }
    public void setFlc_miles(int value) { flc_miles = value; }
}
